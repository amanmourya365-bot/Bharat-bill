"""
BillBharat FastAPI Backend
Handles: Auth helpers, AI CA proxy, Razorpay payment verification,
         Supabase data sync, GSTR export, Webhook handlers
"""

import os
import hmac
import hashlib
import json
from datetime import datetime
from typing import Optional, List, Any

import httpx
import razorpay
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from supabase import create_client, Client

load_dotenv()

# ─────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────
SUPABASE_URL       = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE   = os.getenv("SUPABASE_SERVICE_KEY", "")
RZP_KEY_ID         = os.getenv("RAZORPAY_KEY_ID", "")
RZP_KEY_SECRET     = os.getenv("RAZORPAY_KEY_SECRET", "")
RZP_WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")
ANTHROPIC_KEY      = os.getenv("ANTHROPIC_API_KEY", "")
FRONTEND_URL       = os.getenv("FRONTEND_URL", "http://localhost:3000")
CORS_ORIGINS       = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
PREMIUM_PAISE      = int(os.getenv("PREMIUM_AMOUNT_PAISE", "7900"))

# ─────────────────────────────────────────────────────────────
# App init
# ─────────────────────────────────────────────────────────────
app = FastAPI(
    title="BillBharat API",
    description="Backend for BillBharat GST Billing SaaS",
    version="3.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────
# Supabase client
# ─────────────────────────────────────────────────────────────
def get_supabase() -> Client:
    if not SUPABASE_URL or not SUPABASE_SERVICE:
        raise HTTPException(500, "Supabase not configured")
    return create_client(SUPABASE_URL, SUPABASE_SERVICE)


# ─────────────────────────────────────────────────────────────
# Auth helper — verify Supabase JWT
# ─────────────────────────────────────────────────────────────
async def get_user(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or invalid token")
    token = authorization.split(" ", 1)[1]
    sb = get_supabase()
    resp = sb.auth.get_user(token)
    if not resp or not resp.user:
        raise HTTPException(401, "Invalid token")
    return resp.user


# ─────────────────────────────────────────────────────────────
# Health check
# ─────────────────────────────────────────────────────────────
@app.get("/api/health")
def health():
    return {"status": "ok", "version": "3.0.0", "timestamp": datetime.utcnow().isoformat()}


# ─────────────────────────────────────────────────────────────
# Razorpay — create order
# ─────────────────────────────────────────────────────────────
class CreateOrderReq(BaseModel):
    amount_paise: int = PREMIUM_PAISE
    promo_code: Optional[str] = None

PROMO_DISCOUNTS = {
    "LAUNCH50": 50,
    "STARTUP30": 30,
    "BB2024":   20,
    "EARLYBIRD": 40,
}

@app.post("/api/payment/create-order")
async def create_order(req: CreateOrderReq):
    if not RZP_KEY_ID or not RZP_KEY_SECRET:
        raise HTTPException(500, "Razorpay not configured")

    amount = req.amount_paise
    if req.promo_code:
        disc = PROMO_DISCOUNTS.get(req.promo_code.upper(), 0)
        amount = int(amount * (100 - disc) / 100)

    client = razorpay.Client(auth=(RZP_KEY_ID, RZP_KEY_SECRET))
    order = client.order.create({
        "amount": amount,
        "currency": "INR",
        "payment_capture": 1,
        "notes": {"product": "BillBharat Premium", "promo": req.promo_code or ""}
    })
    return {"order_id": order["id"], "amount": amount, "key": RZP_KEY_ID}


# ─────────────────────────────────────────────────────────────
# Razorpay — verify payment & activate premium
# ─────────────────────────────────────────────────────────────
class VerifyPaymentReq(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    user_id: str

@app.post("/api/payment/verify")
async def verify_payment(req: VerifyPaymentReq):
    # Verify HMAC signature
    msg = f"{req.razorpay_order_id}|{req.razorpay_payment_id}"
    expected = hmac.new(
        RZP_KEY_SECRET.encode(), msg.encode(), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected, req.razorpay_signature):
        raise HTTPException(400, "Invalid payment signature")

    # Activate premium in Supabase
    sb = get_supabase()
    sb.from_("subscriptions").upsert({
        "user_id": req.user_id,
        "is_premium": True,
        "payment_id": req.razorpay_payment_id,
        "order_id": req.razorpay_order_id,
        "activated_at": datetime.utcnow().isoformat(),
        "plan": "monthly"
    }, on_conflict="user_id").execute()

    return {"success": True, "message": "Premium activated!"}


# ─────────────────────────────────────────────────────────────
# Razorpay — webhook (for subscription renewals, refunds)
# ─────────────────────────────────────────────────────────────
@app.post("/api/payment/webhook")
async def razorpay_webhook(request: Request):
    body = await request.body()
    sig = request.headers.get("X-Razorpay-Signature", "")

    # Verify webhook signature
    expected = hmac.new(
        RZP_WEBHOOK_SECRET.encode(), body, hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected, sig):
        raise HTTPException(400, "Invalid webhook signature")

    event = json.loads(body)
    event_type = event.get("event", "")

    if event_type == "payment.captured":
        payment = event["payload"]["payment"]["entity"]
        notes = payment.get("notes", {})
        print(f"[Webhook] Payment captured: {payment['id']} | {payment['amount']/100}₹")
        # Handle subscription renewal here if needed

    elif event_type == "refund.created":
        print(f"[Webhook] Refund: {event['payload']['refund']['entity']['id']}")

    return {"status": "ok"}


# ─────────────────────────────────────────────────────────────
# AI CA Advisor — proxies Anthropic API (hides key from frontend)
# ─────────────────────────────────────────────────────────────
class AIChatReq(BaseModel):
    messages: List[dict]
    system: str
    user_id: Optional[str] = None

@app.post("/api/ai/chat")
async def ai_chat(req: AIChatReq):
    if not ANTHROPIC_KEY:
        raise HTTPException(500, "AI not configured")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1000,
                "system": req.system,
                "messages": req.messages[-8:],  # Last 8 messages for context
            }
        )

    if resp.status_code != 200:
        raise HTTPException(resp.status_code, "AI service error")

    data = resp.json()
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    return {"response": text, "tokens": data.get("usage", {})}


# ─────────────────────────────────────────────────────────────
# Subscription status check
# ─────────────────────────────────────────────────────────────
@app.get("/api/subscription/{user_id}")
async def get_subscription(user_id: str):
    sb = get_supabase()
    result = sb.from_("subscriptions").select("*").eq("user_id", user_id).maybe_single().execute()
    if result.data:
        return {"is_premium": result.data.get("is_premium", False), "data": result.data}
    return {"is_premium": False}


# ─────────────────────────────────────────────────────────────
# GSTR-1 JSON export (for GST portal upload)
# ─────────────────────────────────────────────────────────────
class GSTRExportReq(BaseModel):
    user_id: str
    gstin: str
    fp: str  # Filing period e.g. "032024"
    invoices: List[dict]

@app.post("/api/gstr/generate")
async def generate_gstr(req: GSTRExportReq):
    b2b = []
    b2c_summary = {}

    for inv in req.invoices:
        if not inv.get("hasGst") or inv.get("status") != "paid":
            continue
        party_gstin = inv.get("party", {}).get("gstin", "")
        taxable = inv.get("subtotal", 0)
        cgst = inv.get("totalCGST", 0)
        sgst = inv.get("totalSGST", 0)
        igst = inv.get("totalIGST", 0)
        inv_date = inv.get("invoiceDate", "")

        if party_gstin and len(party_gstin) == 15:
            # B2B invoice
            b2b.append({
                "ctin": party_gstin,
                "inv": [{
                    "inum": inv.get("invoiceNumber", ""),
                    "idt": inv_date,
                    "val": inv.get("grandRounded", 0),
                    "pos": party_gstin[:2],
                    "rchrg": "N",
                    "itms": [{
                        "num": 1,
                        "itm_det": {
                            "txval": round(taxable, 2),
                            "rt": inv.get("items", [{}])[0].get("gstRate", 18),
                            "camt": round(cgst, 2),
                            "samt": round(sgst, 2),
                            "iamt": round(igst, 2),
                        }
                    }]
                }]
            })
        else:
            # B2C — aggregate by GST rate
            rate = str(inv.get("items", [{}])[0].get("gstRate", 18))
            if rate not in b2c_summary:
                b2c_summary[rate] = {"typ": "OE", "pos": "96", "txval": 0, "iamt": 0, "camt": 0, "samt": 0}
            b2c_summary[rate]["txval"] += taxable
            b2c_summary[rate]["iamt"] += igst
            b2c_summary[rate]["camt"] += cgst
            b2c_summary[rate]["samt"] += sgst

    gstr1 = {
        "gstin": req.gstin,
        "fp": req.fp,
        "b2b": b2b,
        "b2cs": list(b2c_summary.values()),
        "generated_at": datetime.utcnow().isoformat()
    }
    return gstr1


# ─────────────────────────────────────────────────────────────
# Sync endpoints (batch upsert from frontend)
# ─────────────────────────────────────────────────────────────
class SyncReq(BaseModel):
    table: str
    rows: List[dict]
    user_id: str

ALLOWED_TABLES = {"invoices", "businesses", "inventory", "payroll", "expenses", "subscriptions"}

@app.post("/api/sync")
async def sync_data(req: SyncReq):
    if req.table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{req.table}' not allowed")
    sb = get_supabase()
    # Tag each row with user_id for RLS
    rows = [{**r, "user_id": req.user_id} for r in req.rows]
    result = sb.from_(req.table).upsert(rows, on_conflict="id").execute()
    return {"synced": len(rows)}


# ─────────────────────────────────────────────────────────────
# Send invoice via WhatsApp (via Meta API stub)
# ─────────────────────────────────────────────────────────────
class WhatsAppReq(BaseModel):
    phone: str
    invoice_number: str
    amount: float
    party_name: str
    pdf_url: Optional[str] = None

@app.post("/api/notify/whatsapp")
async def send_whatsapp(req: WhatsAppReq):
    # TODO: integrate with Meta WhatsApp Business API
    # For now returns a stub response
    print(f"[WhatsApp] Send invoice {req.invoice_number} to {req.phone}")
    return {
        "success": True,
        "message": f"Invoice {req.invoice_number} sent to {req.phone}",
        "note": "Integrate Meta WhatsApp API to enable real sending"
    }


# ─────────────────────────────────────────────────────────────
# GSTIN validation (using govt. API or regex)
# ─────────────────────────────────────────────────────────────
@app.get("/api/gstin/validate/{gstin}")
async def validate_gstin(gstin: str):
    import re
    pattern = r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$"
    is_valid = bool(re.match(pattern, gstin.upper()))
    state_codes = {
        "01": "Jammu & Kashmir", "02": "Himachal Pradesh", "03": "Punjab",
        "04": "Chandigarh", "05": "Uttarakhand", "06": "Haryana",
        "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh",
        "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh",
        "13": "Nagaland", "14": "Manipur", "15": "Mizoram",
        "16": "Tripura", "17": "Meghalaya", "18": "Assam",
        "19": "West Bengal", "20": "Jharkhand", "21": "Odisha",
        "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
        "27": "Maharashtra", "29": "Karnataka", "30": "Goa",
        "32": "Kerala", "33": "Tamil Nadu", "36": "Telangana",
        "37": "Andhra Pradesh", "38": "Ladakh"
    }
    state = state_codes.get(gstin[:2], "Unknown") if is_valid else None
    return {"gstin": gstin.upper(), "valid": is_valid, "state": state}


# ─────────────────────────────────────────────────────────────
# Dashboard analytics (server-side aggregation)
# ─────────────────────────────────────────────────────────────
@app.get("/api/analytics/{user_id}")
async def get_analytics(user_id: str):
    sb = get_supabase()
    try:
        invoices = sb.from_("invoices").select("status,grandRounded,amountPaid,invoiceDate").eq("user_id", user_id).execute().data or []
        expenses = sb.from_("expenses").select("amount,date,category").eq("user_id", user_id).execute().data or []

        total_revenue = sum(i["grandRounded"] for i in invoices if i.get("status") == "paid")
        total_due = sum((i["grandRounded"] - (i.get("amountPaid") or 0)) for i in invoices if i.get("status") in ("unpaid", "partial", "overdue"))
        total_expenses = sum(e["amount"] for e in expenses)

        return {
            "total_revenue": total_revenue,
            "total_due": total_due,
            "total_expenses": total_expenses,
            "net_profit": total_revenue - total_expenses,
            "invoice_count": len(invoices),
            "overdue_count": sum(1 for i in invoices if i.get("status") == "overdue")
        }
    except Exception as e:
        raise HTTPException(500, str(e))


# ─────────────────────────────────────────────────────────────
# Run with: uvicorn main:app --reload --port 8000
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
