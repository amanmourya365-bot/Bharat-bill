-- =====================================================
-- BillBharat — Supabase Database Schema
-- Run this in Supabase → SQL Editor
-- =====================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─────────────────────────────────────────────────────
-- businesses
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS businesses (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  gstin           TEXT,
  is_gst_registered BOOLEAN DEFAULT FALSE,
  phone           TEXT,
  email           TEXT,
  address         JSONB DEFAULT '{}',
  bank            JSONB DEFAULT '{}',
  logo_url        TEXT,
  invoice_prefix  TEXT DEFAULT 'INV',
  invoice_counter TEXT DEFAULT '1001',
  accent_id       TEXT DEFAULT 'teal',
  layout          TEXT DEFAULT 'modern',
  footer_note     TEXT,
  terms_note      TEXT,
  show_bank_details BOOLEAN DEFAULT TRUE,
  show_hsn        BOOLEAN DEFAULT TRUE,
  show_discount   BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- subscriptions
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  is_premium    BOOLEAN DEFAULT FALSE,
  plan          TEXT DEFAULT 'free',
  payment_id    TEXT,
  order_id      TEXT,
  activated_at  TIMESTAMPTZ,
  expires_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- invoices
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id              TEXT PRIMARY KEY,
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  invoice_number  TEXT NOT NULL,
  type            TEXT DEFAULT 'tax_invoice',
  status          TEXT DEFAULT 'unpaid',
  party           JSONB DEFAULT '{}',
  items           JSONB DEFAULT '[]',
  subtotal        NUMERIC(12,2) DEFAULT 0,
  total_cgst      NUMERIC(12,2) DEFAULT 0,
  total_sgst      NUMERIC(12,2) DEFAULT 0,
  total_igst      NUMERIC(12,2) DEFAULT 0,
  total_tax       NUMERIC(12,2) DEFAULT 0,
  grand_total     NUMERIC(12,2) DEFAULT 0,
  grand_rounded   NUMERIC(12,2) DEFAULT 0,
  round_off       NUMERIC(6,2)  DEFAULT 0,
  amount_paid     NUMERIC(12,2) DEFAULT 0,
  payment_mode    TEXT DEFAULT 'UPI',
  invoice_date    TEXT,
  due_date        TEXT,
  notes           TEXT,
  po_number       TEXT,
  template        TEXT DEFAULT 'modern',
  print_size      TEXT DEFAULT 'a4',
  has_gst         BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- inventory (customers + items combined)
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory (
  id          TEXT PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  record_type TEXT NOT NULL,  -- 'customer' or 'item'
  data        JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- expenses
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
  id          TEXT PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  category    TEXT,
  amount      NUMERIC(12,2) DEFAULT 0,
  vendor      TEXT,
  date        TEXT,
  notes       TEXT,
  receipt_url TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- payroll
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll (
  id          TEXT PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  record_type TEXT NOT NULL,  -- 'employee' or 'attendance'
  data        JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────
-- Row Level Security (RLS)
-- ─────────────────────────────────────────────────────
ALTER TABLE businesses    ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices      ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory     ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses      ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll       ENABLE ROW LEVEL SECURITY;

-- Policies: users can only access their own data
CREATE POLICY "users_own_businesses"    ON businesses    FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "users_own_subscriptions" ON subscriptions FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "users_own_invoices"      ON invoices      FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "users_own_inventory"     ON inventory     FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "users_own_expenses"      ON expenses      FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "users_own_payroll"       ON payroll       FOR ALL USING (auth.uid() = user_id);

-- ─────────────────────────────────────────────────────
-- Indexes for performance
-- ─────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_invoices_user    ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_date    ON invoices(invoice_date);
CREATE INDEX IF NOT EXISTS idx_invoices_status  ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_expenses_user    ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_inventory_user   ON inventory(user_id, record_type);
CREATE INDEX IF NOT EXISTS idx_payroll_user     ON payroll(user_id, record_type);

-- ─────────────────────────────────────────────────────
-- updated_at auto-trigger
-- ─────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_businesses_updated    BEFORE UPDATE ON businesses    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_invoices_updated      BEFORE UPDATE ON invoices      FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_inventory_updated     BEFORE UPDATE ON inventory     FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_payroll_updated       BEFORE UPDATE ON payroll       FOR EACH ROW EXECUTE FUNCTION update_updated_at();
