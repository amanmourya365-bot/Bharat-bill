import{useState,useEffect,useCallback,useRef,useMemo}from"react";
import{AreaChart,Area,BarChart,Bar,XAxis,YAxis,Tooltip,ResponsiveContainer}from"recharts";

// ╔══════════════════════════════════════════════════════════════╗
// ║  BILLBHARAT v3 — Enterprise SaaS for Indian SMEs           ║
// ║  Replace the 3 keys below with your actual credentials     ║
// ╚══════════════════════════════════════════════════════════════╝
const SB_URL  = "https://YOUR_PROJECT_ID.supabase.co"; // ← REPLACE
const SB_KEY  = "YOUR_SUPABASE_ANON_KEY";              // ← REPLACE
const RZP_KEY = "rzp_test_YOUR_KEY";                   // ← REPLACE

const PROMOS={LAUNCH50:{disc:50,label:"🎉 50% Launch Offer"},STARTUP30:{disc:30,label:"🚀 30% Startup Deal"},BB2024:{disc:20,label:"💼 20% Welcome Bonus"},EARLYBIRD:{disc:40,label:"🐦 40% Early Bird"}};
let _sb=null;
const getSB=async()=>{if(_sb)return _sb;if(SB_URL.includes("YOUR_PROJECT"))return null;try{const m=await import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm");_sb=m.createClient(SB_URL,SB_KEY);}catch{_sb=null;}return _sb;};
const loadRZP=()=>new Promise(r=>{if(window.Razorpay){r(true);return;}const s=document.createElement("script");s.src="https://checkout.razorpay.com/v1/checkout.js";s.onload=()=>r(true);s.onerror=()=>r(false);document.body.appendChild(s);});
const loadXLSX=()=>new Promise((r,j)=>{if(window.XLSX){r(window.XLSX);return;}const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js";s.onload=()=>r(window.XLSX);s.onerror=j;document.body.appendChild(s);});
const exportXL=async(rows,hdrs,fname)=>{try{const X=await loadXLSX();const ws=X.utils.aoa_to_sheet([hdrs,...rows]);const wb=X.utils.book_new();X.utils.book_append_sheet(wb,ws,"Data");X.writeFile(wb,fname);}catch{alert("Export failed – check network.");}};
const sync=async(t,row)=>{const sb=await getSB();if(!sb)return;try{await sb.from(t).upsert(row,{onConflict:"id"});}catch{}};
const del=async(t,id)=>{const sb=await getSB();if(!sb)return;try{await sb.from(t).delete().eq("id",id);}catch{}};
const _m={};
const LS={get:(k,d)=>{try{const v=localStorage.getItem("bb5_"+k);if(v!=null)return JSON.parse(v);return _m[k]!==undefined?_m[k]:d;}catch{return d;}},set:(k,v)=>{try{localStorage.setItem("bb5_"+k,JSON.stringify(v));}catch{}_m[k]=v;}};

// ── Constants ────────────────────────────────────────────────
const GST_RATES=[0,.1,.25,3,5,12,18,28];
const UNITS=["pcs","kg","ltr","mtr","hrs","days","box","bag","ton","dozen","set","nos","sqft","ml"];
const PAY_MODES=["Cash","UPI","NEFT/RTGS","Cheque","Card","Other"];
const EXP_CATS=["Office Supplies","Travel & Fuel","Food & Dining","Utilities","Rent","Salary","Marketing","Raw Material","Repairs","Transport","Taxes & Fees","Software","Other"];
const REGIONS=["Maharashtra","Karnataka","Tamil Nadu","Delhi","Gujarat","Rajasthan","UP","West Bengal","Telangana","Punjab","Haryana","Kerala","Goa","Other"];
const MO=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MO_F=["January","February","March","April","May","June","July","August","September","October","November","December"];
const LEADS=[{id:"inquiry",l:"Inquiry",c:"#0284C7",bg:"rgba(2,132,199,.1)"},{id:"followup",l:"Follow-up",c:"#D97706",bg:"rgba(217,119,6,.1)"},{id:"converted",l:"Converted",c:"#0CAF60",bg:"rgba(12,175,96,.1)"},{id:"inactive",l:"Inactive",c:"#94A3B8",bg:"rgba(148,163,184,.13)"}];
const SAL_COMPS=[{id:"basic",lbl:"Basic Salary",t:"e"},{id:"hra",lbl:"HRA",t:"e"},{id:"travel",lbl:"Travel Allowance",t:"e"},{id:"special",lbl:"Special Allowance",t:"e"},{id:"bonus",lbl:"Bonus",t:"e"},{id:"pf",lbl:"PF Deduction",t:"d"},{id:"esi",lbl:"ESI",t:"d"},{id:"tds",lbl:"TDS",t:"d"},{id:"advance",lbl:"Advance Recovery",t:"d"},{id:"other_d",lbl:"Other Deduction",t:"d"}];
const ACCENTS=[{id:"teal",n:"Teal",h:"#00897B",d:"#00695C"},{id:"indigo",n:"Indigo",h:"#4A3AFF",d:"#3527E0"},{id:"emerald",n:"Emerald",h:"#059669",d:"#047857"},{id:"rose",n:"Rose",h:"#F43F5E",d:"#BE123C"},{id:"sky",n:"Sky",h:"#0EA5E9",d:"#0369A1"},{id:"violet",n:"Violet",h:"#8B5CF6",d:"#6D28D9"},{id:"amber",n:"Amber",h:"#F59E0B",d:"#D97706"}];
const DTYPES=[{id:"simple_bill",l:"Simple Bill",p:"BILL",i:"🧾"},{id:"tax_invoice",l:"Tax Invoice",p:"INV",i:"📄"},{id:"service_invoice",l:"Service Invoice",p:"SRV",i:"⚙️"},{id:"quotation",l:"Quotation",p:"QUO",i:"💬"},{id:"proforma",l:"Proforma",p:"PRO",i:"📋"},{id:"bill_of_supply",l:"Bill of Supply",p:"BOS",i:"📃"},{id:"credit_note",l:"Credit Note",p:"CDN",i:"↩️"},{id:"debit_note",l:"Debit Note",p:"DBN",i:"↪️"},{id:"delivery_challan",l:"Delivery Challan",p:"DCH",i:"🚛"},{id:"purchase_order",l:"Purchase Order",p:"PO",i:"🛒"},{id:"payment_receipt",l:"Payment Receipt",p:"REC",i:"✅"},{id:"expense_voucher",l:"Expense Voucher",p:"EXP",i:"💸"}];
const NO_GST_SET=new Set(["simple_bill","quotation","payment_receipt","expense_voucher","delivery_challan","purchase_order"]);
const TMPLS=[{id:"modern",l:"Modern",i:"✨",p:false},{id:"billbook",l:"Billbook",i:"📒",p:false},{id:"gst_tally",l:"GST/Tally",i:"📊",p:false},{id:"luxury",l:"Luxury",i:"💎",p:true},{id:"thermal",l:"Thermal 80mm",i:"🖨️",p:true}];

// ── Pure utils ───────────────────────────────────────────────
const fmt=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(n||0);
const fmtN=n=>new Intl.NumberFormat("en-IN",{maximumFractionDigits:2}).format(n||0);
const td=()=>new Date().toISOString().split("T")[0];
const uid=()=>Math.random().toString(36).slice(2,9).toUpperCase();
const dAgo=d=>new Date(Date.now()-d*864e5).toISOString().split("T")[0];
const addD=(d,n)=>new Date(new Date(d).getTime()+n*864e5).toISOString().split("T")[0];
const validG=g=>/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(g||"");
const SC=g=>(g||"").slice(0,2);
const calcLines=(items,sg,bg,noGst)=>{if(noGst)return items.map(i=>{const t=(+i.qty||0)*(+i.rate||0)*(1-(+i.disc||0)/100);return{...i,taxable:t,cgst:0,sgst:0,igst:0,taxAmt:0,lineTotal:t};});const ss=SC(sg),bs=SC(bg),same=ss&&bs&&ss===bs;return items.map(i=>{const t=(+i.qty||0)*(+i.rate||0)*(1-(+i.disc||0)/100),tx=t*(+i.gstRate||0)/100;if(same)return{...i,taxable:t,cgst:tx/2,sgst:tx/2,igst:0,taxAmt:tx,lineTotal:t+tx};return{...i,taxable:t,cgst:0,sgst:0,igst:tx,taxAmt:tx,lineTotal:t+tx};});};
const calcTotals=it=>{const sub=it.reduce((a,i)=>a+(i.taxable||0),0),cg=it.reduce((a,i)=>a+(i.cgst||0),0),sg=it.reduce((a,i)=>a+(i.sgst||0),0),ig=it.reduce((a,i)=>a+(i.igst||0),0),tx=cg+sg+ig,gr=sub+tx,ro=Math.round(gr)-gr;return{subtotal:sub,totalCGST:cg,totalSGST:sg,totalIGST:ig,totalTax:tx,grand:gr,roundOff:ro,grandRounded:Math.round(gr)};};
const numWords=n=>{const a=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"],b=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];const w=n=>{if(n<20)return a[n];if(n<100)return b[Math.floor(n/10)]+(n%10?" "+a[n%10]:"");if(n<1e3)return a[Math.floor(n/100)]+" Hundred"+(n%100?" and "+w(n%100):"");if(n<1e5)return w(Math.floor(n/1e3))+" Thousand"+(n%1e3?" "+w(n%1e3):"");if(n<1e7)return w(Math.floor(n/1e5))+" Lakh"+(n%1e5?" "+w(n%1e5):"");return w(Math.floor(n/1e7))+" Crore"+(n%1e7?" "+w(n%1e7):"");};const int=Math.floor(Math.abs(n||0)),dec=Math.round((Math.abs(n||0)-int)*100);return"Rupees "+w(int)+(dec?" and "+w(dec)+" Paise":"")+" Only";};

// ── Seed / Demo Data ─────────────────────────────────────────
const DEMO_BIZ={name:"Sharma Enterprises",type:"shop",isGstRegistered:true,gstin:"27AAFCS1234A1Z5",pan:"ABCDE1234F",phone:"9876543210",email:"sharma@business.com",address:{line1:"12 Market Road",city:"Pune",state:"Maharashtra",pin:"411001"},bank:{name:"SBI",account:"50200012345",ifsc:"SBIN0001234",upi:"sharma@upi"},invoicePrefix:"INV",invoiceCounter:1060,accentId:"teal",layout:"modern",showHSN:true,showQR:true,showBankDetails:true,showDiscount:true,footerNote:"Thank you for your business! 🙏",termsNote:"Goods once sold will not be taken back."};
const DEMO_CUSTS=[
  {id:"C001",name:"Ramu General Store",gstin:"",phone:"9898989898",email:"ramu@gmail.com",address:{city:"Pune",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"Weekly kirana orders",leadStatus:"converted",region:"Maharashtra",interactions:[]},
  {id:"C002",name:"Priya Consulting",gstin:"",phone:"9977665544",email:"priya@consulting.com",address:{city:"Bangalore",state:"Karnataka"},type:"customer",openingBalance:0,notes:"Monthly retainer",leadStatus:"converted",region:"Karnataka",interactions:[{id:"L1",date:dAgo(5),type:"call",note:"Discussed Q2 scope. Interested in SEO add-on."}]},
  {id:"C003",name:"Mohan Traders",gstin:"27AABCM9012C1Z1",phone:"9966554433",email:"mohan@traders.com",address:{city:"Pune",state:"Maharashtra"},type:"customer",openingBalance:5800,notes:"Bulk buyer",leadStatus:"converted",region:"Maharashtra",interactions:[]},
  {id:"C004",name:"Anita Clinic",gstin:"",phone:"9955443322",email:"",address:{city:"Nagpur",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"",leadStatus:"followup",region:"Maharashtra",interactions:[{id:"L2",date:dAgo(2),type:"meeting",note:"Needs medical billing features. Follow up next week."}]},
  {id:"C005",name:"Suresh Hardware",gstin:"27AADCS1234A1Z5",phone:"9944332211",email:"suresh@hw.com",address:{city:"Pune",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"",leadStatus:"inactive",region:"Maharashtra",interactions:[]},
  {id:"C006",name:"TechVista Solutions",gstin:"29AABCT5432B1Z3",phone:"9886543210",email:"accounts@techvista.com",address:{city:"Bangalore",state:"Karnataka"},type:"customer",openingBalance:0,notes:"IT firm, recurring project",leadStatus:"converted",region:"Karnataka",interactions:[]},
  {id:"C007",name:"Sunrise Retail Chain",gstin:"27AABCS7890C1Z4",phone:"9871234560",email:"purchase@sunriseretail.com",address:{city:"Mumbai",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"New bulk buyer potential",leadStatus:"inquiry",region:"Maharashtra",interactions:[{id:"L3",date:td(),type:"call",note:"Initial inquiry. Sending proforma today."}]},
];
const DEMO_ITEMS=[
  {id:"I001",name:"Basmati Rice 25kg",hsnCode:"1006",sacCode:"",barcode:"8901234567890",type:"product",gstRate:5,unit:"bag",salePrice:1800,purchasePrice:1400,stock:150,lowStock:20},
  {id:"I002",name:"Cooking Oil 5L",hsnCode:"1515",sacCode:"",barcode:"8901234567891",type:"product",gstRate:5,unit:"can",salePrice:650,purchasePrice:500,stock:80,lowStock:15},
  {id:"I003",name:"Wheat Flour 10kg",hsnCode:"1101",sacCode:"",barcode:"8901234567892",type:"product",gstRate:0,unit:"bag",salePrice:340,purchasePrice:270,stock:200,lowStock:30},
  {id:"I004",name:"Web Design Service",hsnCode:"",sacCode:"9983",barcode:"",type:"service",gstRate:18,unit:"hrs",salePrice:2500,purchasePrice:0,stock:0,lowStock:0},
  {id:"I005",name:"Toor Dal 1kg",hsnCode:"0713",sacCode:"",barcode:"8901234567893",type:"product",gstRate:0,unit:"kg",salePrice:120,purchasePrice:95,stock:300,lowStock:50},
  {id:"I006",name:"Printer Paper A4 Ream",hsnCode:"4802",sacCode:"",barcode:"8901234567894",type:"product",gstRate:12,unit:"box",salePrice:480,purchasePrice:360,stock:8,lowStock:10},
];
const DEMO_EMPS=[
  {id:"EMP001",name:"Rajesh Kumar",designation:"Sales Manager",phone:"9871112222",email:"rajesh@sharma.com",department:"Sales",joiningDate:"2022-04-01",salary:{basic:28000,hra:11200,travel:2000,special:3000,bonus:0,pf:3360,esi:0,tds:0,advance:0,other_d:0},attendance:{},salaryHistory:[]},
  {id:"EMP002",name:"Sunita Devi",designation:"Accountant",phone:"9872223333",email:"sunita@sharma.com",department:"Finance",joiningDate:"2021-06-15",salary:{basic:22000,hra:8800,travel:1500,special:2000,bonus:0,pf:2640,esi:0,tds:0,advance:0,other_d:0},attendance:{},salaryHistory:[]},
  {id:"EMP003",name:"Vikram Singh",designation:"Delivery Executive",phone:"9873334444",email:"",department:"Operations",joiningDate:"2023-01-10",salary:{basic:15000,hra:6000,travel:3000,special:0,bonus:0,pf:1800,esi:105,tds:0,advance:0,other_d:0},attendance:{},salaryHistory:[]},
];
const DEMO_EXPS=[
  {id:"E001",category:"Office Supplies",amount:2400,vendor:"Staples Store",date:dAgo(2),paymentMode:"Cash",notes:"Stationery"},
  {id:"E002",category:"Travel & Fuel",amount:800,vendor:"HP Petrol Pump",date:dAgo(5),paymentMode:"UPI",notes:"Fuel"},
  {id:"E003",category:"Utilities",amount:3200,vendor:"MSEDCL",date:dAgo(10),paymentMode:"UPI",notes:"Electricity"},
  {id:"E004",category:"Salary",amount:65000,vendor:"Payroll — April 2024",date:dAgo(15),paymentMode:"NEFT/RTGS",notes:"Monthly salaries"},
];
const mkInv=()=>([
  {id:"D1042",invoiceNumber:"INV-1042",type:"tax_invoice",hasGst:true,status:"paid",party:DEMO_CUSTS[2],items:[{id:"x",name:"Basmati Rice 25kg",hsnCode:"1006",sacCode:"",type:"product",gstRate:5,unit:"bag",qty:10,rate:1800,disc:0,taxable:18000,cgst:450,sgst:450,igst:0,taxAmt:900,lineTotal:18900}],subtotal:18000,totalCGST:450,totalSGST:450,totalIGST:0,totalTax:900,grand:18900,roundOff:0,grandRounded:18900,amountPaid:18900,paymentMode:"UPI",invoiceDate:dAgo(3),dueDate:addD(dAgo(3),30),notes:"Q3 restock",poNumber:"PO-887",createdAt:new Date(Date.now()-3*864e5).toISOString()},
  {id:"D1043",invoiceNumber:"BILL-1043",type:"simple_bill",hasGst:false,status:"paid",party:DEMO_CUSTS[0],items:[{id:"y",name:"Wheat Flour 10kg",hsnCode:"",sacCode:"",type:"product",gstRate:0,unit:"bag",qty:20,rate:340,disc:0,taxable:6800,cgst:0,sgst:0,igst:0,taxAmt:0,lineTotal:6800}],subtotal:6800,totalCGST:0,totalSGST:0,totalIGST:0,totalTax:0,grand:6800,roundOff:0,grandRounded:6800,amountPaid:6800,paymentMode:"Cash",invoiceDate:dAgo(5),dueDate:"",notes:"",poNumber:"",createdAt:new Date(Date.now()-5*864e5).toISOString()},
  {id:"D1044",invoiceNumber:"SRV-1044",type:"service_invoice",hasGst:false,status:"unpaid",party:DEMO_CUSTS[1],items:[{id:"z",name:"Web Design Service",hsnCode:"",sacCode:"9983",type:"service",gstRate:18,unit:"hrs",qty:12,rate:2500,disc:0,taxable:30000,cgst:0,sgst:0,igst:0,taxAmt:0,lineTotal:30000}],subtotal:30000,totalCGST:0,totalSGST:0,totalIGST:0,totalTax:0,grand:30000,roundOff:0,grandRounded:30000,amountPaid:0,paymentMode:"",invoiceDate:dAgo(12),dueDate:addD(dAgo(12),15),notes:"April retainer",poNumber:"PRJ-2024",createdAt:new Date(Date.now()-12*864e5).toISOString()},
  {id:"D1045",invoiceNumber:"INV-1045",type:"tax_invoice",hasGst:true,status:"overdue",party:DEMO_CUSTS[4],items:[{id:"a",name:"Basmati Rice 25kg",hsnCode:"1006",sacCode:"",type:"product",gstRate:5,unit:"bag",qty:25,rate:1800,disc:5,taxable:42750,cgst:1068.75,sgst:1068.75,igst:0,taxAmt:2137.5,lineTotal:44887.5}],subtotal:42750,totalCGST:1068.75,totalSGST:1068.75,totalIGST:0,totalTax:2137.5,grand:44887.5,roundOff:.5,grandRounded:44888,amountPaid:0,paymentMode:"",invoiceDate:dAgo(45),dueDate:addD(dAgo(45),30),notes:"",poNumber:"PO-219",createdAt:new Date(Date.now()-45*864e5).toISOString()},
  {id:"D1046",invoiceNumber:"INV-1046",type:"tax_invoice",hasGst:true,status:"partial",party:DEMO_CUSTS[3],items:[{id:"b",name:"Cooking Oil 5L",hsnCode:"1515",sacCode:"",type:"product",gstRate:5,unit:"can",qty:8,rate:650,disc:0,taxable:5200,cgst:130,sgst:130,igst:0,taxAmt:260,lineTotal:5460}],subtotal:5200,totalCGST:130,totalSGST:130,totalIGST:0,totalTax:260,grand:5460,roundOff:0,grandRounded:5460,amountPaid:3000,paymentMode:"Cheque",invoiceDate:dAgo(18),dueDate:addD(dAgo(18),30),notes:"Balance next month",poNumber:"",createdAt:new Date(Date.now()-18*864e5).toISOString()},
  {id:"D1054",invoiceNumber:"INV-1054",type:"tax_invoice",hasGst:true,status:"paid",party:DEMO_CUSTS[5],items:[{id:"c",name:"Software Implementation",hsnCode:"",sacCode:"9983",type:"service",gstRate:18,unit:"hrs",qty:40,rate:2800,disc:0,taxable:112000,cgst:0,sgst:0,igst:20160,taxAmt:20160,lineTotal:132160}],subtotal:112000,totalCGST:0,totalSGST:0,totalIGST:20160,totalTax:20160,grand:132160,roundOff:0,grandRounded:132160,amountPaid:132160,paymentMode:"NEFT/RTGS",invoiceDate:dAgo(7),dueDate:addD(dAgo(7),30),notes:"Inter-state IGST",poNumber:"TV-088",createdAt:new Date(Date.now()-7*864e5).toISOString()},
  {id:"D1058",invoiceNumber:"PRO-1058",type:"proforma",hasGst:true,status:"draft",party:DEMO_CUSTS[6],items:[{id:"d",name:"Basmati Rice 25kg Premium",hsnCode:"1006",sacCode:"",type:"product",gstRate:5,unit:"bag",qty:200,rate:1900,disc:3,taxable:368200,cgst:9205,sgst:9205,igst:0,taxAmt:18410,lineTotal:386610}],subtotal:368200,totalCGST:9205,totalSGST:9205,totalIGST:0,totalTax:18410,grand:386610,roundOff:0,grandRounded:386610,amountPaid:0,paymentMode:"",invoiceDate:td(),dueDate:addD(td(),3),notes:"30% advance to confirm.",poNumber:"",createdAt:new Date().toISOString()},
]);

// ╔══════════════════════════════════════════════════════════════╗
// ║  CSS  — Professional Light Theme                           ║
// ╚══════════════════════════════════════════════════════════════╝
const CSS=`
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#F0FAF7;--bg2:#FFFFFF;--bg3:#E8F5F1;--bg4:#D1EDE6;
  --bd:#C9E4DC;--bd2:#DCF0EA;
  --tx:#0A1F1A;--tx2:#1A3D35;--mu:#4A7A6D;--mu2:#7EADA3;
  --ac:#00897B;--ac2:#00695C;--acb:rgba(0,137,123,.09);--acbd:rgba(0,137,123,.24);
  --gr:#16A34A;--grb:rgba(22,163,74,.09);
  --re:#E53935;--reb:rgba(229,57,53,.08);
  --or:#F59E0B;--bl:#0284C7;--pu:#7C3AED;
  --r:14px;--rsm:9px;--rxs:6px;--rlg:18px;
  --sh0:0 1px 4px rgba(0,105,92,.07);--sh1:0 3px 10px rgba(0,105,92,.10);
  --sh2:0 6px 20px rgba(0,105,92,.13);--sh3:0 12px 40px rgba(0,105,92,.17);
  --shac:0 4px 20px rgba(0,137,123,.38);
}
html,body,#root{height:100%;background:var(--bg);font-family:'Plus Jakarta Sans','Segoe UI',sans-serif;color:var(--tx);-webkit-font-smoothing:antialiased}
input,select,textarea,button{font-family:inherit}
.app{display:flex;flex-direction:column;height:100dvh;max-width:640px;margin:0 auto;background:var(--bg);position:relative;overflow:hidden}
.page{flex:1;overflow-y:auto;padding:16px 16px 96px;-webkit-overflow-scrolling:touch;animation:pgIn .22s ease}
.ptit{font-size:20px;font-weight:900;color:var(--tx);letter-spacing:-.03em}
.slbl{font-size:10.5px;font-weight:800;color:var(--mu);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px}
.card{background:var(--bg2);border:1px solid var(--bd2);border-radius:var(--r);box-shadow:var(--sh0)}
.cardi{cursor:pointer;transition:box-shadow .15s,transform .12s,border-color .15s}.cardi:active{transform:scale(.98)!important;box-shadow:var(--sh0)!important}
.cardi:hover{box-shadow:var(--sh1);border-color:var(--bd);transform:translateY(-1px)}
.cardi:active{transform:translateY(0)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px 16px;border:1.5px solid var(--bd2);border-radius:var(--rsm);background:var(--bg2);color:var(--tx2);font-size:13px;font-weight:700;cursor:pointer;transition:all .15s;white-space:nowrap;font-family:inherit}
.btn:hover{border-color:var(--bd);background:var(--bg3)}
.btn:active{transform:scale(.98)}
.btn:disabled{opacity:.45;cursor:not-allowed;transform:none!important}
.btnp{background:var(--ac)!important;color:#fff!important;border-color:transparent!important;box-shadow:var(--shac)!important}
.btnp:hover{background:var(--ac2)!important}
.btng{background:transparent!important;border-color:transparent!important;color:var(--mu)!important}
.btng:hover{background:var(--bg3)!important;color:var(--tx2)!important}
.btnG{background:var(--gr)!important;color:#fff!important;border-color:transparent!important}
.btnR{background:var(--re)!important;color:#fff!important;border-color:transparent!important}
.btnsm{padding:6px 12px!important;font-size:12px!important;border-radius:7px!important}
.btnxs{padding:4px 9px!important;font-size:11px!important;border-radius:5px!important}
.inp{width:100%;padding:10px 13px;border:1.5px solid var(--bd);border-radius:var(--rsm);background:var(--bg2);color:var(--tx);font-size:13.5px;font-weight:500;outline:none;transition:border .15s,box-shadow .15s;font-family:inherit}
.inp:focus{border-color:var(--ac);box-shadow:0 0 0 3px var(--acb)}
textarea.inp{resize:vertical;min-height:68px}
.lbl{display:block;font-size:11px;font-weight:800;color:var(--mu);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px}
.tag{display:inline-flex;align-items:center;padding:3px 9px;border-radius:20px;font-size:10.5px;font-weight:800}
.tag-p{background:rgba(12,175,96,.12);color:#047857}
.tag-u{background:rgba(224,59,59,.1);color:var(--re)}
.tag-o{background:rgba(245,144,10,.12);color:#D97706}
.tag-d{background:rgba(148,163,184,.14);color:var(--mu)}
.tag-pt{background:rgba(139,92,246,.1);color:var(--pu)}
.pbadge{display:inline-flex;align-items:center;padding:2px 7px;border-radius:20px;font-size:9.5px;font-weight:900;background:linear-gradient(135deg,#00695C,#00BFA5);color:#fff}
.sbar{display:flex;align-items:center;gap:8px;padding:9px 13px;background:var(--bg2);border:1.5px solid var(--bd2);border-radius:var(--rsm);margin-bottom:12px;box-shadow:var(--sh0)}
.sbar input{border:none;background:transparent;outline:none;flex:1;font-size:13.5px;color:var(--tx);font-family:inherit;font-weight:500}
.sbar input::placeholder{color:var(--mu2)}
.fbar{display:flex;gap:7px;overflow-x:auto;padding-bottom:6px;scrollbar-width:none;position:sticky;top:0;z-index:10;background:var(--bg);padding-top:2px;margin-bottom:10px}
.fbar::-webkit-scrollbar{display:none}
.bnav{display:flex;background:#fff;border-top:1px solid #F0F0F0;padding:8px 0 env(safe-area-inset-bottom,8px);position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:640px;z-index:100;box-shadow:0 -4px 32px rgba(15,23,42,.10)}
.bnt{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;padding:4px 0;background:transparent;border:none;cursor:pointer;color:var(--mu);font-size:10px;font-weight:700;font-family:inherit;position:relative;transition:color .15s}
.bnt.on{color:var(--ac)}.bnt.on .bico{filter:drop-shadow(0 2px 8px var(--ac))}
.bico{font-size:22px;line-height:1;transition:transform .15s}
.bnt.on .bico{transform:scale(1.12)}
.bbdg{position:absolute;top:0;right:calc(50% - 18px);min-width:16px;height:16px;border-radius:8px;background:var(--re);color:#fff;font-size:9px;font-weight:900;display:flex;align-items:center;justify-content:center;padding:0 4px}
.fab{position:fixed;bottom:74px;right:16px;display:flex;flex-direction:column;align-items:flex-end;gap:8px;z-index:90}
@media(min-width:640px){.fab{right:calc(50% - 304px)}}
.fpill{display:inline-flex;align-items:center;gap:7px;padding:10px 18px;border-radius:30px;border:none;font-size:13px;font-weight:800;cursor:pointer;box-shadow:var(--sh2);transition:all .15s;font-family:inherit}
.fpill:hover{transform:translateY(-2px)}
.fmain{background:var(--ac);color:#fff;padding:14px 22px;box-shadow:var(--shac)}
.mbg{position:fixed;inset:0;background:rgba(15,23,42,.52);backdrop-filter:blur(4px);z-index:200;display:flex;align-items:flex-end;justify-content:center}
.mbg.ctr{align-items:center;padding:16px}
.msh{background:var(--bg2);border-radius:24px 24px 0 0;width:100%;max-width:640px;max-height:93dvh;overflow-y:auto}
.mctr{background:var(--bg2);border-radius:20px;width:100%;max-width:500px;max-height:93dvh;overflow-y:auto}
.mh{width:40px;height:4px;background:var(--bd);border-radius:2px;margin:12px auto 4px}
.mhdr{display:flex;align-items:center;justify-content:space-between;padding:12px 18px;border-bottom:1px solid var(--bd2);position:sticky;top:0;background:var(--bg2);z-index:1}
.pmmod{background:var(--bg2);border-radius:20px;width:100%;max-width:460px;overflow:hidden}
.pmhero{background:linear-gradient(135deg,#002E27 0%,#00695C 50%,#00BFA5 100%);padding:32px 24px 28px;text-align:center}
.ub{display:flex;align-items:center;gap:12px;padding:14px 16px;background:linear-gradient(120deg,#003D35,#00695C,#00BFA5);border-radius:14px;cursor:pointer;position:relative;overflow:hidden;margin-bottom:16px;transition:transform .15s,box-shadow .15s}
.ub:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(0,137,123,.45)}
.ubglow{position:absolute;top:-50%;right:-5%;width:80px;height:200%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.07),transparent);transform:skewX(-20deg);pointer-events:none}
.ubt{flex:1}.ubt1{font-size:14px;font-weight:900;color:#fff}.ubt2{font-size:11px;color:rgba(255,255,255,.6);margin-top:2px}
.ubcta{background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.3);color:#fff;padding:7px 14px;border-radius:20px;font-size:12px;font-weight:800;cursor:pointer;font-family:inherit;white-space:nowrap}
.ubcta:hover{background:rgba(255,255,255,.28)}
.kgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px}
.kbox{background:var(--bg2);border:1px solid var(--bd2);border-radius:var(--r);padding:14px;box-shadow:var(--sh0);transition:all .15s;cursor:pointer}
.kbox:hover{box-shadow:var(--sh1);transform:translateY(-1px)}
.kv{font-size:20px;font-weight:900;letter-spacing:-.03em;margin:4px 0 2px}
.kl{font-size:10.5px;font-weight:700;color:var(--mu);text-transform:uppercase;letter-spacing:.05em}
.attg{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.attc{aspect-ratio:1;border-radius:6px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:10px;font-weight:700;cursor:pointer;border:1px solid var(--bd2);background:var(--bg3);transition:all .12s}
.attc.P{background:rgba(12,175,96,.15);color:#047857;border-color:rgba(12,175,96,.3)}
.attc.A{background:rgba(224,59,59,.1);color:var(--re);border-color:rgba(224,59,59,.25)}
.attc.H{background:rgba(245,144,10,.1);color:#D97706;border-color:rgba(245,144,10,.3)}
.attc.wk{opacity:.35;cursor:default}
.ilog{padding:10px 12px;background:var(--bg3);border-radius:10px;border-left:3px solid var(--ac);margin-bottom:8px}
.khb{flex:1;padding:9px;border-radius:8px;border:1.5px solid;font-size:12.5px;font-weight:800;cursor:pointer;font-family:inherit;transition:all .15s}
.khin{border-color:var(--gr);color:var(--gr);background:var(--grb)}.khin:hover{background:var(--gr);color:#fff}
.khout{border-color:var(--re);color:var(--re);background:var(--reb)}.khout:hover{background:var(--re);color:#fff}
.toast{position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;pointer-events:none;animation:fi .2s ease}
.out{background:linear-gradient(135deg,#00897B,#26C6A6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.su{animation:su .35s cubic-bezier(.16,1,.3,1)}
.div{display:flex;align-items:center;gap:10px;margin:14px 0}.div::before,.div::after{content:'';flex:1;height:1px;background:var(--bd2)}
.authcard{background:var(--bg2);border-radius:20px;padding:32px 28px;width:100%;max-width:420px;box-shadow:var(--sh3)}
.adiv{display:flex;align-items:center;gap:10px;margin:16px 0}.adiv::before,.adiv::after{content:'';flex:1;height:1px;background:var(--bd2)}
@media print{.np{display:none!important}.po{display:block!important}}.po{display:none}
.qaico{transition:transform .15s,box-shadow .15s}.qaico:active{transform:scale(.92)}.hdr-hero{background:linear-gradient(135deg,var(--ac) 0%,var(--ac2) 100%)}
@keyframes su{from{transform:translateY(40px);opacity:0}to{transform:translateY(0);opacity:1}}@keyframes pgIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes bou{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@keyframes fi{from{opacity:0}to{opacity:1}}
`;

// ── Atoms ────────────────────────────────────────────────────
const SBadge=({s})=>{const m={paid:"tag-p",unpaid:"tag-u",overdue:"tag-o",draft:"tag-d",partial:"tag-pt"};const l={paid:"✓ Paid",unpaid:"Unpaid",overdue:"Overdue",draft:"Draft",partial:"Partial"};return <span className={`tag ${m[s]||"tag-d"}`}>{l[s]||s}</span>;};
const Toast=({msg,type})=>(<div className="toast"><div style={{padding:"11px 20px",background:type==="err"?"#E03B3B":type==="warn"?"#F5900A":"#0CAF60",borderRadius:12,fontSize:13,fontWeight:700,color:"#fff",boxShadow:"0 8px 32px rgba(0,0,0,.25)",display:"flex",alignItems:"center",gap:8}}>{type==="err"?"✗":type==="warn"?"⚠":"✓"} {msg}</div></div>);
const Empty=({icon,title,sub,cta,onCta})=>(<div style={{textAlign:"center",padding:"52px 20px"}}><div style={{fontSize:56,marginBottom:12,lineHeight:1}}>{icon}</div><div style={{fontSize:16,fontWeight:800,marginBottom:6}}>{title}</div><div style={{fontSize:12.5,color:"var(--mu)",marginBottom:22,lineHeight:1.6}}>{sub}</div>{cta&&<button className="btn btnp" onClick={onCta}>{cta}</button>}</div>);
const Chip=({label,active,onClick,col})=>(<button onClick={onClick} style={{padding:"5px 13px",borderRadius:20,border:`1.5px solid ${active?(col||"var(--ac)"):"var(--bd2)"}`,background:active?(col?col+"16":"var(--acb)"):"var(--bg2)",color:active?(col||"var(--ac)"):"var(--mu)",fontWeight:700,fontSize:11.5,cursor:"pointer",fontFamily:"inherit",transition:"all .15s",whiteSpace:"nowrap",flexShrink:0}}>{label}</button>);
const Spin=({size=18,li})=>(<div style={{width:size,height:size,border:`2.5px solid ${li?"rgba(255,255,255,.25)":"var(--bd)"}`,borderTop:`2.5px solid ${li?"#fff":"var(--ac)"}`,borderRadius:"50%",animation:"spin .7s linear infinite",flexShrink:0}}/>);
const LeadBadge=({s})=>{const ld=LEADS.find(x=>x.id===s)||LEADS[0];return <span style={{display:"inline-flex",alignItems:"center",padding:"3px 10px",borderRadius:20,fontSize:10.5,fontWeight:800,background:ld.bg,color:ld.c}}>{ld.l}</span>;};
const Toggle=({on,onT,label})=>(<button onClick={onT} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:on?"var(--grb)":"var(--bg3)",border:`1.5px solid ${on?"rgba(12,175,96,.3)":"var(--bd2)"}`,borderRadius:10,cursor:"pointer",fontFamily:"inherit",width:"100%"}}><div style={{width:38,height:22,background:on?"var(--gr)":"var(--mu2)",borderRadius:11,position:"relative",flexShrink:0,transition:"background .2s"}}><div style={{position:"absolute",top:3,left:on?18:3,width:16,height:16,borderRadius:"50%",background:"#fff",transition:"left .2s",boxShadow:"0 1px 3px rgba(0,0,0,.2)"}}/></div>{label&&<span style={{fontWeight:700,fontSize:13}}>{label}</span>}</button>);

// ── Auth Screen ──────────────────────────────────────────────
const AuthScreen=({onAuth})=>{
  const [mode,setMode]=useState("login");
  const [email,setEmail]=useState(""),[pw,setPw]=useState(""),[name,setName]=useState("");
  const [loading,setL]=useState(false),[err,setErr]=useState(""),[msg,setMsg]=useState("");
  const submit=async()=>{
    if(!email.trim()){setErr("Enter your email");return;}
    setErr("");setL(true);
    const sb=await getSB();
    if(!sb){onAuth({id:"demo",email:"demo@billbharat.app",name:"Demo User",isDemo:true});return;}
    try{
      if(mode==="forgot"){await sb.auth.resetPasswordForEmail(email,{redirectTo:window.location.origin+"?reset=1"});setMsg("Reset email sent!");setL(false);return;}
      if(mode==="signup"){const{data,error}=await sb.auth.signUp({email,password:pw,options:{data:{full_name:name}}});if(error)throw error;onAuth(data.user);}
      else{const{data,error}=await sb.auth.signInWithPassword({email,password:pw});if(error)throw error;onAuth(data.user);}
    }catch(e){setErr(e.message||"Auth failed");}
    setL(false);
  };
  const gAuth=async()=>{const sb=await getSB();if(!sb){onAuth({id:"demo",email:"demo@billbharat.app",name:"Demo User",isDemo:true});return;}await sb.auth.signInWithOAuth({provider:"google",options:{redirectTo:window.location.origin}});};
  return(
    <div style={{minHeight:"100vh",background:"linear-gradient(135deg,#F8F9FA,#EEF2FF 60%,#F0F9FF)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <style>{CSS}</style>
      <div style={{width:"100%",maxWidth:420}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{fontSize:52,marginBottom:10,filter:"drop-shadow(0 4px 16px rgba(74,58,255,.25))"}}>💼</div>
          <div style={{fontSize:30,fontWeight:900,letterSpacing:"-.04em"}}><span className="out">BillBharat</span></div>
          <div style={{fontSize:13.5,color:"var(--mu)",marginTop:5}}>India's Smart Business Suite</div>
        </div>
        <div className="authcard su">
          <div style={{fontWeight:900,fontSize:19,marginBottom:4}}>{mode==="login"?"Welcome back 👋":mode==="signup"?"Create your account 🚀":"Reset password 🔑"}</div>
          <div style={{fontSize:12.5,color:"var(--mu)",marginBottom:22,lineHeight:1.5}}>{mode==="login"?"Sign in to manage your business":"Join thousands of Indian SMEs"}</div>
          {err&&<div style={{padding:"10px 14px",background:"var(--reb)",border:"1px solid rgba(224,59,59,.25)",borderRadius:9,fontSize:12.5,color:"var(--re)",marginBottom:14,fontWeight:600}}>⚠ {err}</div>}
          {msg&&<div style={{padding:"10px 14px",background:"var(--grb)",border:"1px solid rgba(12,175,96,.25)",borderRadius:9,fontSize:12.5,color:"var(--gr)",marginBottom:14,fontWeight:600}}>✓ {msg}</div>}
          {mode==="signup"&&<div style={{marginBottom:12}}><label className="lbl">Full Name</label><input className="inp" value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name" autoFocus/></div>}
          <div style={{marginBottom:12}}><label className="lbl">Email Address</label><input className="inp" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@business.com" onKeyDown={e=>e.key==="Enter"&&submit()}/></div>
          {mode!=="forgot"&&<div style={{marginBottom:20}}><label className="lbl">Password</label><input className="inp" type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder="••••••••" onKeyDown={e=>e.key==="Enter"&&submit()}/></div>}
          <button className="btn btnp" style={{width:"100%",padding:13,fontSize:14,borderRadius:10,marginBottom:10}} onClick={submit} disabled={loading}>
            {loading?<><Spin size={16} li/> Processing...</>:mode==="login"?"Sign In →":mode==="signup"?"Create Account →":"Send Reset Email"}
          </button>
          {mode!=="forgot"&&<>
            <div className="adiv"><span style={{fontSize:12,color:"var(--mu)",fontWeight:600}}>or continue with</span></div>
            <button className="btn" style={{width:"100%",padding:11,borderRadius:10,marginBottom:10,gap:10}} onClick={gAuth}>
              <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
              Continue with Google
            </button>
            <button className="btn" style={{width:"100%",padding:11,borderRadius:10,marginBottom:14,background:"var(--bg3)"}} onClick={()=>onAuth({id:"demo",email:"demo@billbharat.app",name:"Demo User",isDemo:true})}>🎮 Try Demo Mode</button>
          </>}
          <div style={{textAlign:"center",fontSize:12,color:"var(--mu)"}}>
            {mode==="login"&&<><span>No account? </span><button onClick={()=>{setMode("signup");setErr("");}} style={{background:"none",border:"none",color:"var(--ac)",fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:12}}>Sign Up</button></>}
            {mode==="signup"&&<><span>Have account? </span><button onClick={()=>{setMode("login");setErr("");}} style={{background:"none",border:"none",color:"var(--ac)",fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:12}}>Sign In</button></>}
            {mode==="login"&&<><br/><button onClick={()=>{setMode("forgot");setErr("");}} style={{background:"none",border:"none",color:"var(--mu)",fontWeight:600,cursor:"pointer",fontFamily:"inherit",fontSize:11.5,marginTop:6}}>Forgot password?</button></>}
            {mode==="forgot"&&<button onClick={()=>{setMode("login");setErr("");}} style={{background:"none",border:"none",color:"var(--ac)",fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:12}}>← Back to Sign In</button>}
          </div>
        </div>
        <div style={{textAlign:"center",marginTop:20,fontSize:11,color:"var(--mu2)"}}>🔒 Secured by Supabase · DPDP compliant</div>
      </div>
    </div>
  );
};

// ── Premium Paywall ──────────────────────────────────────────
const PremModal=({onClose,onActivate})=>{
  const [showCode,setSC]=useState(false),[code,setCode]=useState("");
  const [promo,setPromo]=useState(""),[promoA,setPA]=useState(null),[promoErr,setPE]=useState("");
  const [paying,setPaying]=useState(false),[cErr,setCE]=useState("");
  const BASE=79;const final=promoA?Math.round(BASE*(1-promoA.disc/100)):BASE;
  const applyP=()=>{const p=PROMOS[promo.trim().toUpperCase()];if(p){setPA(p);setPE("");}else{setPE("Invalid code");setTimeout(()=>setPE(""),2500);}};
  const tryCode=()=>{if(code.trim()==="797979")onActivate();else{setCE("Invalid code");setTimeout(()=>setCE(""),2000);}};
  const pay=async()=>{
    setPaying(true);const ok=await loadRZP();
    if(!ok){alert("Payment gateway unavailable. Check internet.");setPaying(false);return;}
    try{new window.Razorpay({key:RZP_KEY,amount:final*100,currency:"INR",name:"BillBharat",description:"Premium ₹"+final+"/month"+(promoA?" ("+promoA.label+")":""),handler:r=>{if(r.razorpay_payment_id)onActivate();},theme:{color:"#4A3AFF"},modal:{ondismiss:()=>setPaying(false)}}).open();}catch(e){alert("Payment error: "+e.message);}
    setPaying(false);
  };
  const feats=[{i:"🖨️",l:"Thermal Print",s:"80mm POS printing"},{i:"💎",l:"Luxury Templates",s:"Premium designs"},{i:"🤖",l:"AI CA Assistant",s:"GST & tax guidance"},{i:"📊",l:"Excel Export",s:"One-click export"},{i:"📋",l:"e-Invoice",s:"GST portal sync"},{i:"🔄",l:"Tally Export",s:"XML data export"}];
  return(
    <div className="mbg ctr" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="pmmod">
        <div className="pmhero">
          <button onClick={onClose} style={{position:"absolute",top:14,right:16,background:"rgba(255,255,255,.12)",border:"none",borderRadius:"50%",width:30,height:30,cursor:"pointer",color:"#fff",fontSize:14,display:"grid",placeItems:"center",zIndex:1}}>✕</button>
          <div style={{position:"relative",zIndex:1}}>
            <div style={{fontSize:48,marginBottom:8,filter:"drop-shadow(0 4px 16px rgba(255,200,0,.4))"}}>👑</div>
            <div style={{fontSize:22,fontWeight:900,color:"#fff",marginBottom:4}}>Go Premium</div>
            <div style={{fontSize:13,color:"rgba(255,255,255,.65)",marginBottom:16}}>Unlock BillBharat's full power</div>
            {promoA&&<div style={{fontSize:11,color:"rgba(255,255,255,.5)",textDecoration:"line-through",marginBottom:2}}>₹{BASE}/month</div>}
            <div style={{display:"inline-flex",alignItems:"baseline",gap:4}}><span style={{fontSize:40,fontWeight:900,color:"#FFD700"}}>₹{final}</span><span style={{fontSize:14,color:"rgba(255,255,255,.6)"}}>/month</span></div>
            {promoA&&<div style={{fontSize:12,color:"#86efac",marginTop:4}}>🎉 {promoA.label} applied!</div>}
          </div>
        </div>
        <div style={{padding:"20px 20px 24px"}}>
          {!promoA?(<div style={{marginBottom:14}}>
            <div style={{display:"flex",gap:8}}><input className="inp" value={promo} onChange={e=>setPromo(e.target.value)} placeholder="Promo code (e.g. LAUNCH50)" style={{flex:1,fontSize:13}} onKeyDown={e=>e.key==="Enter"&&applyP()}/><button className="btn btnp btnsm" onClick={applyP}>Apply</button></div>
            {promoErr&&<div style={{fontSize:11.5,color:"var(--re)",marginTop:5,fontWeight:600}}>✗ {promoErr}</div>}
          </div>):(
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"9px 12px",background:"var(--grb)",border:"1px solid rgba(12,175,96,.25)",borderRadius:8,marginBottom:14}}>
              <span style={{fontSize:12.5,fontWeight:700,color:"var(--gr)"}}>✓ {promoA.label}</span>
              <button onClick={()=>{setPA(null);setPromo("");}} style={{background:"none",border:"none",cursor:"pointer",color:"var(--mu)",fontSize:14}}>✕</button>
            </div>
          )}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
            {feats.map(f=><div key={f.l} style={{display:"flex",gap:9,alignItems:"flex-start",padding:"10px 11px",background:"var(--bg3)",borderRadius:10,border:"1px solid var(--bd2)"}}><span style={{fontSize:20,flexShrink:0}}>{f.i}</span><div><div style={{fontSize:11.5,fontWeight:800,lineHeight:1.2}}>{f.l}</div><div style={{fontSize:10.5,color:"var(--mu)",marginTop:2}}>{f.s}</div></div></div>)}
          </div>
          <button className="btn btnp" style={{width:"100%",padding:13,fontSize:14,borderRadius:11,marginBottom:10}} onClick={pay} disabled={paying}>
            {paying?<><Spin size={16} li/> Processing...</>:`🚀 Pay ₹${final}/month via Razorpay`}
          </button>
          {!showCode&&<button onClick={()=>setSC(true)} style={{width:"100%",padding:9,background:"transparent",border:"none",cursor:"pointer",color:"var(--mu)",fontSize:12.5,fontFamily:"inherit",fontWeight:600}}>Have an activation code?</button>}
          {showCode&&<div style={{marginTop:8}}>
            <div style={{display:"flex",gap:8}}><input className="inp" value={code} onChange={e=>setCode(e.target.value)} placeholder="Activation code" onKeyDown={e=>e.key==="Enter"&&tryCode()} autoFocus style={{flex:1}}/><button className="btn btnp btnsm" onClick={tryCode}>Activate</button></div>
            {cErr&&<div style={{fontSize:11.5,color:"var(--re)",marginTop:5,fontWeight:600}}>✗ {cErr}</div>}
          </div>}
        </div>
      </div>
    </div>
  );
};

// ── Invoice Print — 5 Templates ──────────────────────────────
const InvPrint=({inv,biz,tmpl})=>{
  if(!inv||!biz)return null;
  const aObj=ACCENTS.find(a=>a.id===(biz.accentId||"indigo"))||ACCENTS[0];
  const ac=aObj.h,acd=aObj.d;
  const t=tmpl||biz.layout||"modern";
  const isG=inv.hasGst&&biz.isGstRegistered;
  const docL=DTYPES.find(d=>d.id===inv.type)?.l||"Invoice";
  const sHSN=isG&&biz.showHSN!==false;
  const sDis=biz.showDiscount!==false&&(inv.items||[]).some(i=>+i.disc>0);
  const sQR=biz.showQR!==false&&biz.bank?.upi;
  const hasTax=isG&&(inv.totalTax||0)>0;
  const ff="'Plus Jakarta Sans','Segoe UI',Arial,sans-serif";
  const hsn=Object.values((inv.items||[]).reduce((m,i)=>{const h=i.hsnCode||i.sacCode||"NA";if(!m[h])m[h]={hsn:h,taxable:0,cgst:0,sgst:0,igst:0,rate:i.gstRate||0};m[h].taxable+=i.taxable||0;m[h].cgst+=i.cgst||0;m[h].sgst+=i.sgst||0;m[h].igst+=i.igst||0;return m;},{}));

  if(t==="thermal"){const mf="'Courier New',Courier,monospace";return(<div style={{fontFamily:mf,fontSize:"9pt",color:"#000",background:"#fff",width:"80mm",padding:"4mm 3mm",margin:"0 auto"}}>
    <div style={{textAlign:"center",borderBottom:"1px dashed #000",paddingBottom:"3mm",marginBottom:"3mm"}}><div style={{fontSize:"13pt",fontWeight:900}}>{biz.name}</div>{biz.address?.city&&<div style={{fontSize:"8pt"}}>{biz.address.city}</div>}{biz.phone&&<div style={{fontSize:"8pt"}}>Ph: {biz.phone}</div>}{isG&&biz.gstin&&<div style={{fontSize:"8pt"}}>GSTIN: {biz.gstin}</div>}</div>
    <div style={{textAlign:"center",fontSize:"11pt",fontWeight:900,marginBottom:"2mm"}}>{docL.toUpperCase()}</div>
    <div style={{fontSize:"8pt",borderBottom:"1px dashed #000",paddingBottom:"2mm",marginBottom:"2mm"}}><div>No: {inv.invoiceNumber}</div><div>Date: {inv.invoiceDate}</div>{inv.party?.name&&<div>Party: {inv.party.name}</div>}</div>
    <div style={{borderBottom:"1px dashed #000",paddingBottom:"2mm",marginBottom:"2mm"}}>
      <div style={{display:"flex",fontWeight:900,fontSize:"8.5pt",borderBottom:"1px solid #000",paddingBottom:"1mm",marginBottom:"1mm"}}><span style={{flex:1}}>Item</span><span style={{width:"14mm",textAlign:"right"}}>Qty</span><span style={{width:"20mm",textAlign:"right"}}>Amt</span></div>
      {(inv.items||[]).map((it,i)=><div key={i} style={{marginBottom:"1.5mm"}}><div style={{fontSize:"8.5pt",fontWeight:700}}>{it.name}</div><div style={{display:"flex",fontSize:"8pt"}}><span style={{flex:1,color:"#555"}}>{isG?`GST ${it.gstRate||0}%`:""}</span><span style={{width:"14mm",textAlign:"right"}}>{fmtN(it.qty)}</span><span style={{width:"20mm",textAlign:"right"}}>₹{fmtN(it.lineTotal)}</span></div></div>)}
    </div>
    <div style={{fontSize:"8.5pt"}}>{hasTax&&inv.totalCGST>0&&<><div style={{display:"flex",justifyContent:"space-between"}}><span>CGST</span><span>₹{fmtN(inv.totalCGST)}</span></div><div style={{display:"flex",justifyContent:"space-between"}}><span>SGST</span><span>₹{fmtN(inv.totalSGST)}</span></div></>}{hasTax&&inv.totalIGST>0&&<div style={{display:"flex",justifyContent:"space-between"}}><span>IGST</span><span>₹{fmtN(inv.totalIGST)}</span></div>}</div>
    <div style={{borderTop:"2px solid #000",marginTop:"2mm",paddingTop:"2mm",display:"flex",justifyContent:"space-between",fontSize:"12pt",fontWeight:900}}><span>TOTAL</span><span>₹{fmtN(inv.grandRounded)}</span></div>
    {inv.amountPaid>0&&<div style={{fontSize:"8.5pt",marginTop:"2mm"}}><div style={{display:"flex",justifyContent:"space-between"}}><span>Paid</span><span>₹{fmtN(inv.amountPaid)}</span></div><div style={{display:"flex",justifyContent:"space-between",fontWeight:700}}><span>Balance</span><span>₹{fmtN((inv.grandRounded||0)-inv.amountPaid)}</span></div></div>}
    <div style={{textAlign:"center",borderTop:"1px dashed #000",paddingTop:"3mm",marginTop:"3mm",fontSize:"8pt"}}>{biz.bank?.upi&&<div>UPI: {biz.bank.upi}</div>}<div style={{marginTop:"2mm"}}>{biz.footerNote||"Thank you!"}</div></div>
  </div>);}

  if(t==="gst_tally"){return(<div style={{fontFamily:"'Courier New',monospace",fontSize:"10pt",color:"#000",background:"#fff",padding:"8mm",width:"100%",minHeight:"277mm",border:"1px solid #000"}}>
    <div style={{textAlign:"center",borderBottom:"2px solid #000",paddingBottom:"4mm",marginBottom:"4mm"}}><div style={{fontSize:"16pt",fontWeight:900}}>{biz.name}</div><div style={{fontSize:"9pt"}}>{[biz.address?.line1,biz.address?.city,biz.address?.state,biz.address?.pin].filter(Boolean).join(", ")}</div>{biz.phone&&<div style={{fontSize:"9pt"}}>Ph: {biz.phone}</div>}{isG&&biz.gstin&&<div style={{fontSize:"9pt",fontWeight:700}}>GSTIN: {biz.gstin}</div>}</div>
    <div style={{textAlign:"center",fontSize:"13pt",fontWeight:900,border:"2px solid #000",padding:"3mm",marginBottom:"4mm"}}>{docL.toUpperCase()}</div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"4mm",marginBottom:"4mm",fontSize:"9pt"}}>
      <div style={{border:"1px solid #000",padding:"3mm"}}><div style={{fontWeight:700,textDecoration:"underline",marginBottom:3}}>BILL TO:</div><div style={{fontWeight:700}}>{inv.party?.name||"—"}</div>{inv.party?.address?.city&&<div>{inv.party.address.city}, {inv.party.address.state}</div>}{inv.party?.gstin&&<div>GSTIN: {inv.party.gstin}</div>}</div>
      <div style={{border:"1px solid #000",padding:"3mm"}}><div style={{fontWeight:700,textDecoration:"underline",marginBottom:3}}>INVOICE:</div><div>No: {inv.invoiceNumber}</div><div>Date: {inv.invoiceDate}</div>{inv.dueDate&&<div>Due: {inv.dueDate}</div>}{inv.poNumber&&<div>PO: {inv.poNumber}</div>}</div>
    </div>
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:"9pt",marginBottom:"4mm"}}><thead><tr style={{background:"#000",color:"#fff"}}><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"left"}}>#</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"left"}}>Description</th>{sHSN&&<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"center"}}>HSN</th>}<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"center"}}>Qty</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Rate</th>{sDis&&<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"center"}}>Disc%</th>}<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Taxable</th>{isG&&<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"center"}}>GST%</th>}{isG&&<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Tax</th>}<th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Total</th></tr></thead>
    <tbody>{(inv.items||[]).map((it,i)=><tr key={i}><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"center"}}>{i+1}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm"}}>{it.name}</td>{sHSN&&<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"center"}}>{it.hsnCode||it.sacCode||"—"}</td>}<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"center"}}>{fmtN(it.qty)} {it.unit}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(it.rate)}</td>{sDis&&<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"center"}}>{it.disc||0}%</td>}<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(it.taxable)}</td>{isG&&<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"center"}}>{it.gstRate||0}%</td>}{isG&&<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(it.taxAmt)}</td>}<td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right",fontWeight:700}}>₹{fmtN(it.lineTotal)}</td></tr>)}</tbody></table>
    {isG&&hasTax&&<table style={{width:"100%",borderCollapse:"collapse",fontSize:"9pt",marginBottom:"4mm"}}><thead><tr style={{background:"#eee"}}><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"left"}}>HSN/SAC</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Taxable</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>CGST%</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>CGST Amt</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>SGST%</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>SGST Amt</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>IGST</th><th style={{border:"1px solid #000",padding:"2mm 3mm",textAlign:"right"}}>Total Tax</th></tr></thead><tbody>{hsn.map(r=><tr key={r.hsn}><td style={{border:"1px solid #ccc",padding:"2mm 3mm"}}>{r.hsn}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.taxable)}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>{r.rate/2}%</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.cgst)}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>{r.rate/2}%</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.sgst)}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.igst)}</td><td style={{border:"1px solid #ccc",padding:"2mm 3mm",textAlign:"right",fontWeight:700}}>₹{fmtN(r.cgst+r.sgst+r.igst)}</td></tr>)}</tbody></table>}
    <div style={{display:"flex",justifyContent:"flex-end",marginBottom:"4mm"}}><div style={{minWidth:"60mm",border:"2px solid #000",padding:"3mm",fontSize:"9.5pt"}}><div style={{display:"flex",justifyContent:"space-between",borderBottom:"1px solid #ccc",paddingBottom:2,marginBottom:3}}><span>Subtotal</span><span>₹{fmtN(inv.subtotal)}</span></div>{hasTax&&inv.totalCGST>0&&<><div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}><span>CGST</span><span>₹{fmtN(inv.totalCGST)}</span></div><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span>SGST</span><span>₹{fmtN(inv.totalSGST)}</span></div></>}{hasTax&&inv.totalIGST>0&&<div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span>IGST</span><span>₹{fmtN(inv.totalIGST)}</span></div>}<div style={{display:"flex",justifyContent:"space-between",fontWeight:900,fontSize:"12pt",borderTop:"2px solid #000",paddingTop:3}}><span>TOTAL</span><span>₹{fmtN(inv.grandRounded)}</span></div></div></div>
    <div style={{fontSize:"9pt",marginBottom:"4mm"}}><strong>Amount in Words:</strong> {numWords(inv.grandRounded)}</div>
    {biz.termsNote&&<div style={{fontSize:"8.5pt",color:"#555",borderTop:"1px solid #ccc",paddingTop:"3mm"}}><strong>Terms:</strong> {biz.termsNote}</div>}
  </div>);}

  if(t==="luxury"){return(<div style={{fontFamily:ff,fontSize:"10.5pt",color:"#1a1a2a",background:"#fff",padding:"10mm",width:"100%",minHeight:"277mm",position:"relative",border:`3px double ${ac}`}}>
    <div style={{position:"absolute",top:"8mm",left:"8mm",right:"8mm",bottom:"8mm",border:`1px solid ${ac}40`,borderRadius:4,pointerEvents:"none"}}/>
    <div style={{textAlign:"center",padding:"8mm 0 6mm",borderBottom:`2px solid ${ac}`}}><div style={{fontSize:"22pt",fontWeight:900,color:ac,letterSpacing:"0.05em"}}>{biz.name}</div><div style={{fontSize:"9pt",color:"#666",marginTop:3}}>{[biz.address?.line1,biz.address?.city,biz.address?.state].filter(Boolean).join(" · ")}{biz.gstin&&<> · GSTIN: {biz.gstin}</>}</div><div style={{marginTop:10,display:"inline-block",background:ac,color:"#fff",padding:"5px 24px",borderRadius:4,fontSize:"11pt",fontWeight:800,letterSpacing:"0.1em"}}>{docL.toUpperCase()}</div></div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"6mm",margin:"5mm 0"}}><div style={{padding:"4mm",border:`1px solid ${ac}40`,borderRadius:4}}><div style={{fontSize:"8pt",fontWeight:700,color:ac,textTransform:"uppercase",letterSpacing:".1em",marginBottom:4}}>Bill To</div><div style={{fontWeight:900,fontSize:"13pt"}}>{inv.party?.name||"—"}</div>{inv.party?.address?.city&&<div style={{fontSize:"9pt",color:"#666",marginTop:2}}>{inv.party.address.city}</div>}{isG&&inv.party?.gstin&&<div style={{fontSize:"8.5pt",color:"#555"}}>GSTIN: {inv.party.gstin}</div>}</div><div style={{padding:"4mm",border:`1px solid ${ac}40`,borderRadius:4,background:`${ac}06`,textAlign:"right"}}><div style={{fontSize:"8pt",fontWeight:700,color:ac,textTransform:"uppercase",letterSpacing:".1em",marginBottom:4}}>Details</div><div style={{fontSize:"8.5pt",color:"#555",lineHeight:1.8}}><strong>No:</strong> {inv.invoiceNumber}<br/><strong>Date:</strong> {inv.invoiceDate}{inv.dueDate&&<><br/><strong>Due:</strong> {inv.dueDate}</>}</div></div></div>
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:"9pt",marginBottom:"4mm"}}><thead><tr style={{background:ac,color:"#fff"}}><th style={{padding:"3mm 4mm",textAlign:"left"}}>#</th><th style={{padding:"3mm 4mm",textAlign:"left"}}>Description</th><th style={{padding:"3mm 4mm",textAlign:"right"}}>Qty</th><th style={{padding:"3mm 4mm",textAlign:"right"}}>Rate</th>{isG&&<th style={{padding:"3mm 4mm",textAlign:"right"}}>Tax</th>}<th style={{padding:"3mm 4mm",textAlign:"right"}}>Amount</th></tr></thead><tbody>{(inv.items||[]).map((it,i)=><tr key={i} style={{borderBottom:`1px solid ${ac}20`,background:i%2===0?"#fff":ac+"04"}}><td style={{padding:"3mm 4mm"}}>{i+1}</td><td style={{padding:"3mm 4mm",fontWeight:600}}>{it.name}{sHSN&&(it.hsnCode||it.sacCode)&&<div style={{fontSize:"8pt",color:"#888"}}>HSN/SAC: {it.hsnCode||it.sacCode}</div>}</td><td style={{padding:"3mm 4mm",textAlign:"right"}}>{fmtN(it.qty)} {it.unit}</td><td style={{padding:"3mm 4mm",textAlign:"right"}}>₹{fmtN(it.rate)}</td>{isG&&<td style={{padding:"3mm 4mm",textAlign:"right",color:ac}}>₹{fmtN(it.taxAmt)}</td>}<td style={{padding:"3mm 4mm",textAlign:"right",fontWeight:800}}>₹{fmtN(it.lineTotal)}</td></tr>)}</tbody></table>
    <div style={{display:"flex",justifyContent:"flex-end",marginBottom:"4mm"}}><div style={{minWidth:"65mm",padding:"4mm",border:`1.5px solid ${ac}`,borderRadius:6}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span>Subtotal</span><span>₹{fmtN(inv.subtotal)}</span></div>{hasTax&&<><div style={{display:"flex",justifyContent:"space-between",marginBottom:2,fontSize:"9pt",color:"#555"}}><span>GST</span><span>₹{fmtN(inv.totalTax)}</span></div></>}<div style={{display:"flex",justifyContent:"space-between",fontSize:"14pt",fontWeight:900,color:ac,borderTop:`2px solid ${ac}`,paddingTop:4}}><span>TOTAL</span><span>₹{fmtN(inv.grandRounded)}</span></div></div></div>
    {sQR&&<div style={{textAlign:"center",marginTop:"5mm"}}><img src={`https://api.qrserver.com/v1/create-qr-code/?size=72x72&data=upi://pay?pa=${biz.bank.upi}&am=${inv.grandRounded}&tn=${inv.invoiceNumber}&cu=INR`} alt="UPI" style={{width:72,height:72,border:`2px solid ${ac}`,borderRadius:4}}/><div style={{fontSize:"8pt",color:"#777",marginTop:3}}>UPI: {biz.bank.upi}</div></div>}
    <div style={{textAlign:"center",marginTop:"5mm",paddingTop:"4mm",borderTop:`1px solid ${ac}40`,fontSize:"8.5pt",color:"#777"}}>{biz.footerNote||"Thank you for your business!"}</div>
  </div>);}

  // Modern / Billbook
  const isBB=t==="billbook";
  return(<div style={{fontFamily:ff,fontSize:"10pt",color:"#111",background:"#fff",padding:isBB?"6mm 8mm":"10mm",width:"100%",minHeight:"277mm"}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"5mm",borderBottom:`3px solid ${ac}`,paddingBottom:"4mm"}}>
      <div><div style={{fontSize:isBB?"18pt":"20pt",fontWeight:900,color:ac}}>{biz.name}</div><div style={{fontSize:"8.5pt",color:"#555",lineHeight:1.7,marginTop:2}}>{[biz.address?.line1,biz.address?.city,biz.address?.state,biz.address?.pin].filter(Boolean).join(", ")}<br/>{biz.phone&&<span>Ph: {biz.phone}  </span>}{biz.email&&<span>Email: {biz.email}</span>}<br/>{isG&&biz.gstin&&<span style={{fontWeight:700}}>GSTIN: {biz.gstin}</span>}</div></div>
      <div style={{textAlign:"right"}}><div style={{background:ac,color:"#fff",padding:"4px 14px",borderRadius:4,fontSize:"11pt",fontWeight:800,marginBottom:6}}>{docL.toUpperCase()}</div><div style={{fontSize:"9pt",color:"#555",lineHeight:1.8}}><strong>No:</strong> {inv.invoiceNumber}<br/><strong>Date:</strong> {inv.invoiceDate}{inv.dueDate&&<><br/><strong>Due:</strong> {inv.dueDate}</>}{inv.poNumber&&<><br/><strong>PO:</strong> {inv.poNumber}</>}</div></div>
    </div>
    <div style={{marginBottom:"4mm",padding:"3mm 4mm",background:`${ac}08`,borderRadius:6,borderLeft:`3px solid ${ac}`}}><div style={{fontSize:"8pt",fontWeight:700,color:ac,textTransform:"uppercase",marginBottom:3}}>Bill To:</div><div style={{fontWeight:800,fontSize:"11pt"}}>{inv.party?.name||"—"}</div><div style={{fontSize:"8.5pt",color:"#555",lineHeight:1.7}}>{inv.party?.address?.city&&<span>{inv.party.address.city}, {inv.party.address.state}  </span>}{inv.party?.phone&&<span>Ph: {inv.party.phone}  </span>}{isG&&inv.party?.gstin&&<span>GSTIN: {inv.party.gstin}</span>}</div></div>
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:"9pt",marginBottom:"4mm"}}><thead><tr style={{background:ac,color:"#fff"}}><th style={{padding:"2.5mm 3mm",textAlign:"left"}}>#</th><th style={{padding:"2.5mm 3mm",textAlign:"left"}}>Item / Description</th>{sHSN&&<th style={{padding:"2.5mm 3mm",textAlign:"center"}}>HSN</th>}<th style={{padding:"2.5mm 3mm",textAlign:"center"}}>Qty</th><th style={{padding:"2.5mm 3mm",textAlign:"right"}}>Rate</th>{sDis&&<th style={{padding:"2.5mm 3mm",textAlign:"center"}}>Disc%</th>}{isG&&<th style={{padding:"2.5mm 3mm",textAlign:"right"}}>Taxable</th>}{isG&&<th style={{padding:"2.5mm 3mm",textAlign:"center"}}>GST%</th>}{isG&&<th style={{padding:"2.5mm 3mm",textAlign:"right"}}>Tax</th>}<th style={{padding:"2.5mm 3mm",textAlign:"right"}}>Total</th></tr></thead><tbody>{(inv.items||[]).map((it,i)=><tr key={i} style={{borderBottom:"1px solid #e5e7eb",background:i%2===0?"#fff":"#f9fafb"}}><td style={{padding:"2.5mm 3mm"}}>{i+1}</td><td style={{padding:"2.5mm 3mm",fontWeight:600}}>{it.name}</td>{sHSN&&<td style={{padding:"2.5mm 3mm",textAlign:"center",color:"#777"}}>{it.hsnCode||it.sacCode||"—"}</td>}<td style={{padding:"2.5mm 3mm",textAlign:"center"}}>{fmtN(it.qty)} {it.unit}</td><td style={{padding:"2.5mm 3mm",textAlign:"right"}}>₹{fmtN(it.rate)}</td>{sDis&&<td style={{padding:"2.5mm 3mm",textAlign:"center"}}>{it.disc||0}%</td>}{isG&&<td style={{padding:"2.5mm 3mm",textAlign:"right"}}>₹{fmtN(it.taxable)}</td>}{isG&&<td style={{padding:"2.5mm 3mm",textAlign:"center"}}>{it.gstRate||0}%</td>}{isG&&<td style={{padding:"2.5mm 3mm",textAlign:"right"}}>₹{fmtN(it.taxAmt)}</td>}<td style={{padding:"2.5mm 3mm",textAlign:"right",fontWeight:800}}>₹{fmtN(it.lineTotal)}</td></tr>)}</tbody></table>
    {isG&&hasTax&&<table style={{width:"55%",marginLeft:"auto",borderCollapse:"collapse",fontSize:"8.5pt",marginBottom:"4mm",border:"1px solid #ddd"}}><thead><tr style={{background:"#f3f4f6"}}><th style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"left"}}>HSN/SAC</th><th style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>Taxable</th><th style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>CGST</th><th style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>SGST</th><th style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>IGST</th></tr></thead><tbody>{hsn.map(r=><tr key={r.hsn}><td style={{border:"1px solid #ddd",padding:"2mm 3mm"}}>{r.hsn}</td><td style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.taxable)}</td><td style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.cgst)}</td><td style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.sgst)}</td><td style={{border:"1px solid #ddd",padding:"2mm 3mm",textAlign:"right"}}>₹{fmtN(r.igst)}</td></tr>)}</tbody></table>}
    <div style={{display:"flex",justifyContent:"flex-end",marginBottom:"4mm"}}><div style={{minWidth:"60mm"}}><div style={{display:"flex",justifyContent:"space-between",fontSize:"9pt",marginBottom:3}}><span>Subtotal</span><span>₹{fmtN(inv.subtotal)}</span></div>{hasTax&&inv.totalCGST>0&&<><div style={{display:"flex",justifyContent:"space-between",fontSize:"9pt",marginBottom:2}}><span>CGST</span><span>₹{fmtN(inv.totalCGST)}</span></div><div style={{display:"flex",justifyContent:"space-between",fontSize:"9pt",marginBottom:3}}><span>SGST</span><span>₹{fmtN(inv.totalSGST)}</span></div></>}{hasTax&&inv.totalIGST>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:"9pt",marginBottom:3}}><span>IGST</span><span>₹{fmtN(inv.totalIGST)}</span></div>}{inv.roundOff!==0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:"8.5pt",color:"#777",marginBottom:3}}><span>Round Off</span><span>₹{fmtN(inv.roundOff)}</span></div>}<div style={{display:"flex",justifyContent:"space-between",fontSize:"13pt",fontWeight:900,color:ac,borderTop:`2px solid ${ac}`,paddingTop:4}}><span>TOTAL</span><span>₹{fmtN(inv.grandRounded)}</span></div></div></div>
    <div style={{fontSize:"8.5pt",padding:"2.5mm 3mm",background:"#f9fafb",border:"1px solid #e5e7eb",borderRadius:4,marginBottom:"4mm"}}><strong>Amount in Words:</strong> {numWords(inv.grandRounded)}</div>
    {biz.showBankDetails!==false&&biz.bank?.name&&<div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"4mm"}}><div style={{fontSize:"8.5pt",color:"#555"}}><div style={{fontWeight:700,marginBottom:2}}>Bank Details:</div><div>{biz.bank.name}{biz.bank.account&&` · A/c: ${biz.bank.account}`}</div>{biz.bank.ifsc&&<div>IFSC: {biz.bank.ifsc}</div>}{biz.bank.upi&&<div>UPI: {biz.bank.upi}</div>}</div>{sQR&&<div style={{textAlign:"center"}}><img src={`https://api.qrserver.com/v1/create-qr-code/?size=65x65&data=upi://pay?pa=${biz.bank.upi}&am=${inv.grandRounded}&tn=${inv.invoiceNumber}&cu=INR`} alt="QR" style={{width:65,height:65,border:`1.5px solid ${ac}40`,borderRadius:3}}/><div style={{fontSize:"7pt",color:"#888",marginTop:2}}>Scan to Pay</div></div>}</div>}
    {biz.termsNote&&<div style={{fontSize:"8pt",color:"#777",marginBottom:"3mm",borderTop:"1px solid #e5e7eb",paddingTop:"2mm"}}><strong>Terms:</strong> {biz.termsNote}</div>}
    {inv.notes&&<div style={{fontSize:"8pt",color:"#555",marginBottom:"3mm"}}><strong>Notes:</strong> {inv.notes}</div>}
    <div style={{textAlign:"center",fontSize:"8.5pt",color:"#888",borderTop:`1px solid ${ac}30`,paddingTop:"3mm"}}>{biz.footerNote||"Thank you!"}</div>
  </div>);
};

// ── Invoice Modal ─────────────────────────────────────────────
const InvModal=({editing,onClose,onSave,biz,customers,items,isPrem,onUpgrade})=>{
  const isNew=!editing?.id;
  const [form,setForm]=useState(()=>{
    if(editing?.id)return{...editing};
    const dt=DTYPES.find(d=>d.id==="tax_invoice");
    const ctr=String(biz?.invoiceCounter||"1001");return{id:uid(),invoiceNumber:`${biz?.invoicePrefix||"INV"}-${ctr}`,type:"tax_invoice",hasGst:biz?.isGstRegistered&&!NO_GST_SET.has("tax_invoice"),status:"unpaid",party:null,items:[],amountPaid:0,paymentMode:"UPI",invoiceDate:td(),dueDate:addD(td(),30),notes:"",poNumber:"",template:biz?.layout||"modern",printSize:"a4"};
  });
  const [view,setView]=useState("form");
  const printRef=useRef(null);
  const sf=useCallback(p=>setForm(f=>({...f,...p})),[]);
  const noG=NO_GST_SET.has(form.type)||!form.hasGst;
  const calcI=useMemo(()=>calcLines(form.items||[],biz?.gstin,form.party?.gstin,noG),[form.items,biz?.gstin,form.party?.gstin,noG]);
  const tots=useMemo(()=>calcTotals(calcI),[calcI]);
  const setIF=(i,k,v)=>setForm(f=>({...f,items:f.items.map((it,idx)=>idx===i?{...it,[k]:v}:it)}));
  const addRow=()=>sf({items:[...(form.items||[]),{id:uid(),name:"",hsnCode:"",sacCode:"",barcode:"",type:"product",gstRate:18,unit:"pcs",qty:1,rate:0,disc:0}]});
  const remRow=i=>sf({items:form.items.filter((_,idx)=>idx!==i)});
  const save=()=>{const fi=calcLines(form.items||[],biz?.gstin,form.party?.gstin,noG);const t=calcTotals(fi);onSave({...form,...t,items:fi,createdAt:editing?.createdAt||new Date().toISOString()});};
  const doPrint=()=>{
    const el=printRef.current;if(!el){alert("Preview first then print.");return;}
    const w=window.open("","_blank","width=900,height=700");if(!w){alert("Allow popups to print.");return;}
    const gFont="<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap\"/>";
    const styles="*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Plus Jakarta Sans','Segoe UI',Arial,sans-serif;background:#fff;padding:0}@media print{@page{margin:8mm;size:A4}}";
    const html="<!DOCTYPE html><html><head><meta charset=\"utf-8\"/><title>"+form.invoiceNumber+"</title>"+gFont+"<style>"+styles+"</style></head><body>"+el.innerHTML+"</body></html>";
    w.document.write(html);
    w.document.close();
    setTimeout(()=>{w.focus();w.print();},800);
  };

  if(view==="preview"){
    const fi=calcLines(form.items||[],biz?.gstin,form.party?.gstin,noG);const t=calcTotals(fi);
    return(<div className="mbg" onClick={e=>e.target===e.currentTarget&&setView("form")}>
      <div className="msh" style={{maxHeight:"95dvh"}}>
        <div className="mh"/>
        <div style={{padding:"10px 16px",display:"flex",gap:8,justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid var(--bd2)"}}>
          <button className="btn btng btnsm" onClick={()=>setView("form")}>← Edit</button>
          <div style={{fontWeight:800,fontSize:13}}>Print Preview</div>
          <button className="btn btnp btnsm" onClick={doPrint}>🖨 Print</button>
        </div>
        <div style={{padding:10,background:"#e5e7eb",overflowY:"auto"}}>
          <div ref={printRef} className="po" id="printArea" style={{background:"#fff",borderRadius:8,overflow:"hidden",boxShadow:"0 4px 16px rgba(0,0,0,.12)"}}>
            <InvPrint inv={{...form,...t,items:fi}} biz={biz} tmpl={form.template||biz?.layout}/>
          </div>
          <div className="np" style={{background:"#fff",borderRadius:8,overflow:"hidden",boxShadow:"0 4px 16px rgba(0,0,0,.12)"}}>
            <InvPrint inv={{...form,...t,items:fi}} biz={biz} tmpl={form.template||biz?.layout}/>
          </div>
        </div>
      </div>
    </div>);
  }

  return(<div className="mbg" onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div className="msh">
      <div className="mh"/>
      <div className="mhdr"><div style={{fontWeight:900,fontSize:14}}>{isNew?"New Document":"Edit Document"}</div><div style={{display:"flex",gap:6}}><button className="btn btng btnxs" onClick={()=>setView("preview")}>👁 Preview</button><button className="btn btng btnxs" onClick={onClose}>✕</button></div></div>
      <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:14}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div><label className="lbl">Document Type</label><select className="inp" value={form.type} onChange={e=>{const t=e.target.value;sf({type:t,hasGst:biz?.isGstRegistered&&!NO_GST_SET.has(t)});}}>{DTYPES.map(d=><option key={d.id} value={d.id}>{d.i} {d.l}</option>)}</select></div>
          <div><label className="lbl">Invoice No.</label><input className="inp" value={form.invoiceNumber} onChange={e=>sf({invoiceNumber:e.target.value})}/></div>
        </div>
        {biz?.isGstRegistered&&!NO_GST_SET.has(form.type)&&<Toggle on={form.hasGst} onT={()=>sf({hasGst:!form.hasGst})} label={form.hasGst?"GST Invoice (with CGST/SGST/IGST)":"Simple Bill (no GST)"}/>}
        <div><label className="lbl">Customer / Party</label><select className="inp" value={form.party?.id||""} onChange={e=>sf({party:customers.find(c=>c.id===e.target.value)||null})}><option value="">— Select Party —</option>{customers.map(c=><option key={c.id} value={c.id}>{c.name}{c.gstin?` (${c.gstin})`:""}</option>)}</select></div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div><label className="lbl">Invoice Date</label><input className="inp" type="date" value={form.invoiceDate} onChange={e=>sf({invoiceDate:e.target.value})}/></div>
          <div><label className="lbl">Due Date</label><input className="inp" type="date" value={form.dueDate||""} onChange={e=>sf({dueDate:e.target.value})}/></div>
        </div>
        <div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}><label className="lbl" style={{marginBottom:0}}>Items / Services</label><button className="btn btnp btnxs" onClick={addRow}>+ Add Row</button></div>
          {(form.items||[]).length===0&&<div style={{textAlign:"center",padding:"20px",background:"var(--bg3)",borderRadius:10,fontSize:12.5,color:"var(--mu)"}}>No items yet. Click "+ Add Row".</div>}
          {(form.items||[]).map((it,i)=>(
            <div key={it.id||i} style={{background:"var(--bg3)",borderRadius:10,padding:"12px",marginBottom:8}}>
              <div style={{display:"flex",gap:8,marginBottom:8}}>
                <div style={{flex:1}}><label className="lbl">Item Name *</label><input className="inp" value={it.name} onChange={e=>setIF(i,"name",e.target.value)} placeholder="Item name"/></div>
                <button className="btn btng btnxs" style={{flexShrink:0,marginTop:20,color:"var(--re)"}} onClick={()=>remRow(i)}>✕</button>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:8}}>
                <div><label className="lbl">Qty</label><input className="inp" type="number" value={it.qty} onChange={e=>setIF(i,"qty",+e.target.value)}/></div>
                <div><label className="lbl">Rate (₹)</label><input className="inp" type="number" value={it.rate} onChange={e=>setIF(i,"rate",+e.target.value)}/></div>
                <div><label className="lbl">Disc %</label><input className="inp" type="number" value={it.disc||0} onChange={e=>setIF(i,"disc",+e.target.value)}/></div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                <div><label className="lbl">Unit</label><select className="inp" value={it.unit||"pcs"} onChange={e=>setIF(i,"unit",e.target.value)}>{UNITS.map(u=><option key={u} value={u}>{u}</option>)}</select></div>
                {form.hasGst&&<div><label className="lbl">GST %</label><select className="inp" value={it.gstRate||0} onChange={e=>setIF(i,"gstRate",+e.target.value)}>{GST_RATES.map(r=><option key={r} value={r}>{r}%</option>)}</select></div>}
                <div><label className="lbl">HSN/SAC</label><input className="inp" value={it.hsnCode||it.sacCode||""} onChange={e=>setIF(i,"hsnCode",e.target.value)} placeholder="1006"/></div>
              </div>
              {calcI[i]&&<div style={{marginTop:8,display:"flex",justifyContent:"space-between",fontSize:12,color:"var(--mu)",borderTop:"1px solid var(--bd2)",paddingTop:6}}>
                <span>Taxable: {fmt(calcI[i]?.taxable)}</span>{form.hasGst&&<span>Tax: {fmt(calcI[i]?.taxAmt)}</span>}<span style={{fontWeight:800,color:"var(--tx)"}}>Total: {fmt(calcI[i]?.lineTotal)}</span>
              </div>}
            </div>
          ))}
        </div>
        {(form.items||[]).length>0&&<div style={{padding:"12px 14px",background:"var(--bg3)",borderRadius:10}}>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:12.5,marginBottom:4}}><span style={{color:"var(--mu)"}}>Subtotal</span><span>{fmt(tots.subtotal)}</span></div>
          {tots.totalCGST>0&&<><div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:2}}><span style={{color:"var(--mu)"}}>CGST</span><span>{fmt(tots.totalCGST)}</span></div><div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:4}}><span style={{color:"var(--mu)"}}>SGST</span><span>{fmt(tots.totalSGST)}</span></div></>}
          {tots.totalIGST>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:4}}><span style={{color:"var(--mu)"}}>IGST</span><span>{fmt(tots.totalIGST)}</span></div>}
          <div style={{display:"flex",justifyContent:"space-between",fontSize:15,fontWeight:900,borderTop:"1.5px solid var(--bd)",paddingTop:6,color:"var(--ac)"}}><span>Total</span><span>{fmt(tots.grandRounded)}</span></div>
        </div>}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
          <div><label className="lbl">Status</label><select className="inp" value={form.status} onChange={e=>sf({status:e.target.value})}><option value="unpaid">Unpaid</option><option value="paid">Paid</option><option value="partial">Partial</option><option value="draft">Draft</option></select></div>
          <div><label className="lbl">Paid (₹)</label><input className="inp" type="number" value={form.amountPaid||0} onChange={e=>sf({amountPaid:+e.target.value})}/></div>
          <div><label className="lbl">Pay Mode</label><select className="inp" value={form.paymentMode||"Cash"} onChange={e=>sf({paymentMode:e.target.value})}>{PAY_MODES.map(m=><option key={m} value={m}>{m}</option>)}</select></div>
        </div>
        <div><label className="lbl">Template</label><div style={{display:"flex",gap:8,flexWrap:"wrap"}}>{TMPLS.map(t=><button key={t.id} onClick={()=>{if(t.p&&!isPrem){onUpgrade();return;}sf({template:t.id});}} style={{padding:"7px 14px",borderRadius:8,border:`1.5px solid ${form.template===t.id?"var(--ac)":"var(--bd2)"}`,background:form.template===t.id?"var(--acb)":"var(--bg2)",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:5,color:form.template===t.id?"var(--ac)":"var(--tx2)"}}>{t.i} {t.l}{t.p&&!isPrem&&<span className="pbadge">PRO</span>}</button>)}</div></div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div><label className="lbl">PO Number</label><input className="inp" value={form.poNumber||""} onChange={e=>sf({poNumber:e.target.value})} placeholder="PO-001"/></div>
          <div><label className="lbl">Recurring</label><select className="inp" value={form.recurring||""} onChange={e=>sf({recurring:e.target.value||null})}><option value="">None</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select></div>
        </div>
        <div><label className="lbl">Notes</label><textarea className="inp" rows={2} value={form.notes||""} onChange={e=>sf({notes:e.target.value})} placeholder="Additional notes..."/></div>
        <div style={{display:"flex",gap:10,paddingBottom:8}}>
          <button className="btn btng" style={{flex:1}} onClick={onClose}>Cancel</button>
          <button className="btn btnp" style={{flex:3}} onClick={save}>💾 {isNew?"Save Invoice":"Update Invoice"}</button>
        </div>
      </div>
    </div>
  </div>);
};

// ── 3D Logo Component ────────────────────────────────────────
const Logo3D=({size=40})=>(
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" style={{filter:"drop-shadow(0 4px 14px rgba(0,137,123,.55))"}}>
    <defs>
      <linearGradient id="lg1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse"><stop offset="0%" stopColor="#26C6A6"/><stop offset="100%" stopColor="#00695C"/></linearGradient>
      <linearGradient id="lg2" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#B2DFDB"/><stop offset="100%" stopColor="#80CBC4"/></linearGradient>
      <linearGradient id="lg3" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#004D40"/><stop offset="100%" stopColor="#00695C"/></linearGradient>
    </defs>
    <rect x="5" y="10" width="36" height="30" rx="6" fill="url(#lg1)"/>
    <path d="M5 10 L9 6 L45 6 L41 10 Z" fill="url(#lg2)" opacity="0.95"/>
    <path d="M41 10 L45 6 L45 36 L41 40 Z" fill="url(#lg3)" opacity="0.9"/>
    <text x="23" y="30" textAnchor="middle" fontSize="17" fontWeight="900" fill="white" fontFamily="system-ui">₹</text>
    <rect x="9" y="14" width="18" height="3" rx="1.5" fill="white" opacity="0.2"/>
  </svg>
);

// ── Quick Action Items ────────────────────────────────────────
const QA_ITEMS=[
  {i:"📄",l:"Invoices",c:"#00897B",bg:"#E0F2F1",p:"invoices"},
  {i:"📨",l:"e-Invoice",c:"#0288D1",bg:"#E1F5FE",p:"einvoice"},
  {i:"🚚",l:"e-Way Bill",c:"#F57C00",bg:"#FFF3E0",p:"ewaybill"},
  {i:"📝",l:"Proforma",c:"#7B1FA2",bg:"#F3E5F5",p:"proforma"},
  {i:"💵",l:"Receipt",c:"#388E3C",bg:"#E8F5E9",p:"payment_receipt"},
  {i:"💸",l:"Payments",c:"#C62828",bg:"#FFEBEE",p:"payments_made"},
  {i:"📉",l:"Debit Note",c:"#E65100",bg:"#FBE9E7",p:"debit_note"},
  {i:"📈",l:"Credit Note",c:"#1B5E20",bg:"#E8F5E9",p:"credit_note"},
  {i:"🚛",l:"Delivery",c:"#1565C0",bg:"#E3F2FD",p:"delivery_challan"},
  {i:"🛒",l:"Purchase",c:"#4527A0",bg:"#EDE7F6",p:"purchase"},
  {i:"🔖",l:"Refund Vchr",c:"#AD1457",bg:"#FCE4EC",p:"refund_voucher"},
  {i:"🏛️",l:"GSTR Filing",c:"#006064",bg:"#E0F7FA",p:"gstr"},
];
const MORE_ITEMS=[
  {i:"✍️",l:"Digital Sign",c:"#5C6BC0",bg:"#E8EAF6",p:"settings"},
  {i:"📦",l:"Inventory",c:"#F57C00",bg:"#FFF3E0",p:"items"},
  {i:"📒",l:"Ledgers",c:"#2E7D32",bg:"#E8F5E9",p:"ledgers"},
  {i:"📊",l:"Reports",c:"#C62828",bg:"#FFEBEE",p:"reports"},
  {i:"💸",l:"Expenses",c:"#6A1B9A",bg:"#F3E5F5",p:"expenses"},
  {i:"🤖",l:"AI Advisor",c:"#00838F",bg:"#E0F7FA",p:"askca"},
  {i:"🧮",l:"GST Calc",c:"#558B2F",bg:"#F1F8E9",p:"calculator"},
  {i:"👷",l:"Payroll",c:"#E65100",bg:"#FBE9E7",p:"payroll"},
];

// ── Dashboard ─────────────────────────────────────────────────
const Dashboard=({invoices,customers,items,expenses,biz,isPrem,onUpgrade,setPage,onNewInv})=>{
  const now=new Date();
  const mn=now.getMonth(),yr=now.getFullYear();
  const kpi=useMemo(()=>{
    const paid=invoices.filter(i=>i.status==="paid").reduce((a,i)=>a+i.grandRounded,0);
    const due=invoices.filter(i=>["unpaid","partial","overdue"].includes(i.status)).reduce((a,i)=>a+(i.grandRounded-(i.amountPaid||0)),0);
    const overdue=invoices.filter(i=>i.status==="overdue").length;
    const thisM=invoices.filter(i=>{const d=new Date(i.invoiceDate);return d.getMonth()===mn&&d.getFullYear()===yr;}).reduce((a,i)=>a+i.grandRounded,0);
    const expM=expenses.filter(e=>{const d=new Date(e.date);return d.getMonth()===mn&&d.getFullYear()===yr;}).reduce((a,e)=>a+e.amount,0);
    const invCount=invoices.filter(i=>{const d=new Date(i.invoiceDate);return d.getMonth()===mn&&d.getFullYear()===yr;}).length;
    return{paid,due,overdue,thisM,expM,profit:paid-expM,invCount};
  },[invoices,expenses,mn,yr]);

  const recent=useMemo(()=>[...invoices].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,5),[invoices]);
  const lowStock=useMemo(()=>items.filter(i=>i.type==="product"&&i.stock<=i.lowStock).length,[items]);

  const goPage=p=>{
    const stub=new Set(["einvoice","ewaybill","proforma","payment_receipt","payments_made","debit_note","credit_note","delivery_challan","purchase_order","refund_voucher","gstr","ledgers","purchase"]);
    if(stub.has(p)){alert("Coming soon in the next update!");return;}
    setPage(p);
  };

  return(<div style={{minHeight:"100%",background:"var(--bg)",paddingBottom:90}}>

    {/* Hero header */}
    <div style={{background:"linear-gradient(145deg,#004D40 0%,#00695C 50%,#00897B 100%)",padding:"20px 18px 58px",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",top:-50,right:-30,width:180,height:180,borderRadius:"50%",background:"rgba(255,255,255,.05)",pointerEvents:"none"}}/>
      <div style={{position:"absolute",top:15,right:50,width:90,height:90,borderRadius:"50%",background:"rgba(255,255,255,.04)",pointerEvents:"none"}}/>
      <div style={{position:"absolute",bottom:-30,left:-30,width:140,height:140,borderRadius:"50%",background:"rgba(0,0,0,.08)",pointerEvents:"none"}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",position:"relative",zIndex:1}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <Logo3D size={44}/>
          <div>
            <div style={{color:"rgba(255,255,255,.6)",fontSize:10,fontWeight:700,letterSpacing:".1em",textTransform:"uppercase"}}>BillBharat</div>
            <div style={{color:"#fff",fontWeight:900,fontSize:18,letterSpacing:"-.02em",lineHeight:1.1,marginTop:2}}>{biz?.name||"My Business"}</div>
            <div style={{display:"flex",gap:5,marginTop:5,flexWrap:"wrap"}}>
              <span style={{background:biz?.isGstRegistered?"rgba(255,255,255,.18)":"rgba(255,210,0,.22)",color:biz?.isGstRegistered?"rgba(255,255,255,.9)":"#FFD54F",fontSize:9.5,fontWeight:800,padding:"2px 8px",borderRadius:20}}>{biz?.isGstRegistered?"✓ GST Reg":"Unregistered"}</span>
              {!isPrem&&<span style={{background:"rgba(255,193,7,.2)",color:"#FFD54F",fontSize:9.5,fontWeight:800,padding:"2px 8px",borderRadius:20}}>FREE</span>}
            </div>
          </div>
        </div>
        <button onClick={onNewInv} style={{display:"flex",alignItems:"center",gap:6,background:"rgba(255,255,255,.15)",border:"1.5px solid rgba(255,255,255,.3)",color:"#fff",padding:"10px 16px",borderRadius:26,fontWeight:800,fontSize:13,cursor:"pointer",fontFamily:"inherit",whiteSpace:"nowrap",boxShadow:"0 4px 16px rgba(0,0,0,.2)"}}>✏️ Create</button>
      </div>
      <div style={{color:"rgba(255,255,255,.5)",fontSize:11,fontWeight:600,marginTop:12,position:"relative",zIndex:1}}>{now.toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</div>
    </div>

    {/* Floating KPI card */}
    <div style={{margin:"0 14px",transform:"translateY(-36px)",position:"relative",zIndex:5}}>
      <div style={{background:"#fff",borderRadius:20,boxShadow:"0 8px 32px rgba(0,105,92,.18)",padding:"16px",border:"1px solid rgba(0,137,123,.12)"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:0,marginBottom:12}}>
          {[{l:"Revenue",v:fmt(kpi.thisM),c:"var(--ac)",sub:"This month",pg:"invoices"},{l:"Receivable",v:fmt(kpi.due),c:kpi.due>0?"var(--re)":"var(--gr)",sub:"Outstanding",pg:"invoices"},{l:"Expenses",v:fmt(kpi.expM),c:"var(--or)",sub:"This month",pg:"expenses"}].map((k,i)=>(
            <div key={k.l} onClick={()=>setPage(k.pg)} style={{textAlign:"center",padding:"2px 4px",borderRight:i<2?"1px solid var(--bd2)":"none",cursor:"pointer"}}>
              <div style={{fontSize:9.5,color:"var(--mu)",fontWeight:700,textTransform:"uppercase",letterSpacing:".05em",marginBottom:3}}>{k.l}</div>
              <div style={{fontSize:13.5,fontWeight:900,color:k.c,letterSpacing:"-.02em"}}>{k.v}</div>
              <div style={{fontSize:9,color:"var(--mu2)",marginTop:1}}>{k.sub}</div>
            </div>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:0,paddingTop:10,borderTop:"1px solid var(--bd2)"}}>
          <div onClick={()=>setPage("invoices")} style={{textAlign:"center",cursor:"pointer"}}><div style={{fontSize:15,fontWeight:900,color:"var(--ac)"}}>{kpi.invCount}</div><div style={{fontSize:9.5,color:"var(--mu)",fontWeight:600}}>Invoices</div></div>
          <div onClick={()=>setPage("items")} style={{textAlign:"center",cursor:"pointer",borderLeft:"1px solid var(--bd2)",borderRight:"1px solid var(--bd2)"}}><div style={{fontSize:15,fontWeight:900,color:lowStock>0?"var(--re)":"var(--gr)"}}>{lowStock}</div><div style={{fontSize:9.5,color:"var(--mu)",fontWeight:600}}>Low Stock</div></div>
          <div style={{textAlign:"center"}}><div style={{fontSize:15,fontWeight:900,color:kpi.profit>=0?"var(--gr)":"var(--re)"}}>{fmt(kpi.profit)}</div><div style={{fontSize:9.5,color:"var(--mu)",fontWeight:600}}>Net Profit</div></div>
        </div>
      </div>
    </div>

    <div style={{padding:"0 14px",marginTop:-24}}>
      {kpi.overdue>0&&<div onClick={()=>setPage("invoices")} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",background:"linear-gradient(120deg,#FFEBEE,#FFCDD2)",border:"1px solid rgba(229,57,53,.2)",borderRadius:14,marginBottom:14,cursor:"pointer",boxShadow:"0 2px 10px rgba(229,57,53,.12)"}}>
        <span style={{fontSize:22}}>⚠️</span>
        <div style={{flex:1}}><div style={{fontWeight:800,fontSize:13,color:"#C62828"}}>{kpi.overdue} Overdue Invoice{kpi.overdue>1?"s":""}</div><div style={{fontSize:11,color:"#E53935",marginTop:1}}>Tap to follow up →</div></div>
      </div>}

      {!isPrem&&<div className="ub" onClick={onUpgrade}><div className="ubglow"/><div className="ubt"><div className="ubt1">✨ Upgrade to Premium</div><div className="ubt2">Excel export · AI CA advisor · Luxury templates</div></div><button className="ubcta">₹79/mo →</button></div>}

      {/* Quick Actions */}
      <div style={{background:"#fff",borderRadius:18,padding:"16px 14px 14px",marginBottom:14,boxShadow:"0 2px 14px rgba(0,105,92,.09)",border:"1px solid var(--bd2)"}}>
        <div style={{fontWeight:900,fontSize:15,marginBottom:14,display:"flex",alignItems:"center",gap:8}}><span style={{background:"var(--acb)",borderRadius:9,padding:"4px 8px",fontSize:17}}>⚡</span>Quick Actions</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
          {QA_ITEMS.map(q=>(
            <div key={q.l} onClick={()=>goPage(q.p)} style={{textAlign:"center",cursor:"pointer"}}>
              <div style={{width:54,height:54,borderRadius:16,background:q.bg,display:"grid",placeItems:"center",margin:"0 auto 6px",fontSize:25,border:"1.5px solid "+q.c+"28",boxShadow:"0 3px 10px "+q.c+"18"}}>{q.i}</div>
              <div style={{fontSize:10,fontWeight:700,color:"var(--tx2)",lineHeight:1.3}}>{q.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* More Options */}
      <div style={{background:"#fff",borderRadius:18,padding:"16px 14px 14px",marginBottom:14,boxShadow:"0 2px 14px rgba(0,105,92,.09)",border:"1px solid var(--bd2)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontWeight:900,fontSize:15,display:"flex",alignItems:"center",gap:8}}><span style={{background:"var(--acb)",borderRadius:9,padding:"4px 8px",fontSize:17}}>🔧</span>More Options</div>
          <button onClick={()=>setPage("more")} style={{background:"var(--acb)",border:"none",color:"var(--ac)",fontWeight:800,fontSize:11.5,cursor:"pointer",fontFamily:"inherit",padding:"4px 12px",borderRadius:20}}>View All</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
          {MORE_ITEMS.map(q=>(
            <div key={q.l} onClick={()=>goPage(q.p)} style={{textAlign:"center",cursor:"pointer"}}>
              <div style={{width:54,height:54,borderRadius:16,background:q.bg,display:"grid",placeItems:"center",margin:"0 auto 6px",fontSize:25,border:"1.5px solid "+q.c+"28",boxShadow:"0 3px 10px "+q.c+"18"}}>{q.i}</div>
              <div style={{fontSize:10,fontWeight:700,color:"var(--tx2)",lineHeight:1.3}}>{q.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Transactions */}
      <div style={{background:"#fff",borderRadius:18,padding:"16px",marginBottom:14,boxShadow:"0 2px 14px rgba(0,105,92,.09)",border:"1px solid var(--bd2)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{fontWeight:900,fontSize:15}}>Recent Transactions</div>
          <button onClick={()=>setPage("invoices")} style={{background:"var(--acb)",border:"none",color:"var(--ac)",fontWeight:800,fontSize:11.5,cursor:"pointer",fontFamily:"inherit",padding:"4px 12px",borderRadius:20}}>View All</button>
        </div>
        {recent.length===0&&<Empty icon="📄" title="No invoices yet" sub="Create your first invoice" cta="+ New Invoice" onCta={onNewInv}/>}
        {recent.map((inv,i)=>(
          <div key={inv.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:i<recent.length-1?"1px solid var(--bd2)":"none"}}>
            <div style={{width:42,height:42,borderRadius:13,background:"var(--acb)",display:"grid",placeItems:"center",fontSize:19,flexShrink:0}}>{DTYPES.find(d=>d.id===inv.type)?.i||"📄"}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:800,fontSize:13,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{inv.party?.name||"—"}</div>
              <div style={{fontSize:11,color:"var(--mu)",marginTop:1}}>{inv.invoiceNumber} · {inv.invoiceDate}</div>
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <div style={{fontWeight:900,fontSize:13.5,color:inv.status==="paid"?"var(--gr)":"var(--tx)"}}>{fmt(inv.grandRounded)}</div>
              <SBadge s={inv.status}/>
            </div>
          </div>
        ))}
      </div>

      {/* Customer + Items summary */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
        <div onClick={()=>setPage("crm")} style={{background:"linear-gradient(135deg,#E0F2F1,#B2DFDB)",borderRadius:16,padding:"16px",cursor:"pointer",border:"1px solid rgba(0,137,123,.2)"}}>
          <div style={{fontSize:26,marginBottom:6}}>👥</div>
          <div style={{fontWeight:900,fontSize:24,color:"var(--ac)"}}>{customers.length}</div>
          <div style={{fontSize:12,fontWeight:700,color:"var(--tx2)"}}>Customers</div>
          <div style={{fontSize:10,color:"var(--mu)",marginTop:2}}>Manage CRM →</div>
        </div>
        <div onClick={()=>setPage("items")} style={{background:"linear-gradient(135deg,#FFF3E0,#FFE0B2)",borderRadius:16,padding:"16px",cursor:"pointer",border:"1px solid rgba(245,124,0,.2)"}}>
          <div style={{fontSize:26,marginBottom:6}}>📦</div>
          <div style={{fontWeight:900,fontSize:24,color:"#F57C00"}}>{items.length}</div>
          <div style={{fontSize:12,fontWeight:700,color:"var(--tx2)"}}>Items</div>
          <div style={{fontSize:10,color:"var(--mu)",marginTop:2}}>Inventory →</div>
        </div>
      </div>
    </div>
  </div>);
};

// ── Invoices List ─────────────────────────────────────────────
const InvList=({invoices,onNew,onEdit,onDelete,biz,isPrem,onUpgrade})=>{
  const [q,setQ]=useState(""),[sf,setSF]=useState("all"),[pm,setPM]=useState("all"),[dr,setDR]=useState("all"),[selInv,setSel]=useState(null);
  const [custDR,setCDR]=useState({from:"",to:""});
  const filtered=useMemo(()=>{let r=[...invoices];if(sf!=="all")r=r.filter(i=>i.status===sf);if(pm!=="all")r=r.filter(i=>i.paymentMode===pm);if(q.trim())r=r.filter(i=>(i.party?.name||"").toLowerCase().includes(q.toLowerCase())||(i.invoiceNumber||"").toLowerCase().includes(q.toLowerCase()));const now=new Date();if(dr==="today")r=r.filter(i=>i.invoiceDate===td());else if(dr==="week"){const s=dAgo(7);r=r.filter(i=>i.invoiceDate>=s);}else if(dr==="30d"){const s=dAgo(30);r=r.filter(i=>i.invoiceDate>=s);}else if(dr==="custom"&&custDR.from&&custDR.to)r=r.filter(i=>i.invoiceDate>=custDR.from&&i.invoiceDate<=custDR.to);return r.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));},[invoices,q,sf,pm,dr,custDR]);
  const tots=useMemo(()=>({total:filtered.reduce((a,i)=>a+i.grandRounded,0),paid:filtered.filter(i=>i.status==="paid").reduce((a,i)=>a+i.grandRounded,0),due:filtered.filter(i=>["unpaid","partial","overdue"].includes(i.status)).reduce((a,i)=>a+(i.grandRounded-(i.amountPaid||0)),0)}), [filtered]);
  const doExport=()=>{if(!isPrem){onUpgrade();return;}exportXL(filtered.map(i=>[i.invoiceNumber,i.invoiceDate,i.party?.name||"",i.type,i.status,i.grandRounded,i.amountPaid||0,i.paymentMode||""]),["Invoice No","Date","Party","Type","Status","Amount","Paid","Mode"],`invoices_${td()}.xlsx`);};
  return(<div className="page">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
      <div className="ptit">Sales 📄</div>
      <div style={{display:"flex",gap:7}}>
        <button className="btn btnsm" onClick={doExport}>📥 Export{!isPrem&&<span className="pbadge" style={{marginLeft:4}}>PRO</span>}</button>
        <button className="btn btnp btnsm" onClick={onNew}>+ New</button>
      </div>
    </div>
    <div className="sbar"><span style={{fontSize:18,opacity:.5}}>🔍</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search by party or invoice no..."/>{q&&<button onClick={()=>setQ("")} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:"var(--mu)"}}>✕</button>}</div>
    <div className="fbar">
      {["all","paid","unpaid","overdue","partial","draft"].map(s=><Chip key={s} label={s==="all"?"All":s.charAt(0).toUpperCase()+s.slice(1)} active={sf===s} onClick={()=>setSF(s)} col={s==="paid"?"#0CAF60":s==="overdue"?"#E03B3B":s==="unpaid"?"#F5900A":undefined}/>)}
    </div>
    <div className="fbar">
      {["all","today","week","30d","custom"].map(d=><Chip key={d} label={d==="all"?"All Dates":d==="today"?"Today":d==="week"?"7 Days":d==="30d"?"30 Days":"Custom"} active={dr===d} onClick={()=>setDR(d)}/>)}
    </div>
    {dr==="custom"&&<div style={{display:"flex",gap:8,marginBottom:10}}><input className="inp" type="date" value={custDR.from} onChange={e=>setCDR(p=>({...p,from:e.target.value}))} style={{flex:1}}/><span style={{alignSelf:"center",color:"var(--mu)",fontSize:12}}>to</span><input className="inp" type="date" value={custDR.to} onChange={e=>setCDR(p=>({...p,to:e.target.value}))} style={{flex:1}}/></div>}
    {filtered.length>0&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
      <div className="card" style={{padding:"10px 12px",textAlign:"center"}}><div style={{fontSize:11,fontWeight:700,color:"var(--mu)",textTransform:"uppercase",letterSpacing:".05em"}}>Total</div><div style={{fontSize:14,fontWeight:900,color:"var(--ac)",marginTop:3}}>{fmt(tots.total)}</div></div>
      <div className="card" style={{padding:"10px 12px",textAlign:"center"}}><div style={{fontSize:11,fontWeight:700,color:"var(--mu)",textTransform:"uppercase",letterSpacing:".05em"}}>Collected</div><div style={{fontSize:14,fontWeight:900,color:"var(--gr)",marginTop:3}}>{fmt(tots.paid)}</div></div>
      <div className="card" style={{padding:"10px 12px",textAlign:"center"}}><div style={{fontSize:11,fontWeight:700,color:"var(--mu)",textTransform:"uppercase",letterSpacing:".05em"}}>Pending</div><div style={{fontSize:14,fontWeight:900,color:"var(--re)",marginTop:3}}>{fmt(tots.due)}</div></div>
    </div>}
    {filtered.length===0?<Empty icon="📭" title="No invoices found" sub="Try changing filters or create a new one" cta="+ New Invoice" onCta={onNew}/>:
      filtered.map(inv=><div key={inv.id} className="card cardi" style={{padding:"12px 14px",marginBottom:8}} onClick={()=>setSel(inv)}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
          <div><div style={{fontWeight:800,fontSize:13}}>{inv.invoiceNumber}</div><div style={{fontSize:11.5,color:"var(--mu)",marginTop:1}}>{inv.party?.name||"—"}</div></div>
          <div style={{textAlign:"right"}}><div style={{fontWeight:900,fontSize:14}}>{fmt(inv.grandRounded)}</div><SBadge s={inv.status}/></div>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:11,color:"var(--mu)"}}>📅 {inv.invoiceDate}{inv.dueDate&&` · Due: ${inv.dueDate}`}</div>
          <div style={{fontSize:11,color:"var(--mu)"}}>{DTYPES.find(d=>d.id===inv.type)?.i} {DTYPES.find(d=>d.id===inv.type)?.l}</div>
        </div>
        {inv.status==="partial"&&<div style={{marginTop:5,fontSize:11.5,color:"var(--pu)"}}> Balance: {fmt(inv.grandRounded-(inv.amountPaid||0))} · Paid: {fmt(inv.amountPaid||0)}</div>}
      </div>)
    }
    {selInv&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setSel(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr"><div style={{fontWeight:900}}>{selInv.invoiceNumber}</div><button className="btn btng btnxs" onClick={()=>setSel(null)}>✕</button></div>
        <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:10}}>
          <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:"var(--mu)",fontSize:13}}>Party</span><span style={{fontWeight:700}}>{selInv.party?.name||"—"}</span></div>
          <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:"var(--mu)",fontSize:13}}>Amount</span><span style={{fontWeight:800,fontSize:15,color:"var(--ac)"}}>{fmt(selInv.grandRounded)}</span></div>
          <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:"var(--mu)",fontSize:13}}>Status</span><SBadge s={selInv.status}/></div>
          <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:"var(--mu)",fontSize:13}}>Date</span><span style={{fontWeight:600}}>{selInv.invoiceDate}</span></div>
          {selInv.notes&&<div style={{padding:"8px 12px",background:"var(--bg3)",borderRadius:8,fontSize:12.5}}>{selInv.notes}</div>}
          <div style={{display:"flex",gap:8,paddingTop:4}}>
            <button className="btn btnsm" style={{flex:1}} onClick={()=>{onEdit(selInv);setSel(null);}}>✏️ Edit</button>
            <button className="btn btnsm btnp" style={{flex:1}} onClick={()=>printInv(selInv,biz)}>🖨 Print</button>
            <button className="btn btnsm btnR" onClick={()=>{if(window.confirm("Delete this invoice?"))onDelete(selInv.id);setSel(null);}}>🗑</button>
          </div>
        </div>
      </div>
    </div>}
  </div>);
};

// ── CRM Tab ───────────────────────────────────────────────────
const CRMTab=({customers,setCustomers,invoices,showToast,isPrem,onUpgrade})=>{
  const [q,setQ]=useState(""),[lsF,setLF]=useState("all"),[rgF,setRG]=useState("all"),[ovF,setOV]=useState(false);
  const [selC,setSelC]=useState(null),[editC,setEditC]=useState(null),[khModal,setKH]=useState(null),[logModal,setLM]=useState(null);

  const stats=useMemo(()=>LEADS.reduce((m,l)=>({...m,[l.id]:customers.filter(c=>c.leadStatus===l.id).length}),{}),[customers]);

  const filtered=useMemo(()=>{
    let r=[...customers];
    if(q.trim())r=r.filter(c=>c.name.toLowerCase().includes(q.toLowerCase())||c.phone?.includes(q));
    if(lsF!=="all")r=r.filter(c=>c.leadStatus===lsF);
    if(rgF!=="all")r=r.filter(c=>c.region===rgF);
    if(ovF){const cut=dAgo(30);r=r.filter(c=>{const due=invoices.filter(i=>i.party?.id===c.id&&["unpaid","partial","overdue"].includes(i.status)&&i.dueDate&&i.dueDate<cut).reduce((a,i)=>a+(i.grandRounded-(i.amountPaid||0)),0);return due>0;});}
    return r;
  },[customers,q,lsF,rgF,ovF]);

  const getBalance=useCallback(cId=>invoices.filter(i=>i.party?.id===cId&&["unpaid","partial","overdue"].includes(i.status)).reduce((a,i)=>a+(i.grandRounded-(i.amountPaid||0)),0),[invoices]);
  const getTotalBiz=useCallback(cId=>invoices.filter(i=>i.party?.id===cId).reduce((a,i)=>a+i.grandRounded,0),[invoices]);

  const saveC=c=>{setCustomers(p=>p.find(x=>x.id===c.id)?p.map(x=>x.id===c.id?c:x):[...p,c]);setEditC(null);sync("businesses",c);showToast(c.id?"Party updated":"Party added");};
  const delC=id=>{setCustomers(p=>p.filter(c=>c.id!==id));del("businesses",id);setSelC(null);showToast("Party deleted","warn");};
  const addLog=(cId,log)=>{setCustomers(p=>p.map(c=>c.id===cId?{...c,interactions:[...(c.interactions||[]),log]}:c));showToast("Interaction logged");};
  const setLead=(cId,ls)=>{setCustomers(p=>p.map(c=>c.id===cId?{...c,leadStatus:ls}:c));showToast(`Status → ${LEADS.find(l=>l.id===ls)?.l}`);};

  return(<div className="page">
    {/* Pipeline summary */}
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
      <div className="ptit">CRM 🎯</div>
      <button className="btn btnp btnsm" onClick={()=>setEditC({id:null,name:"",gstin:"",phone:"",email:"",address:{city:"",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"",leadStatus:"inquiry",region:"Maharashtra",interactions:[]})}>+ Add Party</button>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,marginBottom:14}}>
      {LEADS.map(l=><div key={l.id} className="card" style={{padding:"8px 6px",textAlign:"center",cursor:"pointer",borderColor:lsF===l.id?l.c:"var(--bd2)",background:lsF===l.id?l.bg:"var(--bg2)"}} onClick={()=>setLF(lsF===l.id?"all":l.id)}><div style={{fontSize:18,fontWeight:900,color:l.c}}>{stats[l.id]||0}</div><div style={{fontSize:9.5,fontWeight:700,color:l.c,marginTop:2}}>{l.l}</div></div>)}
    </div>
    <div className="sbar"><span style={{fontSize:18,opacity:.5}}>🔍</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search parties..."/>{q&&<button onClick={()=>setQ("")} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:"var(--mu)"}}>✕</button>}</div>
    <div className="fbar">
      <Chip label="All Regions" active={rgF==="all"} onClick={()=>setRG("all")}/>
      {REGIONS.slice(0,6).map(r=><Chip key={r} label={r} active={rgF===r} onClick={()=>setRG(r==="all"||rgF===r?"all":r)}/>)}
    </div>
    <div className="fbar">
      <Chip label={ovF?"✓ Overdue >30d":"Overdue >30d"} active={ovF} onClick={()=>setOV(!ovF)} col="#E03B3B"/>
    </div>
    {filtered.length===0?<Empty icon="👥" title="No parties found" sub="Add your customers and leads" cta="+ Add Party" onCta={()=>setEditC({id:null,name:"",gstin:"",phone:"",email:"",address:{city:"",state:"Maharashtra"},type:"customer",openingBalance:0,notes:"",leadStatus:"inquiry",region:"Maharashtra",interactions:[]})}/>:
      filtered.map(c=>{const bal=getBalance(c.id);return(<div key={c.id} className="card cardi" style={{padding:"12px 14px",marginBottom:8}} onClick={()=>setSelC(c)}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <div style={{width:36,height:36,borderRadius:"50%",background:"var(--acb)",display:"grid",placeItems:"center",fontSize:16,fontWeight:900,color:"var(--ac)",flexShrink:0}}>{c.name[0]}</div>
            <div><div style={{fontWeight:800,fontSize:13.5}}>{c.name}</div><div style={{fontSize:11,color:"var(--mu)",marginTop:1}}>{c.phone||"—"}{c.region&&<span style={{marginLeft:6}}>📍 {c.region}</span>}</div></div>
          </div>
          <div style={{textAlign:"right"}}><LeadBadge s={c.leadStatus}/>{bal>0&&<div style={{fontSize:11,color:"var(--re)",marginTop:3,fontWeight:700}}>Due: {fmt(bal)}</div>}</div>
        </div>
        {c.gstin&&<div style={{fontSize:10.5,color:"var(--mu)",fontFamily:"'JetBrains Mono',monospace"}}>GST: {c.gstin}</div>}
        {(c.interactions||[]).length>0&&<div style={{fontSize:11,color:"var(--mu)",marginTop:4}}>💬 Last: {c.interactions[c.interactions.length-1].note?.slice(0,50)}...</div>}
      </div>);})}

    {/* Party Detail Modal */}
    {selC&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setSelC(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr">
          <div style={{fontWeight:900,fontSize:15}}>{selC.name}</div>
          <div style={{display:"flex",gap:6}}>
            <button className="btn btnsm" onClick={()=>{setEditC(selC);setSelC(null);}}>✏️ Edit</button>
            <button className="btn btng btnxs" onClick={()=>setSelC(null)}>✕</button>
          </div>
        </div>
        <div style={{padding:"14px 16px"}}>
          {/* Lead pipeline */}
          <div style={{marginBottom:14}}>
            <div className="lbl" style={{marginBottom:8}}>CRM Pipeline</div>
            <div style={{display:"flex",gap:6}}>
              {LEADS.map(l=><button key={l.id} onClick={()=>{setLead(selC.id,l.id);setSelC(p=>({...p,leadStatus:l.id}));}} style={{flex:1,padding:"8px 4px",borderRadius:8,border:`1.5px solid ${selC.leadStatus===l.id?l.c:"var(--bd2)"}`,background:selC.leadStatus===l.id?l.bg:"var(--bg2)",color:selC.leadStatus===l.id?l.c:"var(--mu)",fontWeight:700,fontSize:10.5,cursor:"pointer",fontFamily:"inherit",transition:"all .15s"}}>{l.l}</button>)}
            </div>
          </div>
          {/* Stats */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
            <div className="card" style={{padding:"10px",textAlign:"center"}}><div style={{fontSize:10,fontWeight:700,color:"var(--mu)",textTransform:"uppercase"}}>Total Biz</div><div style={{fontSize:13,fontWeight:900,color:"var(--ac)",marginTop:3}}>{fmt(getTotalBiz(selC.id))}</div></div>
            <div className="card" style={{padding:"10px",textAlign:"center"}}><div style={{fontSize:10,fontWeight:700,color:"var(--mu)",textTransform:"uppercase"}}>Due</div><div style={{fontSize:13,fontWeight:900,color:"var(--re)",marginTop:3}}>{fmt(getBalance(selC.id))}</div></div>
            <div className="card" style={{padding:"10px",textAlign:"center"}}><div style={{fontSize:10,fontWeight:700,color:"var(--mu)",textTransform:"uppercase"}}>Invoices</div><div style={{fontSize:13,fontWeight:900,marginTop:3}}>{invoices.filter(i=>i.party?.id===selC.id).length}</div></div>
          </div>
          {/* Contact info */}
          {selC.phone&&<div style={{display:"flex",gap:10,alignItems:"center",padding:"10px 12px",background:"var(--bg3)",borderRadius:10,marginBottom:10}}><span style={{fontSize:20}}>📱</span><div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>{selC.phone}</div><div style={{fontSize:11,color:"var(--mu)"}}>Mobile</div></div><a href={`tel:${selC.phone}`} className="btn btnp btnxs">Call</a></div>}
          {selC.email&&<div style={{display:"flex",gap:10,alignItems:"center",padding:"10px 12px",background:"var(--bg3)",borderRadius:10,marginBottom:10}}><span style={{fontSize:20}}>✉️</span><div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>{selC.email}</div></div><a href={`mailto:${selC.email}`} className="btn btnsm">Email</a></div>}
          {selC.gstin&&<div style={{padding:"10px 12px",background:"var(--bg3)",borderRadius:10,marginBottom:10}}><div style={{fontSize:11,fontWeight:700,color:"var(--mu)"}}>GSTIN</div><div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:13,fontWeight:600,marginTop:2,color:validG(selC.gstin)?"var(--gr)":"var(--re)"}}>{selC.gstin} {validG(selC.gstin)?"✓":""}</div></div>}
          {/* Khata */}
          <div style={{display:"flex",gap:8,marginBottom:14}}>
            <button className="khb khin" onClick={()=>setKH({cId:selC.id,type:"payment_received"})}>+ Received ₹</button>
            <button className="khb khout" onClick={()=>setKH({cId:selC.id,type:"payment_sent"})}>+ Paid ₹</button>
          </div>
          {/* Interaction log */}
          <div style={{marginBottom:14}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div className="lbl" style={{marginBottom:0}}>Interaction Log</div>
              <button className="btn btnp btnxs" onClick={()=>setLM({cId:selC.id})}>+ Log</button>
            </div>
            {(selC.interactions||[]).length===0&&<div style={{fontSize:12.5,color:"var(--mu)",padding:"12px",background:"var(--bg3)",borderRadius:8,textAlign:"center"}}>No interactions yet. Log a call or meeting!</div>}
            {[...(selC.interactions||[])].reverse().map(lg=><div key={lg.id} className="ilog"><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontSize:10.5,fontWeight:800,color:"var(--ac)"}}>{lg.type==="call"?"📞 Call":"🤝 Meeting"}</span><span style={{fontSize:10.5,color:"var(--mu)"}}>{lg.date}</span></div><div style={{fontSize:12.5,lineHeight:1.5}}>{lg.note}</div></div>)}
          </div>
          {selC.notes&&<div style={{fontSize:12.5,color:"var(--mu)",marginBottom:10,padding:"8px 12px",background:"var(--bg3)",borderRadius:8}}>📝 {selC.notes}</div>}
          <button className="btn btnR btnsm" style={{width:"100%"}} onClick={()=>{if(window.confirm("Delete this party?"))delC(selC.id);}}>🗑 Delete Party</button>
        </div>
      </div>
    </div>}

    {/* Edit / Add Party Modal */}
    {editC!==null&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setEditC(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr"><div style={{fontWeight:900}}>{editC.id?"Edit Party":"New Party"}</div><button className="btn btng btnxs" onClick={()=>setEditC(null)}>✕</button></div>
        <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:12}}>
          <div><label className="lbl">Name *</label><input className="inp" value={editC.name||""} onChange={e=>setEditC(p=>({...p,name:e.target.value}))} placeholder="Party name" autoFocus/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Phone</label><input className="inp" value={editC.phone||""} onChange={e=>setEditC(p=>({...p,phone:e.target.value}))} placeholder="9876543210"/></div>
            <div><label className="lbl">Email</label><input className="inp" type="email" value={editC.email||""} onChange={e=>setEditC(p=>({...p,email:e.target.value}))} placeholder="email@example.com"/></div>
          </div>
          <div><label className="lbl">GSTIN</label><input className="inp" value={editC.gstin||""} onChange={e=>setEditC(p=>({...p,gstin:e.target.value.toUpperCase()}))} placeholder="27AAFCS1234A1Z5" style={{fontFamily:"'JetBrains Mono',monospace"}}/>{editC.gstin&&<div style={{fontSize:11,marginTop:4,color:validG(editC.gstin)?"var(--gr)":"var(--re)",fontWeight:600}}>{validG(editC.gstin)?"✓ Valid GSTIN":"⚠ Invalid GSTIN"}</div>}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">City</label><input className="inp" value={editC.address?.city||""} onChange={e=>setEditC(p=>({...p,address:{...p.address,city:e.target.value}}))}/></div>
            <div><label className="lbl">State</label><select className="inp" value={editC.address?.state||"Maharashtra"} onChange={e=>setEditC(p=>({...p,address:{...p.address,state:e.target.value}}))}>{REGIONS.map(r=><option key={r} value={r}>{r}</option>)}</select></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Lead Status</label><select className="inp" value={editC.leadStatus||"inquiry"} onChange={e=>setEditC(p=>({...p,leadStatus:e.target.value}))}>{LEADS.map(l=><option key={l.id} value={l.id}>{l.l}</option>)}</select></div>
            <div><label className="lbl">Region</label><select className="inp" value={editC.region||"Maharashtra"} onChange={e=>setEditC(p=>({...p,region:e.target.value}))}>{REGIONS.map(r=><option key={r} value={r}>{r}</option>)}</select></div>
          </div>
          <div><label className="lbl">Opening Balance (₹)</label><input className="inp" type="number" value={editC.openingBalance||0} onChange={e=>setEditC(p=>({...p,openingBalance:+e.target.value}))}/></div>
          <div><label className="lbl">Notes</label><textarea className="inp" rows={2} value={editC.notes||""} onChange={e=>setEditC(p=>({...p,notes:e.target.value}))} placeholder="Any notes about this party..."/></div>
          <div style={{display:"flex",gap:10,paddingBottom:8}}>
            <button className="btn" style={{flex:1}} onClick={()=>setEditC(null)}>Cancel</button>
            <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!editC.name?.trim()){alert("Name required");return;}saveC({...editC,id:editC.id||uid()});}}>💾 Save</button>
          </div>
        </div>
      </div>
    </div>}

    {/* Log Interaction Modal */}
    {logModal&&<div className="mbg ctr" onClick={e=>e.target===e.currentTarget&&setLM(null)}>
      <div className="mctr">
        <div style={{padding:"20px 20px 24px"}}>
          <div style={{fontWeight:900,fontSize:16,marginBottom:14}}>📋 Log Interaction</div>
          <LogForm cId={logModal.cId} onSave={log=>{addLog(logModal.cId,log);setLM(null);}} onClose={()=>setLM(null)}/>
        </div>
      </div>
    </div>}

    {/* Khata modal */}
    {khModal&&<div className="mbg ctr" onClick={e=>e.target===e.currentTarget&&setKH(null)}>
      <div className="mctr"><KhataForm {...khModal} onClose={()=>setKH(null)} onSave={()=>{showToast("Entry saved");setKH(null);}}/></div>
    </div>}
  </div>);
};

const LogForm=({cId,onSave,onClose})=>{
  const [type,setType]=useState("call"),[note,setNote]=useState(""),[date,setDate]=useState(td());
  return(<div style={{display:"flex",flexDirection:"column",gap:12}}>
    <div style={{display:"flex",gap:8}}>{["call","meeting"].map(t=><button key={t} onClick={()=>setType(t)} style={{flex:1,padding:"9px",borderRadius:9,border:`1.5px solid ${type===t?"var(--ac)":"var(--bd2)"}`,background:type===t?"var(--acb)":"var(--bg2)",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit"}}>{t==="call"?"📞 Call":"🤝 Meeting"}</button>)}</div>
    <div><label className="lbl">Date</label><input className="inp" type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
    <div><label className="lbl">Note *</label><textarea className="inp" rows={3} value={note} onChange={e=>setNote(e.target.value)} placeholder="What was discussed? Any action items?" autoFocus/></div>
    <div style={{display:"flex",gap:8}}>
      <button className="btn" style={{flex:1}} onClick={onClose}>Cancel</button>
      <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!note.trim()){alert("Add a note");return;}onSave({id:uid(),date,type,note});}}>💾 Save</button>
    </div>
  </div>);
};

const KhataForm=({cId,type,onClose,onSave})=>{
  const [amt,setAmt]=useState(""),[note,setNote]=useState(""),[pm,setPM]=useState("Cash"),[date,setDate]=useState(td());
  return(<div style={{padding:"20px 20px 24px"}}>
    <div style={{fontWeight:900,fontSize:16,marginBottom:14}}>{type==="payment_received"?"💚 Payment Received":"💸 Payment Sent"}</div>
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div><label className="lbl">Amount (₹) *</label><input className="inp" type="number" value={amt} onChange={e=>setAmt(e.target.value)} placeholder="0" autoFocus/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        <div><label className="lbl">Date</label><input className="inp" type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
        <div><label className="lbl">Mode</label><select className="inp" value={pm} onChange={e=>setPM(e.target.value)}>{PAY_MODES.map(m=><option key={m} value={m}>{m}</option>)}</select></div>
      </div>
      <div><label className="lbl">Note</label><input className="inp" value={note} onChange={e=>setNote(e.target.value)} placeholder="Reference / remarks"/></div>
      <div style={{display:"flex",gap:8}}>
        <button className="btn" style={{flex:1}} onClick={onClose}>Cancel</button>
        <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!amt){alert("Enter amount");return;}onSave({id:uid(),cId,type,amount:+amt,paymentMode:pm,date,note});}}>💾 Save</button>
      </div>
    </div>
  </div>);
};

// ── Items Tab ─────────────────────────────────────────────────
const ItemsTab=({items,setItems,showToast,isPrem,onUpgrade})=>{
  const [q,setQ]=useState(""),[editI,setEI]=useState(null),[typeF,setTF]=useState("all");
  const filtered=useMemo(()=>{let r=[...items];if(typeF!=="all")r=r.filter(i=>i.type===typeF);if(q.trim())r=r.filter(i=>i.name.toLowerCase().includes(q.toLowerCase())||i.hsnCode?.includes(q)||i.barcode?.includes(q));return r;},[items,q,typeF]);
  const lowStock=useMemo(()=>items.filter(i=>i.type==="product"&&i.stock<=i.lowStock),[items]);
  const saveI=it=>{setItems(p=>p.find(x=>x.id===it.id)?p.map(x=>x.id===it.id?it:x):[...p,it]);setEI(null);sync("inventory",it);showToast(it.id?"Item updated":"Item added");};
  const delI=id=>{setItems(p=>p.filter(i=>i.id!==id));del("inventory",id);showToast("Item deleted","warn");};
  const doExport=()=>{if(!isPrem){onUpgrade();return;}exportXL(items.map(i=>[i.name,i.type,i.hsnCode||i.sacCode||"",i.salePrice,i.purchasePrice,i.stock,i.unit,i.gstRate]),["Name","Type","HSN/SAC","Sale Price","Purchase Price","Stock","Unit","GST%"],`inventory_${td()}.xlsx`);};
  const blank={id:null,name:"",hsnCode:"",sacCode:"",barcode:"",type:"product",gstRate:18,unit:"pcs",salePrice:0,purchasePrice:0,stock:0,lowStock:10};
  return(<div className="page">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
      <div className="ptit">Items 📦</div>
      <div style={{display:"flex",gap:7}}>
        <button className="btn btnsm" onClick={doExport}>📥 Export{!isPrem&&<span className="pbadge" style={{marginLeft:4}}>PRO</span>}</button>
        <button className="btn btnp btnsm" onClick={()=>setEI(blank)}>+ Add</button>
      </div>
    </div>
    {lowStock.length>0&&<div style={{padding:"10px 14px",background:"rgba(245,144,10,.1)",border:"1px solid rgba(245,144,10,.3)",borderRadius:10,marginBottom:12,display:"flex",alignItems:"center",gap:10}}><span style={{fontSize:18}}>⚠️</span><div><div style={{fontWeight:700,fontSize:13,color:"#D97706"}}>Low Stock Alert</div><div style={{fontSize:11.5,color:"var(--mu)"}}>{lowStock.map(i=>i.name).join(", ")}</div></div></div>}
    <div className="sbar"><span style={{fontSize:18,opacity:.5}}>🔍</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search items, HSN, barcode..."/>{q&&<button onClick={()=>setQ("")} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:"var(--mu)"}}>✕</button>}</div>
    <div className="fbar"><Chip label="All" active={typeF==="all"} onClick={()=>setTF("all")}/><Chip label="Products" active={typeF==="product"} onClick={()=>setTF("product")}/><Chip label="Services" active={typeF==="service"} onClick={()=>setTF("service")}/></div>
    {filtered.length===0?<Empty icon="📦" title="No items found" sub="Add products and services to use in invoices" cta="+ Add Item" onCta={()=>setEI(blank)}/>:
      filtered.map(it=>{const margin=it.purchasePrice>0?((it.salePrice-it.purchasePrice)/it.purchasePrice*100).toFixed(1):null;return(<div key={it.id} className="card cardi" style={{padding:"12px 14px",marginBottom:8,display:"flex",gap:12,alignItems:"flex-start"}}>
        <div style={{width:40,height:40,borderRadius:10,background:it.type==="service"?"rgba(139,92,246,.1)":"var(--acb)",display:"grid",placeItems:"center",fontSize:20,flexShrink:0}}>{it.type==="service"?"⚙️":"📦"}</div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
            <div style={{fontWeight:800,fontSize:13.5,flex:1}}>{it.name}</div>
            <div style={{fontWeight:900,fontSize:14,color:"var(--ac)",flexShrink:0}}>{fmt(it.salePrice)}</div>
          </div>
          <div style={{fontSize:11,color:"var(--mu)",marginTop:2,display:"flex",gap:10,flexWrap:"wrap"}}>
            {it.hsnCode&&<span>HSN: {it.hsnCode}</span>}
            {it.gstRate>0&&<span>GST: {it.gstRate}%</span>}
            {it.type==="product"&&<span style={{color:it.stock<=it.lowStock?"var(--re)":"var(--gr)",fontWeight:700}}>Stock: {it.stock} {it.unit}</span>}
            {margin&&<span style={{color:+margin>20?"var(--gr)":"var(--or)",fontWeight:700}}>Margin: {margin}%</span>}
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:4,flexShrink:0}}>
          <button className="btn btnsm" onClick={e=>{e.stopPropagation();setEI(it);}}>✏️</button>
          <button className="btn btnsm btnR" style={{padding:"6px 8px"}} onClick={e=>{e.stopPropagation();if(window.confirm("Delete?"))delI(it.id);}}>🗑</button>
        </div>
      </div>);})}

    {editI!==null&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setEI(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr"><div style={{fontWeight:900}}>{editI.id?"Edit Item":"New Item"}</div><button className="btn btng btnxs" onClick={()=>setEI(null)}>✕</button></div>
        <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:12}}>
          <div style={{display:"flex",gap:8}}>{["product","service"].map(t=><button key={t} onClick={()=>setEI(p=>({...p,type:t}))} style={{flex:1,padding:"9px",borderRadius:9,border:`1.5px solid ${editI.type===t?"var(--ac)":"var(--bd2)"}`,background:editI.type===t?"var(--acb)":"var(--bg2)",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit"}}>{t==="product"?"📦 Product":"⚙️ Service"}</button>)}</div>
          <div><label className="lbl">Name *</label><input className="inp" value={editI.name||""} onChange={e=>setEI(p=>({...p,name:e.target.value}))} placeholder="Item name" autoFocus/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Sale Price (₹)</label><input className="inp" type="number" value={editI.salePrice||0} onChange={e=>setEI(p=>({...p,salePrice:+e.target.value}))}/></div>
            <div><label className="lbl">Purchase Price (₹)</label><input className="inp" type="number" value={editI.purchasePrice||0} onChange={e=>setEI(p=>({...p,purchasePrice:+e.target.value}))}/></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
            <div><label className="lbl">GST %</label><select className="inp" value={editI.gstRate||0} onChange={e=>setEI(p=>({...p,gstRate:+e.target.value}))}>{GST_RATES.map(r=><option key={r} value={r}>{r}%</option>)}</select></div>
            <div><label className="lbl">Unit</label><select className="inp" value={editI.unit||"pcs"} onChange={e=>setEI(p=>({...p,unit:e.target.value}))}>{UNITS.map(u=><option key={u} value={u}>{u}</option>)}</select></div>
            {editI.type==="product"&&<div><label className="lbl">Stock</label><input className="inp" type="number" value={editI.stock||0} onChange={e=>setEI(p=>({...p,stock:+e.target.value}))}/></div>}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">{editI.type==="product"?"HSN Code":"SAC Code"}</label><input className="inp" value={editI.type==="product"?editI.hsnCode||"":editI.sacCode||""} onChange={e=>setEI(p=>editI.type==="product"?{...p,hsnCode:e.target.value}:{...p,sacCode:e.target.value})} placeholder={editI.type==="product"?"1006":"9983"}/></div>
            <div><label className="lbl">Barcode</label><input className="inp" value={editI.barcode||""} onChange={e=>setEI(p=>({...p,barcode:e.target.value}))} placeholder="Scan or type"/></div>
          </div>
          {editI.type==="product"&&<div><label className="lbl">Low Stock Alert</label><input className="inp" type="number" value={editI.lowStock||10} onChange={e=>setEI(p=>({...p,lowStock:+e.target.value}))} placeholder="10"/></div>}
          <div style={{display:"flex",gap:10,paddingBottom:8}}>
            <button className="btn" style={{flex:1}} onClick={()=>setEI(null)}>Cancel</button>
            <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!editI.name?.trim()){alert("Name required");return;}saveI({...editI,id:editI.id||uid()});}}>💾 Save</button>
          </div>
        </div>
      </div>
    </div>}
  </div>);
};

// ── Payroll Tab ───────────────────────────────────────────────
const PayrollTab=({employees,setEmployees,expenses,setExpenses,showToast,isPrem,onUpgrade})=>{
  const now=new Date();
  const [selM,setSelM]=useState(now.getMonth()),[selY,setSelY]=useState(now.getFullYear());
  const [editE,setEE]=useState(null),[selEmp,setSelEmp]=useState(null),[genModal,setGM]=useState(null);
  const attKey=useCallback((empId,y,m)=>`${empId}_${y}_${m}`,[]);

  const getAtt=useCallback((emp,y,m)=>emp.attendance?.[attKey(emp.id,y,m)]||{},[attKey]);
  const setAtt=(emp,day,status)=>{const k=attKey(emp.id,selY,selM);const updated={...employees.find(e=>e.id===emp.id),attendance:{...emp.attendance,[k]:{...(emp.attendance?.[k]||{}),[day]:status}}};setEmployees(p=>p.map(e=>e.id===emp.id?updated:e));sync("payroll",updated);};

  const calcSal=useCallback((emp,y,m)=>{const att=getAtt(emp,y,m);const days=new Date(y,m+1,0).getDate();const worked=Object.values(att).reduce((a,s)=>a+(s==="P"?1:s==="H"?.5:0),0);const totalE=SAL_COMPS.filter(c=>c.t==="e").reduce((a,c)=>a+(emp.salary?.[c.id]||0),0);const totalD=SAL_COMPS.filter(c=>c.t==="d").reduce((a,c)=>a+(emp.salary?.[c.id]||0),0);const gross=totalE;const net=Math.round((gross/days)*worked-totalD);return{gross,net,worked,days,totalE,totalD};},[getAtt]);

  const generateSlip=useCallback((emp)=>{const {gross,net,worked,days}=calcSal(emp,selY,selM);const expRec={id:uid(),category:"Salary",amount:net,vendor:`${emp.name} — ${MO_F[selM]} ${selY}`,date:td(),paymentMode:"NEFT/RTGS",notes:`Salary slip: ${worked}/${days} days worked`};setExpenses(p=>[...p,expRec]);const updated={...emp,salaryHistory:[...(emp.salaryHistory||[]),{month:selM,year:selY,net,gross,worked,days,date:td()}]};setEmployees(p=>p.map(e=>e.id===emp.id?updated:e));sync("payroll",updated);showToast(`Salary ₹${fmtN(net)} generated for ${emp.name}`);setGM(null);},[calcSal,selY,selM]);

  const saveEmp=e=>{setEmployees(p=>p.find(x=>x.id===e.id)?p.map(x=>x.id===e.id?e:x):[...p,e]);setEE(null);sync("payroll",e);showToast(e.id?"Employee updated":"Employee added");};
  const delEmp=id=>{setEmployees(p=>p.filter(e=>e.id!==id));del("payroll",id);setSelEmp(null);showToast("Employee deleted","warn");};

  const doExport=()=>{if(!isPrem){onUpgrade();return;}exportXL(employees.map(e=>{const {net,gross,worked,days}=calcSal(e,selY,selM);return[e.name,e.designation,e.department,gross,net,worked,days];}),["Name","Designation","Department","Gross Salary","Net Salary","Days Worked","Working Days"],`payroll_${MO[selM]}_${selY}.xlsx`);};

  const daysInMonth=new Date(selY,selM+1,0).getDate();
  const dayNames=["Su","Mo","Tu","We","Th","Fr","Sa"];
  const firstDay=new Date(selY,selM,1).getDay();
  const blank={id:null,name:"",designation:"",phone:"",email:"",department:"",joiningDate:td(),salary:{basic:15000,hra:6000,travel:1500,special:0,bonus:0,pf:1800,esi:0,tds:0,advance:0,other_d:0},attendance:{},salaryHistory:[]};

  return(<div className="page">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
      <div className="ptit">Payroll 💰</div>
      <div style={{display:"flex",gap:7}}>
        <button className="btn btnsm" onClick={doExport}>📥 Export{!isPrem&&<span className="pbadge" style={{marginLeft:4}}>PRO</span>}</button>
        <button className="btn btnp btnsm" onClick={()=>setEE(blank)}>+ Employee</button>
      </div>
    </div>
    {/* Month selector */}
    <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:14}}>
      <button className="btn btnsm" onClick={()=>{if(selM===0){setSelM(11);setSelY(y=>y-1);}else setSelM(m=>m-1);}}>◀</button>
      <div style={{flex:1,textAlign:"center",fontWeight:800,fontSize:14}}>{MO_F[selM]} {selY}</div>
      <button className="btn btnsm" onClick={()=>{if(selM===11){setSelM(0);setSelY(y=>y+1);}else setSelM(m=>m+1);}}>▶</button>
    </div>
    {employees.length===0?<Empty icon="👷" title="No employees yet" sub="Add employees to track attendance and generate salary slips" cta="+ Add Employee" onCta={()=>setEE(blank)}/>:
      employees.map(emp=>{const att=getAtt(emp,selY,selM);const {net,gross,worked,days}=calcSal(emp,selY,selM);const alreadyPaid=(emp.salaryHistory||[]).some(h=>h.month===selM&&h.year===selY);
        return(<div key={emp.id} className="card" style={{marginBottom:12,overflow:"hidden"}}>
          <div style={{padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-start",borderBottom:"1px solid var(--bd2)",cursor:"pointer"}} onClick={()=>setSelEmp(selEmp?.id===emp.id?null:emp)}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{width:38,height:38,borderRadius:"50%",background:"var(--acb)",display:"grid",placeItems:"center",fontSize:15,fontWeight:900,color:"var(--ac)",flexShrink:0}}>{emp.name[0]}</div>
              <div><div style={{fontWeight:800,fontSize:13.5}}>{emp.name}</div><div style={{fontSize:11,color:"var(--mu)"}}>{emp.designation}{emp.department&&<span> · {emp.department}</span>}</div></div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontWeight:900,fontSize:14,color:"var(--ac)"}}>{fmt(net)}</div>
              <div style={{fontSize:11,color:"var(--mu)"}}>{worked}/{days} days</div>
              {alreadyPaid&&<span style={{fontSize:10,background:"var(--grb)",color:"var(--gr)",padding:"2px 6px",borderRadius:10,fontWeight:700}}>✓ Paid</span>}
            </div>
          </div>

          {selEmp?.id===emp.id&&<div style={{padding:"12px 14px"}}>
            {/* Attendance calendar */}
            <div style={{marginBottom:12}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3,marginBottom:4}}>
                {dayNames.map(d=><div key={d} style={{textAlign:"center",fontSize:9,fontWeight:800,color:"var(--mu)",padding:"3px 0"}}>{d}</div>)}
              </div>
              <div className="attg">
                {[...Array(firstDay)].map((_,i)=><div key={"e"+i}/>)}
                {[...Array(daysInMonth)].map((_,i)=>{const day=i+1;const s=att[day];const isWk=new Date(selY,selM,day).getDay()===0||new Date(selY,selM,day).getDay()===6;const cyc={P:"A",A:"H",H:undefined,undefined:"P"};return(<div key={day} className={`attc ${s||""} ${isWk?"wk":""}`} onClick={()=>!isWk&&setAtt(emp,day,cyc[s])}>
                  <span>{day}</span>{s&&<span style={{fontSize:7,fontWeight:900}}>{s}</span>}
                </div>);})}
              </div>
              <div style={{display:"flex",gap:8,marginTop:6,fontSize:11,color:"var(--mu)"}}><span>P=Present</span><span>A=Absent</span><span>H=Half-day</span><span>· tap to cycle</span></div>
            </div>
            {/* Salary breakdown */}
            <div style={{background:"var(--bg3)",borderRadius:10,padding:"10px 12px",marginBottom:10}}>
              <div style={{fontWeight:800,fontSize:12.5,marginBottom:8}}>Salary Breakdown</div>
              {SAL_COMPS.filter(c=>c.t==="e"&&(emp.salary?.[c.id]||0)>0).map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:3}}><span style={{color:"var(--mu)"}}>{c.lbl}</span><span style={{color:"var(--gr)"}}>{fmt(emp.salary?.[c.id]||0)}</span></div>)}
              {SAL_COMPS.filter(c=>c.t==="d"&&(emp.salary?.[c.id]||0)>0).map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:3}}><span style={{color:"var(--mu)"}}>{c.lbl}</span><span style={{color:"var(--re)"}}> - {fmt(emp.salary?.[c.id]||0)}</span></div>)}
              <div style={{display:"flex",justifyContent:"space-between",fontWeight:900,fontSize:13,borderTop:"1px solid var(--bd)",paddingTop:6,marginTop:4,color:"var(--ac)"}}><span>Net ({worked}/{days} days)</span><span>{fmt(net)}</span></div>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button className="btn btnsm" style={{flex:1}} onClick={()=>setEE(emp)}>✏️ Edit</button>
              <button className="btn btnG btnsm" style={{flex:2}} disabled={alreadyPaid} onClick={()=>setGM(emp)}>{alreadyPaid?"✓ Salary Paid":`🎯 Generate ₹${fmtN(net)}`}</button>
            </div>
          </div>}
        </div>);
      })}

    {/* Employee Form */}
    {editE!==null&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setEE(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr"><div style={{fontWeight:900}}>{editE.id?"Edit Employee":"New Employee"}</div><button className="btn btng btnxs" onClick={()=>setEE(null)}>✕</button></div>
        <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:12}}>
          <div><label className="lbl">Full Name *</label><input className="inp" value={editE.name||""} onChange={e=>setEE(p=>({...p,name:e.target.value}))} placeholder="Employee name" autoFocus/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Designation</label><input className="inp" value={editE.designation||""} onChange={e=>setEE(p=>({...p,designation:e.target.value}))} placeholder="Manager"/></div>
            <div><label className="lbl">Department</label><input className="inp" value={editE.department||""} onChange={e=>setEE(p=>({...p,department:e.target.value}))} placeholder="Sales"/></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Phone</label><input className="inp" value={editE.phone||""} onChange={e=>setEE(p=>({...p,phone:e.target.value}))}/></div>
            <div><label className="lbl">Email</label><input className="inp" type="email" value={editE.email||""} onChange={e=>setEE(p=>({...p,email:e.target.value}))}/></div>
          </div>
          <div><label className="lbl">Joining Date</label><input className="inp" type="date" value={editE.joiningDate||td()} onChange={e=>setEE(p=>({...p,joiningDate:e.target.value}))}/></div>
          <div style={{fontWeight:800,fontSize:12,color:"var(--mu)",textTransform:"uppercase",letterSpacing:".06em",marginBottom:-4}}>💚 Earnings</div>
          {SAL_COMPS.filter(c=>c.t==="e").map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:10}}><label style={{fontSize:13,flex:1}}>{c.lbl}</label><input className="inp" type="number" value={editE.salary?.[c.id]||0} onChange={e=>setEE(p=>({...p,salary:{...p.salary,[c.id]:+e.target.value}}))} style={{width:120}}/></div>)}
          <div style={{fontWeight:800,fontSize:12,color:"var(--mu)",textTransform:"uppercase",letterSpacing:".06em",marginBottom:-4}}>💸 Deductions</div>
          {SAL_COMPS.filter(c=>c.t==="d").map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:10}}><label style={{fontSize:13,flex:1}}>{c.lbl}</label><input className="inp" type="number" value={editE.salary?.[c.id]||0} onChange={e=>setEE(p=>({...p,salary:{...p.salary,[c.id]:+e.target.value}}))} style={{width:120}}/></div>)}
          <div style={{display:"flex",gap:10,paddingBottom:8}}>
            <button className="btn" style={{flex:1}} onClick={()=>setEE(null)}>Cancel</button>
            {editE.id&&<button className="btn btnR btnsm" onClick={()=>{if(window.confirm("Delete employee?"))delEmp(editE.id);}}>🗑</button>}
            <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!editE.name?.trim()){alert("Name required");return;}saveEmp({...editE,id:editE.id||uid()});}}>💾 Save</button>
          </div>
        </div>
      </div>
    </div>}

    {/* Confirm Generate Salary */}
    {genModal&&<div className="mbg ctr" onClick={e=>e.target===e.currentTarget&&setGM(null)}>
      <div className="mctr" style={{padding:"24px 20px"}}>
        <div style={{textAlign:"center",marginBottom:20}}>
          <div style={{fontSize:48,marginBottom:10}}>💸</div>
          <div style={{fontWeight:900,fontSize:18,marginBottom:4}}>Generate Salary?</div>
          <div style={{fontSize:13,color:"var(--mu)",lineHeight:1.6}}>This will create an expense record for <strong>{genModal.name}</strong> for <strong>{MO_F[selM]} {selY}</strong>.</div>
          <div style={{fontSize:24,fontWeight:900,color:"var(--ac)",marginTop:10}}>{fmt(calcSal(genModal,selY,selM).net)}</div>
        </div>
        <div style={{display:"flex",gap:10}}>
          <button className="btn" style={{flex:1}} onClick={()=>setGM(null)}>Cancel</button>
          <button className="btn btnG" style={{flex:2}} onClick={()=>generateSlip(genModal)}>✓ Confirm & Generate</button>
        </div>
      </div>
    </div>}
  </div>);
};

// ── Expenses Page ─────────────────────────────────────────────
const ExpensesPage=({expenses,setExpenses,showToast,isPrem,onUpgrade})=>{
  const [q,setQ]=useState(""),[catF,setCF]=useState("all"),[dr,setDR]=useState("all");
  const [editX,setEX]=useState(null);
  const filtered=useMemo(()=>{let r=[...expenses];if(catF!=="all")r=r.filter(e=>e.category===catF);if(q.trim())r=r.filter(e=>e.vendor?.toLowerCase().includes(q.toLowerCase())||e.category?.toLowerCase().includes(q.toLowerCase()));if(dr==="today")r=r.filter(e=>e.date===td());else if(dr==="week")r=r.filter(e=>e.date>=dAgo(7));else if(dr==="30d")r=r.filter(e=>e.date>=dAgo(30));return r.sort((a,b)=>new Date(b.date)-new Date(a.date));},[expenses,q,catF,dr]);
  const total=useMemo(()=>filtered.reduce((a,e)=>a+e.amount,0),[filtered]);
  const saveX=x=>{setExpenses(p=>p.find(e=>e.id===x.id)?p.map(e=>e.id===x.id?x:e):[...p,x]);setEX(null);showToast(x.id?"Expense updated":"Expense added");};
  const delX=id=>{setExpenses(p=>p.filter(e=>e.id!==id));showToast("Deleted","warn");};
  const doExport=()=>{if(!isPrem){onUpgrade();return;}exportXL(filtered.map(e=>[e.date,e.category,e.vendor||"",e.amount,e.paymentMode||"",e.notes||""]),["Date","Category","Vendor","Amount","Mode","Notes"],`expenses_${td()}.xlsx`);};
  const blank={id:null,category:"Office Supplies",amount:"",vendor:"",date:td(),paymentMode:"Cash",notes:""};
  return(<div className="page">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
      <div className="ptit">Expenses 💸</div>
      <div style={{display:"flex",gap:7}}>
        <button className="btn btnsm" onClick={doExport}>📥 Export{!isPrem&&<span className="pbadge" style={{marginLeft:4}}>PRO</span>}</button>
        <button className="btn btnp btnsm" onClick={()=>setEX(blank)}>+ Add</button>
      </div>
    </div>
    <div className="sbar"><span style={{fontSize:18,opacity:.5}}>🔍</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search expenses..."/></div>
    <div className="fbar">
      <Chip label="All Dates" active={dr==="all"} onClick={()=>setDR("all")}/>
      <Chip label="Today" active={dr==="today"} onClick={()=>setDR("today")}/>
      <Chip label="7 Days" active={dr==="week"} onClick={()=>setDR("week")}/>
      <Chip label="30 Days" active={dr==="30d"} onClick={()=>setDR("30d")}/>
    </div>
    <div className="fbar">
      <Chip label="All" active={catF==="all"} onClick={()=>setCF("all")}/>
      {EXP_CATS.map(c=><Chip key={c} label={c} active={catF===c} onClick={()=>setCF(c===catF?"all":c)}/>)}
    </div>
    {filtered.length>0&&<div className="card" style={{padding:"10px 14px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}><span style={{fontSize:12.5,color:"var(--mu)",fontWeight:600}}>{filtered.length} expenses</span><span style={{fontWeight:900,fontSize:15,color:"var(--re)"}}>{fmt(total)}</span></div>}
    {filtered.length===0?<Empty icon="💸" title="No expenses" sub="Track your business expenses here" cta="+ Add Expense" onCta={()=>setEX(blank)}/>:
      filtered.map(ex=><div key={ex.id} className="card cardi" style={{padding:"12px 14px",marginBottom:8,display:"flex",justifyContent:"space-between",alignItems:"center"}} onClick={()=>setEX(ex)}>
        <div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>{ex.category}</div><div style={{fontSize:11.5,color:"var(--mu)",marginTop:2}}>{ex.vendor||"—"} · {ex.date}</div>{ex.notes&&<div style={{fontSize:11,color:"var(--mu2)",marginTop:1}}>{ex.notes}</div>}</div>
        <div style={{textAlign:"right",flexShrink:0}}><div style={{fontWeight:900,fontSize:14,color:"var(--re)"}}>{fmt(ex.amount)}</div><div style={{fontSize:11,color:"var(--mu)"}}>{ex.paymentMode}</div></div>
      </div>)}

    {editX!==null&&<div className="mbg" onClick={e=>e.target===e.currentTarget&&setEX(null)}>
      <div className="msh">
        <div className="mh"/>
        <div className="mhdr"><div style={{fontWeight:900}}>{editX.id?"Edit Expense":"New Expense"}</div><button className="btn btng btnxs" onClick={()=>setEX(null)}>✕</button></div>
        <div style={{padding:"14px 16px",display:"flex",flexDirection:"column",gap:12}}>
          <div><label className="lbl">Category</label><select className="inp" value={editX.category||"Other"} onChange={e=>setEX(p=>({...p,category:e.target.value}))}>{EXP_CATS.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          <div><label className="lbl">Amount (₹) *</label><input className="inp" type="number" value={editX.amount||""} onChange={e=>setEX(p=>({...p,amount:+e.target.value}))} placeholder="0" autoFocus/></div>
          <div><label className="lbl">Vendor / Paid To</label><input className="inp" value={editX.vendor||""} onChange={e=>setEX(p=>({...p,vendor:e.target.value}))} placeholder="Vendor name"/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">Date</label><input className="inp" type="date" value={editX.date||td()} onChange={e=>setEX(p=>({...p,date:e.target.value}))}/></div>
            <div><label className="lbl">Payment Mode</label><select className="inp" value={editX.paymentMode||"Cash"} onChange={e=>setEX(p=>({...p,paymentMode:e.target.value}))}>{PAY_MODES.map(m=><option key={m} value={m}>{m}</option>)}</select></div>
          </div>
          <div><label className="lbl">Notes</label><input className="inp" value={editX.notes||""} onChange={e=>setEX(p=>({...p,notes:e.target.value}))} placeholder="Brief description"/></div>
          <div style={{display:"flex",gap:10,paddingBottom:8}}>
            <button className="btn" style={{flex:1}} onClick={()=>setEX(null)}>Cancel</button>
            {editX.id&&<button className="btn btnR btnsm" onClick={()=>{delX(editX.id);setEX(null);}}>🗑</button>}
            <button className="btn btnp" style={{flex:2}} onClick={()=>{if(!editX.amount){alert("Enter amount");return;}saveX({...editX,id:editX.id||uid()});}}>💾 Save</button>
          </div>
        </div>
      </div>
    </div>}
  </div>);
};

// ── Reports Page ──────────────────────────────────────────────
const ReportsPage=({invoices,expenses,biz,isPrem,onUpgrade})=>{
  const [tab,setTab]=useState("pl");
  const now=new Date();
  const fy=now.getMonth()>=3?now.getFullYear():now.getFullYear()-1;
  const fyS=`${fy}-04-01`,fyE=`${fy+1}-03-31`;
  const fyInv=useMemo(()=>invoices.filter(i=>i.invoiceDate>=fyS&&i.invoiceDate<=fyE),[invoices,fyS,fyE]);
  const fyExp=useMemo(()=>expenses.filter(e=>e.date>=fyS&&e.date<=fyE),[expenses,fyS,fyE]);
  const plData=useMemo(()=>MO.map((m,mi)=>{const mS=mi>=3?`${fy}-${String(mi+1).padStart(2,"0")}`:`${fy+1}-${String(mi+1).padStart(2,"0")}`;const rev=fyInv.filter(i=>i.invoiceDate.startsWith(mS)&&i.status==="paid").reduce((a,i)=>a+i.grandRounded,0);const exp=fyExp.filter(e=>e.date.startsWith(mS)).reduce((a,e)=>a+e.amount,0);return{name:m,Revenue:Math.round(rev),Expenses:Math.round(exp),Profit:Math.round(rev-exp)};}),[fyInv,fyExp,fy]);
  const totRev=fyInv.filter(i=>i.status==="paid").reduce((a,i)=>a+i.grandRounded,0);
  const totExp=fyExp.reduce((a,e)=>a+e.amount,0);
  const b2b=fyInv.filter(i=>i.hasGst&&i.party?.gstin&&i.status==="paid");
  const b2c=fyInv.filter(i=>i.hasGst&&!i.party?.gstin&&i.status==="paid");
  const hsnMap={};fyInv.filter(i=>i.hasGst).forEach(i=>(i.items||[]).forEach(it=>{const h=it.hsnCode||it.sacCode||"NA";if(!hsnMap[h])hsnMap[h]={hsn:h,taxable:0,cgst:0,sgst:0,igst:0};hsnMap[h].taxable+=it.taxable||0;hsnMap[h].cgst+=it.cgst||0;hsnMap[h].sgst+=it.sgst||0;hsnMap[h].igst+=it.igst||0;}));
  return(<div className="page">
    <div className="ptit" style={{marginBottom:12}}>Reports 📊</div>
    <div style={{display:"text",fontSize:12.5,color:"var(--mu)",marginBottom:14}}>FY {fy}–{fy+1} · Apr {fy} – Mar {fy+1}</div>
    <div className="fbar">
      <Chip label="P&L" active={tab==="pl"} onClick={()=>setTab("pl")}/>
      <Chip label="GSTR-1" active={tab==="gstr"} onClick={()=>setTab("gstr")}/>
      <Chip label="HSN Summary" active={tab==="hsn"} onClick={()=>setTab("hsn")}/>
    </div>
    {tab==="pl"&&<>
      <div className="kgrid" style={{marginBottom:14}}>
        <div className="kbox"><div className="kl">Revenue</div><div className="kv" style={{color:"var(--gr)"}}>{fmt(totRev)}</div></div>
        <div className="kbox"><div className="kl">Expenses</div><div className="kv" style={{color:"var(--re)"}}>{fmt(totExp)}</div></div>
        <div className="kbox" style={{gridColumn:"1/-1"}}><div className="kl">Net Profit</div><div className="kv" style={{color:totRev-totExp>=0?"var(--gr)":"var(--re)",fontSize:24}}>{fmt(totRev-totExp)}</div></div>
      </div>
      <div className="card" style={{padding:"14px 8px",marginBottom:14}}><ResponsiveContainer width="100%" height={160}><BarChart data={plData} margin={{top:0,right:8,left:-20,bottom:0}}><XAxis dataKey="name" tick={{fontSize:10,fill:"var(--mu)"}}/><YAxis tick={{fontSize:9,fill:"var(--mu)"}}/><Tooltip formatter={(v,n)=>[fmt(v),n]}/><Bar dataKey="Revenue" fill="#4A3AFF" radius={[4,4,0,0]}/><Bar dataKey="Expenses" fill="#F5900A" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div>
      {plData.filter(m=>m.Revenue>0||m.Expenses>0).map(m=><div key={m.name} className="card" style={{padding:"10px 14px",marginBottom:6,display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:700}}>{m.name}</span><span style={{color:"var(--gr)",fontWeight:700}}>{fmt(m.Revenue)}</span><span style={{color:"var(--re)",fontSize:12.5}}>{fmt(m.Expenses)}</span><span style={{color:m.Profit>=0?"var(--gr)":"var(--re)",fontWeight:800}}>{fmt(m.Profit)}</span></div>)}
    </>}
    {tab==="gstr"&&<>
      <div style={{fontWeight:800,marginBottom:8}}>B2B Invoices ({b2b.length})</div>
      {b2b.map(i=><div key={i.id} className="card" style={{padding:"10px 14px",marginBottom:6}}><div style={{display:"flex",justifyContent:"space-between"}}><div><div style={{fontWeight:700,fontSize:13}}>{i.party?.name}</div><div style={{fontSize:10.5,color:"var(--mu)",fontFamily:"'JetBrains Mono',monospace"}}>{i.party?.gstin}</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:800}}>{fmt(i.grandRounded)}</div><div style={{fontSize:11,color:"var(--mu)"}}>{i.invoiceNumber}</div></div></div></div>)}
      {b2b.length===0&&<div style={{color:"var(--mu)",fontSize:13,textAlign:"center",padding:"20px"}}>No B2B invoices with GSTIN</div>}
      <div style={{fontWeight:800,marginTop:14,marginBottom:8}}>B2C Invoices ({b2c.length})</div>
      {b2c.map(i=><div key={i.id} className="card" style={{padding:"10px 14px",marginBottom:6}}><div style={{display:"flex",justifyContent:"space-between"}}><div><div style={{fontWeight:700,fontSize:13}}>{i.party?.name||"Walk-in"}</div><div style={{fontSize:11,color:"var(--mu)"}}>{i.invoiceDate}</div></div><div style={{fontWeight:800}}>{fmt(i.grandRounded)}</div></div></div>)}
    </>}
    {tab==="hsn"&&<>
      {Object.values(hsnMap).length===0?<Empty icon="📊" title="No GST data" sub="GST invoices will appear here"/>:<div className="card" style={{overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}><thead><tr style={{background:"var(--acb)"}}><th style={{padding:"8px 10px",textAlign:"left",fontWeight:800}}>HSN/SAC</th><th style={{padding:"8px 10px",textAlign:"right",fontWeight:800}}>Taxable</th><th style={{padding:"8px 10px",textAlign:"right",fontWeight:800}}>CGST</th><th style={{padding:"8px 10px",textAlign:"right",fontWeight:800}}>SGST</th><th style={{padding:"8px 10px",textAlign:"right",fontWeight:800}}>IGST</th></tr></thead><tbody>{Object.values(hsnMap).map(r=><tr key={r.hsn} style={{borderTop:"1px solid var(--bd2)"}}><td style={{padding:"8px 10px",fontWeight:700,fontFamily:"'JetBrains Mono',monospace"}}>{r.hsn}</td><td style={{padding:"8px 10px",textAlign:"right"}}>{fmt(r.taxable)}</td><td style={{padding:"8px 10px",textAlign:"right",color:"var(--ac)"}}>{fmt(r.cgst)}</td><td style={{padding:"8px 10px",textAlign:"right",color:"var(--ac)"}}>{fmt(r.sgst)}</td><td style={{padding:"8px 10px",textAlign:"right",color:"var(--or)"}}>{fmt(r.igst)}</td></tr>)}</tbody></table></div>}
    </>}
  </div>);
};

// ── AskCA (AI Advisor) ────────────────────────────────────────
const AskCA=({invoices,expenses,customers,biz,isPrem,onUpgrade})=>{
  const [mode,setMode]=useState("brutal"),[input,setInput]=useState(""),[msgs,setMsgs]=useState([]),[loading,setLoading]=useState(false);
  const modes=[{id:"brutal",l:"Brutal Audit",i:"🔥",p:false},{id:"gst",l:"GST Guide",i:"📋",p:false},{id:"cashflow",l:"Cash Flow",i:"💰",p:false},{id:"offer",l:"Offers",i:"🎯",p:true},{id:"growth",l:"Growth",i:"📈",p:true}];
  const ctx=useMemo(()=>{const rev=invoices.filter(i=>i.status==="paid").reduce((a,i)=>a+i.grandRounded,0);const due=invoices.filter(i=>["unpaid","overdue","partial"].includes(i.status)).reduce((a,i)=>a+(i.grandRounded-(i.amountPaid||0)),0);const exp=expenses.reduce((a,e)=>a+e.amount,0);const top=customers.slice(0,3).map(c=>c.name).join(", ");return{rev,due,exp,profit:rev-exp,top,bizName:biz?.name,gstin:biz?.gstin};},[invoices,expenses,customers,biz]);
  const sysP=`You are a senior CA (Chartered Accountant) and business advisor for Indian SMEs. Business: ${ctx.bizName}. GSTIN: ${ctx.gstin||"Not registered"}. Revenue: ₹${fmtN(ctx.rev)}. Dues: ₹${fmtN(ctx.due)}. Expenses: ₹${fmtN(ctx.exp)}. Profit: ₹${fmtN(ctx.profit)}. Top customers: ${ctx.top}. Mode: ${mode}. Be direct, specific, and practical. Use Indian context (GST, ITR, MSME). Give actionable advice in 3-4 bullet points maximum.`;
  const send=async()=>{
    if(!input.trim())return;
    if(modes.find(m=>m.id===mode)?.p&&!isPrem){onUpgrade();return;}
    const userMsg={role:"user",content:input};
    setMsgs(p=>[...p,userMsg]);setInput("");setLoading(true);
    try{
      const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:sysP,messages:[...msgs,userMsg].slice(-8)})});
      const d=await r.json();
      setMsgs(p=>[...p,{role:"assistant",content:d.content?.[0]?.text||"Unable to respond."}]);
    }catch{setMsgs(p=>[...p,{role:"assistant",content:"Connection failed. Check your internet."}]);}
    setLoading(false);
  };
  return(<div className="page" style={{display:"flex",flexDirection:"column",height:"calc(100dvh - 100px)"}}>
    <div className="ptit" style={{marginBottom:12}}>AI CA Advisor 🤖</div>
    {!isPrem&&<div className="ub" style={{marginBottom:12}} onClick={onUpgrade}><div className="ubglow"/><div className="ubt"><div className="ubt1">🤖 Full AI Advisor — Premium</div><div className="ubt2">Get expert GST, cashflow & growth advice</div></div><button className="ubcta">Unlock</button></div>}
    <div className="fbar">{modes.map(m=><Chip key={m.id} label={`${m.i} ${m.l}`} active={mode===m.id} onClick={()=>{if(m.p&&!isPrem){onUpgrade();return;}setMode(m.id);}}/>)}</div>
    <div style={{flex:1,overflowY:"auto",paddingBottom:8}}>
      {msgs.length===0&&<div style={{padding:"20px",textAlign:"center",color:"var(--mu)"}}>
        <div style={{fontSize:48,marginBottom:10}}>🤖</div>
        <div style={{fontWeight:800,fontSize:14,marginBottom:4}}>Your AI Chartered Accountant</div>
        <div style={{fontSize:12.5,lineHeight:1.6}}>Ask me about GST, cash flow, pricing strategy, or business growth. I know your business numbers!</div>
        <div style={{marginTop:12,display:"flex",flexWrap:"wrap",gap:6,justifyContent:"center"}}>
          {["Why is my profit low?","Any overdue follow-ups?","Check my GST compliance","How to improve cash flow?"].map(q=><button key={q} onClick={()=>setInput(q)} style={{padding:"6px 12px",borderRadius:16,border:"1.5px solid var(--acbd)",background:"var(--acb)",color:"var(--ac)",fontSize:11.5,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>{q}</button>)}
        </div>
      </div>}
      {msgs.map((m,i)=><div key={i} style={{marginBottom:10,display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
        <div style={{maxWidth:"85%",padding:"10px 14px",borderRadius:m.role==="user"?"16px 16px 4px 16px":"16px 16px 16px 4px",background:m.role==="user"?"var(--ac)":"var(--bg2)",color:m.role==="user"?"#fff":"var(--tx)",fontSize:13,lineHeight:1.6,border:m.role==="assistant"?"1px solid var(--bd2)":"none",boxShadow:m.role==="assistant"?"var(--sh0)":"none",whiteSpace:"pre-wrap"}}>{m.content}</div>
      </div>)}
      {loading&&<div style={{display:"flex",gap:8,alignItems:"center",padding:"10px 14px",background:"var(--bg2)",borderRadius:12,width:"fit-content",border:"1px solid var(--bd2)"}}><Spin size={16}/><span style={{fontSize:12.5,color:"var(--mu)"}}>Analyzing your business data...</span></div>}
    </div>
    <div style={{display:"flex",gap:8,paddingTop:8,borderTop:"1px solid var(--bd2)"}}>
      <input className="inp" value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask your CA anything..." onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&send()} style={{flex:1}}/>
      <button className="btn btnp" style={{flexShrink:0,padding:"10px 16px"}} onClick={send} disabled={loading||!input.trim()}>{loading?<Spin size={16} li/>:"Send ↑"}</button>
    </div>
  </div>);
};

// ── Settings Page ─────────────────────────────────────────────
const SettingsPage=({biz,setBiz,user,onLogout,isPrem,onUpgrade,showToast})=>{
  const [b,setB]=useState(biz||{});
  const save=()=>{setBiz(b);LS.set("biz",b);sync("businesses",b);showToast("Settings saved ✓");};
  return(<div className="page">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
      <div className="ptit">Settings ⚙️</div>
      <button className="btn btnp btnsm" onClick={save}>💾 Save</button>
    </div>
    {/* Account card */}
    <div className="card" style={{padding:"14px",marginBottom:14}}>
      <div style={{display:"flex",gap:12,alignItems:"center",marginBottom:12}}>
        <div style={{width:44,height:44,borderRadius:"50%",background:"var(--acb)",display:"grid",placeItems:"center",fontSize:20,fontWeight:900,color:"var(--ac)"}}>{(user?.email||"U")[0].toUpperCase()}</div>
        <div><div style={{fontWeight:800,fontSize:14}}>{user?.email||"Demo User"}</div><div style={{fontSize:12,color:"var(--mu)"}}>{isPrem?"✨ Premium Account":"Free Account"}</div></div>
      </div>
      {!isPrem&&<button className="btn btnp" style={{width:"100%",marginBottom:8}} onClick={onUpgrade}>🚀 Upgrade to Premium — ₹79/month</button>}
      <button className="btn btnR" style={{width:"100%"}} onClick={onLogout}>🚪 Logout</button>
    </div>
    <div className="slbl">Business Profile</div>
    <div className="card" style={{padding:"14px",marginBottom:14,display:"flex",flexDirection:"column",gap:12}}>
      <div><label className="lbl">Business Name</label><input className="inp" value={b.name||""} onChange={e=>setB(p=>({...p,name:e.target.value}))}/></div>
      <div><label className="lbl">Phone</label><input className="inp" value={b.phone||""} onChange={e=>setB(p=>({...p,phone:e.target.value}))}/></div>
      <div><label className="lbl">Email</label><input className="inp" type="email" value={b.email||""} onChange={e=>setB(p=>({...p,email:e.target.value}))}/></div>
      <div><label className="lbl">Address</label><input className="inp" value={b.address?.line1||""} onChange={e=>setB(p=>({...p,address:{...p.address,line1:e.target.value}}))}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        <div><label className="lbl">City</label><input className="inp" value={b.address?.city||""} onChange={e=>setB(p=>({...p,address:{...p.address,city:e.target.value}}))}/></div>
        <div><label className="lbl">PIN</label><input className="inp" value={b.address?.pin||""} onChange={e=>setB(p=>({...p,address:{...p.address,pin:e.target.value}}))}/></div>
      </div>
    </div>
    <div className="slbl">GST & Tax</div>
    <div className="card" style={{padding:"14px",marginBottom:14,display:"flex",flexDirection:"column",gap:12}}>
      <Toggle on={b.isGstRegistered} onT={()=>setB(p=>({...p,isGstRegistered:!p.isGstRegistered}))} label={b.isGstRegistered?"GST Registered":"Not GST Registered"}/>
      {b.isGstRegistered&&<div><label className="lbl">GSTIN</label><input className="inp" value={b.gstin||""} onChange={e=>setB(p=>({...p,gstin:e.target.value.toUpperCase()}))} style={{fontFamily:"'JetBrains Mono',monospace"}}/>{b.gstin&&<div style={{fontSize:11,marginTop:4,color:validG(b.gstin)?"var(--gr)":"var(--re)",fontWeight:600}}>{validG(b.gstin)?"✓ Valid GSTIN":"⚠ Invalid GSTIN"}</div>}</div>}
      <div><label className="lbl">PAN</label><input className="inp" value={b.pan||""} onChange={e=>setB(p=>({...p,pan:e.target.value.toUpperCase()}))} placeholder="ABCDE1234F"/></div>
    </div>
    <div className="slbl">Bank & UPI</div>
    <div className="card" style={{padding:"14px",marginBottom:14,display:"flex",flexDirection:"column",gap:12}}>
      <div><label className="lbl">Bank Name</label><input className="inp" value={b.bank?.name||""} onChange={e=>setB(p=>({...p,bank:{...p.bank,name:e.target.value}}))}/></div>
      <div><label className="lbl">Account Number</label><input className="inp" value={b.bank?.account||""} onChange={e=>setB(p=>({...p,bank:{...p.bank,account:e.target.value}}))} style={{fontFamily:"'JetBrains Mono',monospace"}}/></div>
      <div><label className="lbl">IFSC Code</label><input className="inp" value={b.bank?.ifsc||""} onChange={e=>setB(p=>({...p,bank:{...p.bank,ifsc:e.target.value.toUpperCase()}}))}/></div>
      <div><label className="lbl">UPI ID</label><input className="inp" value={b.bank?.upi||""} onChange={e=>setB(p=>({...p,bank:{...p.bank,upi:e.target.value}}))}/></div>
    </div>
    <div className="slbl">Invoice Preferences</div>
    <div className="card" style={{padding:"14px",marginBottom:14,display:"flex",flexDirection:"column",gap:12}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        <div><label className="lbl">Invoice Prefix</label><input className="inp" value={b.invoicePrefix||"INV"} onChange={e=>setB(p=>({...p,invoicePrefix:e.target.value}))}/></div>
        <div><label className="lbl">Next Number</label><input className="inp" type="text" value={b.invoiceCounter||"1001"} onChange={e=>setB(p=>({...p,invoiceCounter:e.target.value}))} placeholder="e.g. 001 or 1001"/></div>
      </div>
      <Toggle on={b.showHSN!==false} onT={()=>setB(p=>({...p,showHSN:p.showHSN===false}))} label="Show HSN/SAC codes"/>
      <Toggle on={b.showQR!==false} onT={()=>setB(p=>({...p,showQR:p.showQR===false}))} label="Show UPI QR Code"/>
      <Toggle on={b.showBankDetails!==false} onT={()=>setB(p=>({...p,showBankDetails:p.showBankDetails===false}))} label="Show Bank Details"/>
      <Toggle on={b.showDiscount!==false} onT={()=>setB(p=>({...p,showDiscount:p.showDiscount===false}))} label="Show Discount Column"/>
      <div><label className="lbl">Footer Note</label><input className="inp" value={b.footerNote||""} onChange={e=>setB(p=>({...p,footerNote:e.target.value}))} placeholder="Thank you for your business!"/></div>
      <div><label className="lbl">Terms & Conditions</label><textarea className="inp" rows={2} value={b.termsNote||""} onChange={e=>setB(p=>({...p,termsNote:e.target.value}))}/></div>
    </div>
    <div className="slbl">Accent Color</div>
    <div className="card" style={{padding:"14px",marginBottom:14}}>
      <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
        {ACCENTS.map(a=><button key={a.id} onClick={()=>setB(p=>({...p,accentId:a.id}))} style={{width:40,height:40,borderRadius:"50%",background:a.h,border:b.accentId===a.id?"3px solid var(--tx)":"3px solid transparent",cursor:"pointer",transition:"all .15s",boxShadow:b.accentId===a.id?`0 0 0 3px ${a.h}40`:"none"}}/>)}
      </div>
    </div>
    <button className="btn btnp" style={{width:"100%",padding:"13px",borderRadius:11,marginBottom:16}} onClick={save}>💾 Save All Settings</button>
  </div>);
};

// ── More Tab Hub ──────────────────────────────────────────────
const MoreTab=({setPage,onLogout,isPrem,onUpgrade,user})=>{
  const links=[{i:"💸",l:"Expenses",d:"Track business expenses",p:"expenses"},{i:"📊",l:"Reports",d:"P&L, GSTR, HSN summary",p:"reports"},{i:"🤖",l:"AI CA Advisor",d:"Expert GST & business advice",p:"askca",prem:true},{i:"🧮",l:"GST Calculator",d:"Calculate tax instantly",p:"calculator"},{i:"⚙️",l:"Settings",d:"Business profile & preferences",p:"settings"}];
  return(<div className="page">
    <div className="ptit" style={{marginBottom:4}}>More</div>
    <div style={{fontSize:12.5,color:"var(--mu)",marginBottom:16}}>{user?.email||"Demo Mode"}</div>
    {!isPrem&&<div className="ub" onClick={onUpgrade}><div className="ubglow"/><div className="ubt"><div className="ubt1">🚀 Upgrade to Premium</div><div className="ubt2">Excel export · AI advisor · Luxury templates</div></div><button className="ubcta">₹79/mo →</button></div>}
    {links.map(l=><div key={l.p} className="card cardi" style={{padding:"14px",marginBottom:8,display:"flex",gap:14,alignItems:"center"}} onClick={()=>{if(l.prem&&!isPrem){onUpgrade();return;}setPage(l.p);}}>
      <div style={{fontSize:28,width:44,height:44,background:"var(--acb)",borderRadius:12,display:"grid",placeItems:"center",flexShrink:0}}>{l.i}</div>
      <div style={{flex:1}}><div style={{fontWeight:800,fontSize:14,display:"flex",alignItems:"center",gap:6}}>{l.l}{l.prem&&!isPrem&&<span className="pbadge">PRO</span>}</div><div style={{fontSize:12,color:"var(--mu)",marginTop:2}}>{l.d}</div></div>
      <span style={{color:"var(--mu2)",fontSize:18}}>›</span>
    </div>)}
    <div style={{textAlign:"center",padding:"20px 0 8px"}}>
      <button className="btn btnR" style={{width:"100%",maxWidth:280}} onClick={onLogout}>🚪 Logout</button>
    </div>
    <div style={{textAlign:"center",fontSize:11,color:"var(--mu2)",marginTop:8}}>BillBharat v3.0 · Made for Indian SMEs 🇮🇳</div>
  </div>);
};

// ── GST Calculator ────────────────────────────────────────────
const GstCalc=()=>{
  const [amt,setAmt]=useState(""),[rate,setRate]=useState(18),[inc,setInc]=useState(false);
  const calc=useMemo(()=>{const a=+amt||0;if(inc){const base=a/(1+rate/100);const tax=a-base;return{base,tax,cgst:tax/2,sgst:tax/2,total:a};}const tax=a*rate/100;return{base:a,tax,cgst:tax/2,sgst:tax/2,total:a+tax};},[amt,rate,inc]);
  return(<div className="page">
    <div className="ptit" style={{marginBottom:14}}>GST Calculator 🧮</div>
    <div className="card" style={{padding:"16px",marginBottom:14}}>
      <div style={{marginBottom:12}}><label className="lbl">Amount (₹)</label><input className="inp" type="number" value={amt} onChange={e=>setAmt(e.target.value)} placeholder="Enter amount" autoFocus/></div>
      <div style={{marginBottom:12}}><label className="lbl">GST Rate</label><div style={{display:"flex",gap:8,flexWrap:"wrap"}}>{GST_RATES.filter(r=>r>0).map(r=><button key={r} onClick={()=>setRate(r)} style={{padding:"6px 14px",borderRadius:8,border:`1.5px solid ${rate===r?"var(--ac)":"var(--bd2)"}`,background:rate===r?"var(--acb)":"var(--bg2)",fontWeight:700,fontSize:12,cursor:"pointer",fontFamily:"inherit",color:rate===r?"var(--ac)":"var(--tx2)"}}>{r}%</button>)}</div></div>
      <Toggle on={inc} onT={()=>setInc(!inc)} label={inc?"Amount is GST Inclusive":"Amount is GST Exclusive"}/>
    </div>
    {amt&&<div className="card" style={{padding:"16px"}}>
      <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--bd2)"}}><span style={{color:"var(--mu)"}}>Base Amount</span><span style={{fontWeight:700}}>{fmt(calc.base)}</span></div>
      <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--bd2)"}}><span style={{color:"var(--mu)"}}>CGST ({rate/2}%)</span><span style={{fontWeight:700,color:"var(--ac)"}}>{fmt(calc.cgst)}</span></div>
      <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--bd2)"}}><span style={{color:"var(--mu)"}}>SGST ({rate/2}%)</span><span style={{fontWeight:700,color:"var(--ac)"}}>{fmt(calc.sgst)}</span></div>
      <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--bd2)"}}><span style={{color:"var(--mu)"}}>Total Tax</span><span style={{fontWeight:700,color:"var(--or)"}}>{fmt(calc.tax)}</span></div>
      <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0"}}><span style={{fontWeight:800,fontSize:15}}>Grand Total</span><span style={{fontWeight:900,fontSize:18,color:"var(--ac)"}}>{fmt(calc.total)}</span></div>
    </div>}
  </div>);
};

// ── Onboarding ────────────────────────────────────────────────
const Onboarding=({onDone})=>{
  const [step,setStep]=useState(0);
  const [f,setF]=useState({name:"",type:"shop",isGstRegistered:false,gstin:"",pan:"",phone:"",email:"",address:{line1:"",city:"",state:"Maharashtra",pin:""},bank:{name:"",account:"",ifsc:"",upi:""},accentId:"teal",invoicePrefix:"INV",invoiceCounter:1001,layout:"modern",showHSN:true,showQR:true,showBankDetails:true,showDiscount:true,footerNote:"Thank you for your business! 🙏",termsNote:"Goods once sold will not be taken back."});
  const sf=p=>setF(x=>({...x,...p}));
  const biz_types=[{id:"shop",l:"Retail Shop",i:"🏪"},{id:"trader",l:"Trader",i:"📦"},{id:"manufacturer",l:"Manufacturer",i:"🏭"},{id:"service",l:"Service Provider",i:"💼"},{id:"restaurant",l:"Restaurant",i:"🍽️"},{id:"freelancer",l:"Freelancer",i:"💻"}];
  const done=()=>onDone({...f,id:uid()});
  return(<div style={{minHeight:"100vh",background:"linear-gradient(135deg,#F8F9FA,#EEF2FF 60%,#F0F9FF)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <style>{CSS}</style>
    <div style={{width:"100%",maxWidth:440}}>
      {/* Progress */}
      <div style={{display:"flex",gap:6,marginBottom:28,justifyContent:"center"}}>
        {[0,1,2].map(i=><div key={i} style={{height:4,flex:1,borderRadius:2,background:i<=step?"var(--ac)":"var(--bd2)",transition:"background .3s"}}/>)}
      </div>

      {step===0&&<div className="authcard su">
        <div style={{fontSize:48,marginBottom:12,textAlign:"center"}}>🏢</div>
        <div style={{fontWeight:900,fontSize:19,marginBottom:4}}>Tell us about your business</div>
        <div style={{fontSize:12.5,color:"var(--mu)",marginBottom:20}}>Step 1 of 3 — Business profile</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div><label className="lbl">Business Name *</label><input className="inp" value={f.name} onChange={e=>sf({name:e.target.value})} placeholder="e.g. Sharma Enterprises" autoFocus/></div>
          <div><label className="lbl">Business Type</label><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>{biz_types.map(t=><button key={t.id} onClick={()=>sf({type:t.id})} style={{padding:"10px",borderRadius:10,border:`1.5px solid ${f.type===t.id?"var(--ac)":"var(--bd2)"}`,background:f.type===t.id?"var(--acb)":"var(--bg2)",fontWeight:700,fontSize:12.5,cursor:"pointer",fontFamily:"inherit",color:f.type===t.id?"var(--ac)":"var(--tx2)"}}>{t.i} {t.l}</button>)}</div></div>
          <div><label className="lbl">Phone</label><input className="inp" value={f.phone} onChange={e=>sf({phone:e.target.value})} placeholder="9876543210" type="tel"/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div><label className="lbl">City</label><input className="inp" value={f.address.city} onChange={e=>sf({address:{...f.address,city:e.target.value}})}/></div>
            <div><label className="lbl">State</label><select className="inp" value={f.address.state} onChange={e=>sf({address:{...f.address,state:e.target.value}})}>{REGIONS.map(r=><option key={r} value={r}>{r}</option>)}</select></div>
          </div>
          <button className="btn btnp" style={{padding:"13px",fontSize:14,borderRadius:10,marginTop:4}} onClick={()=>{if(!f.name.trim()){alert("Enter business name");return;}setStep(1);}}>Continue →</button>
        </div>
      </div>}

      {step===1&&<div className="authcard su">
        <div style={{fontSize:48,marginBottom:12,textAlign:"center"}}>📋</div>
        <div style={{fontWeight:900,fontSize:19,marginBottom:4}}>GST Registration</div>
        <div style={{fontSize:12.5,color:"var(--mu)",marginBottom:20}}>Step 2 of 3 — Tax details</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <Toggle on={f.isGstRegistered} onT={()=>sf({isGstRegistered:!f.isGstRegistered})} label={f.isGstRegistered?"GST Registered Business":"Not GST Registered"}/>
          {f.isGstRegistered&&<div><label className="lbl">GSTIN</label><input className="inp" value={f.gstin} onChange={e=>sf({gstin:e.target.value.toUpperCase()})} placeholder="27AAFCS1234A1Z5" style={{fontFamily:"'JetBrains Mono',monospace"}}/>{f.gstin&&<div style={{fontSize:11,marginTop:4,color:validG(f.gstin)?"var(--gr)":"var(--re)",fontWeight:600}}>{validG(f.gstin)?"✓ Valid GSTIN":"⚠ Please check format"}</div>}</div>}
          <div><label className="lbl">PAN (optional)</label><input className="inp" value={f.pan} onChange={e=>sf({pan:e.target.value.toUpperCase()})} placeholder="ABCDE1234F"/></div>
          <div><label className="lbl">Invoice Prefix</label><input className="inp" value={f.invoicePrefix} onChange={e=>sf({invoicePrefix:e.target.value})} placeholder="INV"/></div>
          <div style={{display:"flex",gap:8,marginTop:4}}>
            <button className="btn" style={{flex:1}} onClick={()=>setStep(0)}>← Back</button>
            <button className="btn btnp" style={{flex:2,padding:"12px"}} onClick={()=>setStep(2)}>Continue →</button>
          </div>
        </div>
      </div>}

      {step===2&&<div className="authcard su">
        <div style={{fontSize:48,marginBottom:12,textAlign:"center"}}>🎨</div>
        <div style={{fontWeight:900,fontSize:19,marginBottom:4}}>Almost done!</div>
        <div style={{fontSize:12.5,color:"var(--mu)",marginBottom:20}}>Step 3 of 3 — Bank & theme</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div><label className="lbl">UPI ID</label><input className="inp" value={f.bank.upi} onChange={e=>sf({bank:{...f.bank,upi:e.target.value}})} placeholder="yourname@upi"/></div>
          <div><label className="lbl">Bank Account (optional)</label><input className="inp" value={f.bank.account} onChange={e=>sf({bank:{...f.bank,account:e.target.value}})} style={{fontFamily:"'JetBrains Mono',monospace"}}/></div>
          <div><label className="lbl">Accent Color</label><div style={{display:"flex",gap:10}}>{ACCENTS.map(a=><button key={a.id} onClick={()=>sf({accentId:a.id})} style={{width:36,height:36,borderRadius:"50%",background:a.h,border:f.accentId===a.id?"3px solid var(--tx)":"3px solid transparent",cursor:"pointer",boxShadow:f.accentId===a.id?`0 0 0 3px ${a.h}40`:"none"}}/>)}</div></div>
          <div style={{display:"flex",gap:8,marginTop:4}}>
            <button className="btn" style={{flex:1}} onClick={()=>setStep(1)}>← Back</button>
            <button className="btn btnp" style={{flex:2,padding:"12px"}} onClick={done}>🚀 Get Started!</button>
          </div>
          <button onClick={done} style={{background:"none",border:"none",cursor:"pointer",color:"var(--mu)",fontSize:12.5,fontFamily:"inherit",textAlign:"center",padding:"4px"}}>Skip for now</button>
        </div>
      </div>}
    </div>
  </div>);
};

// ╔══════════════════════════════════════════════════════════════╗
// ║  ROOT APP                                                  ║
// ╚══════════════════════════════════════════════════════════════╝
export default function App(){
  const [user,setUser]=useState(null),[loading,setLoading]=useState(true);
  const [page,setPage]=useState("home");
  const [biz,setBiz]=useState(null),[setupDone,setSetup]=useState(false);
  const [invoices,setInvoices]=useState([]),[customers,setCustomers]=useState([]);
  const [items,setItems]=useState([]),[expenses,setExpenses]=useState([]),[employees,setEmployees]=useState([]);
  const [isPrem,setPrem]=useState(false);
  const [toast,setToast]=useState(null),[showPrem,setSP]=useState(false);
  const [showInvModal,setSIM]=useState(false),[editInv,setEI]=useState(null);

  const showToast=useCallback((msg,type="ok")=>{setToast({msg,type});setTimeout(()=>setToast(null),3000);},[]);
  const onUpgrade=useCallback(()=>setSP(true),[]);

  // Bootstrap: check auth + load data
  useEffect(()=>{
    const init=async()=>{
      const sb=await getSB();
      if(sb){
        const{data:{session}}=await sb.auth.getSession();
        if(session?.user)setUser(session.user);
        sb.auth.onAuthStateChange((_,s)=>{setUser(s?.user||null);if(!s?.user){setBiz(null);setSetup(false);}});
      }
      // Load from LS
      const lsPrem=LS.get("isPrem",false);if(lsPrem)setPrem(true);
      const lsBiz=LS.get("biz",null);if(lsBiz){setBiz(lsBiz);setSetup(true);}
      const lsInv=LS.get("invoices",null);setInvoices(lsInv||mkInv());
      const lsCust=LS.get("customers",null);setCustomers(lsCust||DEMO_CUSTS);
      const lsItems=LS.get("items",null);setItems(lsItems||DEMO_ITEMS);
      const lsExp=LS.get("expenses",null);setExpenses(lsExp||DEMO_EXPS);
      const lsEmps=LS.get("employees",null);setEmployees(lsEmps||DEMO_EMPS);
      setLoading(false);
    };
    init();
  },[]);

  // Persist to LS on change
  useEffect(()=>{if(invoices.length>0)LS.set("invoices",invoices);},[invoices]);
  useEffect(()=>{if(customers.length>0)LS.set("customers",customers);},[customers]);
  useEffect(()=>{if(items.length>0)LS.set("items",items);},[items]);
  useEffect(()=>{if(expenses.length>0)LS.set("expenses",expenses);},[expenses]);
  useEffect(()=>{if(employees.length>0)LS.set("employees",employees);},[employees]);
  useEffect(()=>{if(biz)LS.set("biz",biz);},[biz]);

  const handleAuth=useCallback(u=>{setUser(u);if(u.isDemo){setBiz(DEMO_BIZ);setSetup(true);}showToast("Welcome to BillBharat! 🎉");},[showToast]);
  const handleLogout=useCallback(async()=>{const sb=await getSB();if(sb)await sb.auth.signOut();setUser(null);setBiz(null);setSetup(false);setInvoices(mkInv());setCustomers(DEMO_CUSTS);setItems(DEMO_ITEMS);setExpenses(DEMO_EXPS);setEmployees(DEMO_EMPS);setPrem(false);setPage("home");showToast("Logged out");},[showToast]);
  const handleActivate=useCallback(()=>{setPrem(true);LS.set("isPrem",true);setSP(false);showToast("🎉 Premium activated! Welcome aboard.");},[showToast]);
  const saveInv=useCallback(inv=>{setInvoices(p=>p.find(i=>i.id===inv.id)?p.map(i=>i.id===inv.id?inv:i):[inv,...p]);if(!editInv?.id&&biz)setBiz(b=>{const c=String(b.invoiceCounter||"1001");const num=c.replace(/\D/g,"");const inc=String(parseInt(num,10)+1).padStart(num.length,"0");return{...b,invoiceCounter:inc};});setSIM(false);setEI(null);sync("invoices",inv);showToast(editInv?.id?"Invoice updated":"Invoice saved ✓");},[editInv,biz,showToast]);
  const delInv=useCallback(id=>{setInvoices(p=>p.filter(i=>i.id!==id));del("invoices",id);showToast("Invoice deleted","warn");},[showToast]);

  const tabs=[{id:"home",i:"🏠",l:"Home"},{id:"crm",i:"🎯",l:"CRM"},{id:"items",i:"📦",l:"Items"},{id:"payroll",i:"💰",l:"Payroll"},{id:"more",i:"☰",l:"More"}];
  const mainTabs=new Set(["home","crm","items","payroll","more"]);
  const overdueCount=useMemo(()=>invoices.filter(i=>i.status==="overdue").length,[invoices]);

  // Active accent
  const accObj=ACCENTS.find(a=>a.id===(biz?.accentId||"indigo"))||ACCENTS[0];
  const accentCSS=biz?.accentId&&biz.accentId!=="indigo"?`:root{--ac:${accObj.h};--ac2:${accObj.d};--acb:${accObj.h}13;--acbd:${accObj.h}38;--shac:0 4px 20px ${accObj.h}52;}`:"";

  if(loading)return(<div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#F8F9FA",flexDirection:"column",gap:16}}><style>{CSS}</style><div style={{fontSize:52,filter:"drop-shadow(0 4px 16px rgba(74,58,255,.25))",animation:"bou 1.5s infinite"}}>💼</div><div style={{fontSize:22,fontWeight:900,letterSpacing:"-.03em"}}><span className="out">BillBharat</span></div><Spin size={28}/></div>);
  if(!user)return <AuthScreen onAuth={handleAuth}/>;
  if(!setupDone)return <Onboarding onDone={b=>{setBiz({...DEMO_BIZ,...b});setSetup(true);showToast("Setup complete! 🎉");}}/>;

  return(<div className="app">
    <style>{CSS}{accentCSS}</style>
    {toast&&<Toast msg={toast.msg} type={toast.type}/>}

    {/* Pages */}
    {page==="home"&&<div style={{maxWidth:640,margin:"0 auto",minHeight:"100%",background:"var(--bg)"}}><Dashboard invoices={invoices} customers={customers} items={items} expenses={expenses} biz={biz} isPrem={isPrem} onUpgrade={onUpgrade} setPage={setPage} onNewInv={()=>{setEI(null);setSIM(true);}}/></div>}
    {page==="crm"&&<CRMTab customers={customers} setCustomers={setCustomers} invoices={invoices} showToast={showToast} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="items"&&<ItemsTab items={items} setItems={setItems} showToast={showToast} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="payroll"&&<PayrollTab employees={employees} setEmployees={setEmployees} expenses={expenses} setExpenses={setExpenses} showToast={showToast} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="more"&&<MoreTab setPage={setPage} onLogout={handleLogout} isPrem={isPrem} onUpgrade={onUpgrade} user={user}/>}
    {page==="invoices"&&<InvList invoices={invoices} onNew={()=>{setEI(null);setSIM(true);}} onEdit={inv=>{setEI(inv);setSIM(true);}} onDelete={delInv} biz={biz} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="expenses"&&<ExpensesPage expenses={expenses} setExpenses={setExpenses} showToast={showToast} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="reports"&&<ReportsPage invoices={invoices} expenses={expenses} biz={biz} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="askca"&&<AskCA invoices={invoices} expenses={expenses} customers={customers} biz={biz} isPrem={isPrem} onUpgrade={onUpgrade}/>}
    {page==="calculator"&&<GstCalc/>}
    {page==="settings"&&<SettingsPage biz={biz} setBiz={setBiz} user={user} onLogout={handleLogout} isPrem={isPrem} onUpgrade={onUpgrade} showToast={showToast}/>}

    {/* FAB */}
    {mainTabs.has(page)&&<div className="fab">
      {page==="home"&&<>
        <button className="fpill" style={{background:"var(--bg2)",boxShadow:"var(--sh1)"}} onClick={()=>setPage("invoices")}>📋 All Sales</button>
        <button className="fpill fmain" onClick={()=>{setEI(null);setSIM(true);}}>+ New Invoice</button>
      </>}
      {page==="crm"&&<button className="fpill fmain" onClick={()=>{}}>+ Add Party</button>}
      {page==="items"&&<button className="fpill fmain" onClick={()=>{}}>+ Add Item</button>}
      {page==="payroll"&&<button className="fpill fmain" onClick={()=>{}}>+ Employee</button>}
    </div>}

    {/* Bottom Nav */}
    <nav className="bnav">
      {tabs.map(t=><button key={t.id} className={`bnt${page===t.id?" on":""}`} onClick={()=>setPage(t.id)}>
        <span className="bico">{t.i}</span>
        <span>{t.l}</span>
        {t.id==="home"&&overdueCount>0&&<span className="bbdg">{overdueCount}</span>}
      </button>)}
    </nav>

    {/* Invoice Modal */}
    {showInvModal&&<InvModal editing={editInv} onClose={()=>{setSIM(false);setEI(null);}} onSave={saveInv} biz={biz} customers={customers} items={items} isPrem={isPrem} onUpgrade={onUpgrade}/>}

    {/* Premium Modal */}
    {showPrem&&<PremModal onClose={()=>setSP(false)} onActivate={handleActivate}/>}
  </div>);
}
