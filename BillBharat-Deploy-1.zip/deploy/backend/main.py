"""
BillBharat FastAPI Backend v3.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Handles:
  • Razorpay — create order, verify payment, webhook
  • AI CA Proxy — Anthropic API (secure, not exposed to browser)
  • Supabase sync — CRUD helpers (invoices, customers, items, expenses, employees)
  • GSTR export — JSON & CSV
  • GST utilities — GSTIN verify, HSN lookup
  • Email notifications — payment receipt, invoice email
  • SMS OTP via Fast2SMS
  • Health / version
"""

import os, hmac, hashlib, json, csv, io, logging
from datetime import datetime, timedelta
from typing import Optional, List, Any, Dict

import httpx, razorpay
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request, Depends, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, EmailStr
from supabase import create_client, Client

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("billbharat")

# ─────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────
SUPABASE_URL        = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE    = os.getenv("SUPABASE_SERVICE_KEY", "")
RZP_KEY_ID          = os.getenv("RAZORPAY_KEY_ID", "")
RZP_KEY_SECRET      = os.getenv("RAZORPAY_KEY_SECRET", "")
RZP_WEBHOOK_SECRET  = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")
ANTHROPIC_KEY       = os.getenv("ANTHROPIC_API_KEY", "")
FAST2SMS_KEY        = os.getenv("FAST2SMS_API_KEY", "")
SMTP_HOST           = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT           = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER           = os.getenv("SMTP_USER", "")
SMTP_PASS           = os.getenv("SMTP_PASS", "")
FRONTEND_URL        = os.getenv("FRONTEND_URL", "http://localhost:3000")
CORS_ORIGINS        = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
PREMIUM_PAISE       = int(os.getenv("PREMIUM_AMOUNT_PAISE", "7900"))   # ₹79

PROMO_DISCOUNTS: Dict[str, int] = {
    "LAUNCH50":  50,
    "STARTUP30": 30,
    "BB2024":    20,
    "EARLYBIRD": 40,
}

# ─────────────────────────────────────────────────────────────
# App
# ─────────────────────────────────────────────────────────────
app = FastAPI(
    title="BillBharat API",
    description="Production backend for BillBharat GST Billing SaaS",
    version="3.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────
# Dependencies
# ─────────────────────────────────────────────────────────────
def get_supabase() -> Client:
    if not SUPABASE_URL or not SUPABASE_SERVICE:
        raise HTTPException(500, "Supabase not configured. Check SUPABASE_URL and SUPABASE_SERVICE_KEY env vars.")
    return create_client(SUPABASE_URL, SUPABASE_SERVICE)

async def get_user(authorization: str = Header(None)):
    """Validate Supabase JWT and return user object."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or invalid Authorization header")
    token = authorization.split(" ", 1)[1]
    sb = get_supabase()
    try:
        resp = sb.auth.get_user(token)
        if not resp or not resp.user:
            raise HTTPException(401, "Token invalid or expired")
        return resp.user
    except Exception as e:
        log.warning(f"Auth failure: {e}")
        raise HTTPException(401, "Unauthorized")

def get_rzp():
    if not RZP_KEY_ID or not RZP_KEY_SECRET:
        raise HTTPException(500, "Razorpay not configured")
    return razorpay.Client(auth=(RZP_KEY_ID, RZP_KEY_SECRET))

# ─────────────────────────────────────────────────────────────
# ── Models ───────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
class CreateOrderReq(BaseModel):
    amount_paise: int = PREMIUM_PAISE
    promo_code: Optional[str] = None
    user_id: str
    user_email: Optional[str] = None

class VerifyPaymentReq(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    user_id: str
    plan: str = "monthly"

class AIReq(BaseModel):
    messages: List[Dict[str, Any]]
    mode: str = "gst"          # brutal | gst | cashflow | offer | growth
    business_context: Optional[Dict] = None

class GSTRExportReq(BaseModel):
    user_id: str
    month: int           # 1-12
    year: int
    invoice_ids: Optional[List[str]] = None

class InvoiceEmailReq(BaseModel):
    to_email: str
    to_name: str
    invoice_number: str
    invoice_date: str
    amount: float
    business_name: str
    download_url: Optional[str] = None

class SMSOTPReq(BaseModel):
    phone: str   # 10-digit Indian mobile

class GSTINVerifyReq(BaseModel):
    gstin: str

class SyncRecord(BaseModel):
    table: str
    record: Dict[str, Any]
    user_id: str

class DeleteRecord(BaseModel):
    table: str
    record_id: str
    user_id: str

# ─────────────────────────────────────────────────────────────
# ── Health ───────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.get("/api/health", tags=["System"])
def health():
    return {
        "status": "ok",
        "version": "3.0.0",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "services": {
            "supabase": bool(SUPABASE_URL),
            "razorpay": bool(RZP_KEY_ID),
            "ai": bool(ANTHROPIC_KEY),
            "sms": bool(FAST2SMS_KEY),
            "email": bool(SMTP_USER),
        }
    }

# ─────────────────────────────────────────────────────────────
# ── Razorpay — Create Order ───────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/payment/create-order", tags=["Payments"])
async def create_order(req: CreateOrderReq, user=Depends(get_user)):
    rzp = get_rzp()
    amount = req.amount_paise

    # Apply promo discount
    promo_label = None
    if req.promo_code:
        code = req.promo_code.upper().strip()
        disc = PROMO_DISCOUNTS.get(code)
        if disc:
            amount = int(amount * (1 - disc / 100))
            promo_label = f"{disc}% off ({code})"
        else:
            raise HTTPException(400, f"Invalid promo code: {req.promo_code}")

    try:
        order = rzp.order.create({
            "amount": amount,
            "currency": "INR",
            "receipt": f"bb_{req.user_id[:8]}_{int(datetime.utcnow().timestamp())}",
            "notes": {
                "user_id": req.user_id,
                "user_email": req.user_email or "",
                "promo_code": req.promo_code or "",
                "product": "BillBharat Premium",
            }
        })
    except Exception as e:
        log.error(f"Razorpay create order error: {e}")
        raise HTTPException(502, f"Payment gateway error: {str(e)}")

    return {
        "order_id": order["id"],
        "amount": amount,
        "currency": "INR",
        "key_id": RZP_KEY_ID,
        "promo_label": promo_label,
    }

# ─────────────────────────────────────────────────────────────
# ── Razorpay — Verify Payment ─────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/payment/verify", tags=["Payments"])
async def verify_payment(req: VerifyPaymentReq, user=Depends(get_user)):
    # Signature verification
    payload = f"{req.razorpay_order_id}|{req.razorpay_payment_id}"
    expected = hmac.new(
        RZP_KEY_SECRET.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected, req.razorpay_signature):
        log.warning(f"Payment signature mismatch for user {req.user_id}")
        raise HTTPException(400, "Payment signature verification failed")

    # Mark premium in Supabase
    sb = get_supabase()
    try:
        sb.table("user_subscriptions").upsert({
            "user_id": req.user_id,
            "is_premium": True,
            "plan": req.plan,
            "razorpay_payment_id": req.razorpay_payment_id,
            "razorpay_order_id": req.razorpay_order_id,
            "activated_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(days=30)).isoformat(),
        }).execute()
    except Exception as e:
        log.error(f"Supabase subscription update error: {e}")
        # Don't fail — payment already done. Log for manual review.

    log.info(f"✅ Premium activated for user {req.user_id}, payment {req.razorpay_payment_id}")
    return {"success": True, "message": "Premium activated!", "payment_id": req.razorpay_payment_id}

# ─────────────────────────────────────────────────────────────
# ── Razorpay — Webhook ────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/webhook/razorpay", tags=["Webhooks"])
async def razorpay_webhook(request: Request):
    body = await request.body()
    sig = request.headers.get("x-razorpay-signature", "")

    if RZP_WEBHOOK_SECRET:
        expected = hmac.new(RZP_WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, sig):
            raise HTTPException(400, "Invalid webhook signature")

    try:
        event = json.loads(body)
    except Exception:
        raise HTTPException(400, "Invalid JSON")

    event_type = event.get("event")
    log.info(f"Razorpay webhook: {event_type}")

    if event_type == "payment.captured":
        payment = event.get("payload", {}).get("payment", {}).get("entity", {})
        notes = payment.get("notes", {})
        user_id = notes.get("user_id")
        if user_id:
            sb = get_supabase()
            sb.table("user_subscriptions").upsert({
                "user_id": user_id,
                "is_premium": True,
                "plan": "monthly",
                "razorpay_payment_id": payment.get("id"),
                "activated_at": datetime.utcnow().isoformat(),
                "expires_at": (datetime.utcnow() + timedelta(days=30)).isoformat(),
            }).execute()
            log.info(f"Webhook: Premium activated for {user_id}")

    elif event_type == "subscription.halted":
        log.warning(f"Subscription halted: {event}")

    return {"status": "ok"}

# ─────────────────────────────────────────────────────────────
# ── AI CA Proxy ───────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
MODE_PROMPTS = {
    "brutal": "You are a brutally honest Indian CA giving no-nonsense business advice. Be direct, use Indian context (GST, TDS, ITR, MSME). Point out real risks. Max 3 paragraphs.",
    "gst": "You are an expert GST consultant for India. Answer GST questions precisely with section references. Cover ITC, GSTR-1, GSTR-3B, e-invoicing, HSN codes. Keep it practical.",
    "cashflow": "You are a cash flow expert for Indian SMEs. Analyse the data and give 3-5 actionable steps to improve cash flow, receivables, and working capital. Use ₹ figures.",
    "offer": "You are a sales coach for Indian SMEs. Based on the business data, suggest specific deal structures, discount strategies, and upsell opportunities to close more sales.",
    "growth": "You are a business growth advisor for Indian SMEs. Identify growth levers, market opportunities, and practical steps to scale revenue in the next 90 days.",
}

@app.post("/api/ai/ask", tags=["AI"])
async def ai_ask(req: AIReq, user=Depends(get_user)):
    if not ANTHROPIC_KEY:
        raise HTTPException(503, "AI service not configured")

    system = MODE_PROMPTS.get(req.mode, MODE_PROMPTS["gst"])

    # Append business context to system prompt if provided
    if req.business_context:
        ctx = json.dumps(req.business_context, ensure_ascii=False, indent=2)
        system += f"\n\nBusiness Context:\n{ctx}"

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1024,
                    "system": system,
                    "messages": req.messages,
                }
            )
        resp.raise_for_status()
        data = resp.json()
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        return {"response": text, "usage": data.get("usage")}
    except httpx.HTTPStatusError as e:
        log.error(f"Anthropic API error: {e.response.status_code} {e.response.text}")
        raise HTTPException(502, "AI service temporarily unavailable")
    except Exception as e:
        log.error(f"AI error: {e}")
        raise HTTPException(500, str(e))

# ─────────────────────────────────────────────────────────────
# ── Supabase Data Sync ────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
ALLOWED_TABLES = {"invoices", "customers", "items", "expenses", "employees", "businesses", "interactions"}

@app.post("/api/sync/upsert", tags=["Data"])
async def sync_upsert(req: SyncRecord, user=Depends(get_user)):
    if req.table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{req.table}' not allowed")
    sb = get_supabase()
    try:
        sb.table(req.table).upsert({**req.record, "user_id": req.user_id}).execute()
        return {"success": True}
    except Exception as e:
        log.error(f"Sync upsert error: {e}")
        raise HTTPException(500, str(e))

@app.post("/api/sync/delete", tags=["Data"])
async def sync_delete(req: DeleteRecord, user=Depends(get_user)):
    if req.table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{req.table}' not allowed")
    sb = get_supabase()
    try:
        sb.table(req.table).delete().eq("id", req.record_id).eq("user_id", req.user_id).execute()
        return {"success": True}
    except Exception as e:
        log.error(f"Sync delete error: {e}")
        raise HTTPException(500, str(e))

@app.get("/api/sync/pull/{table}", tags=["Data"])
async def sync_pull(table: str, user=Depends(get_user)):
    if table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{table}' not allowed")
    sb = get_supabase()
    try:
        uid = user.id
        result = sb.table(table).select("*").eq("user_id", uid).execute()
        return {"data": result.data or []}
    except Exception as e:
        log.error(f"Sync pull error: {e}")
        raise HTTPException(500, str(e))

# ─────────────────────────────────────────────────────────────
# ── Subscription Status ───────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.get("/api/subscription/status", tags=["Payments"])
async def subscription_status(user=Depends(get_user)):
    sb = get_supabase()
    try:
        result = sb.table("user_subscriptions").select("*").eq("user_id", user.id).single().execute()
        sub = result.data
        if not sub:
            return {"is_premium": False}
        # Check expiry
        expires = sub.get("expires_at")
        if expires and datetime.fromisoformat(expires.replace("Z","")) < datetime.utcnow():
            return {"is_premium": False, "expired": True, "expired_at": expires}
        return {
            "is_premium": sub.get("is_premium", False),
            "plan": sub.get("plan"),
            "activated_at": sub.get("activated_at"),
            "expires_at": expires,
        }
    except Exception:
        return {"is_premium": False}

# ─────────────────────────────────────────────────────────────
# ── GSTR Export ───────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/gstr/export", tags=["GST"])
async def gstr_export(req: GSTRExportReq, user=Depends(get_user)):
    """Export invoices in GSTR-1 JSON format for GST portal upload."""
    sb = get_supabase()
    query = (sb.table("invoices")
               .select("*")
               .eq("user_id", req.user_id)
               .gte("invoiceDate", f"{req.year}-{req.month:02d}-01")
               .lte("invoiceDate", f"{req.year}-{req.month:02d}-31")
               .in_("type", ["tax_invoice","debit_note","credit_note"]))

    if req.invoice_ids:
        query = query.in_("id", req.invoice_ids)

    result = query.execute()
    invoices = result.data or []

    # Build GSTR-1 structure (B2B section)
    b2b_map: Dict[str, list] = {}
    b2c_list = []

    for inv in invoices:
        party = inv.get("party") or {}
        gstin = party.get("gstin", "")
        items = inv.get("items") or []

        inv_entry = {
            "inum": inv.get("invoiceNumber", ""),
            "idt": inv.get("invoiceDate", ""),
            "val": float(inv.get("grandRounded", 0)),
            "pos": gstin[0:2] if gstin else "",
            "rchrg": "N",
            "itms": [
                {
                    "num": i + 1,
                    "itm_det": {
                        "hsn_sc": it.get("hsnCode") or it.get("sacCode") or "",
                        "txval": float(it.get("taxable", 0)),
                        "irt": float(it.get("gstRate", 0)),
                        "iamt": float(it.get("taxAmt", 0)),
                        "crt": 0,
                        "camt": float(it.get("cgst", 0)),
                        "srt": 0,
                        "samt": float(it.get("sgst", 0)),
                        "csrt": 0,
                        "csamt": 0,
                    }
                }
                for i, it in enumerate(items)
            ]
        }

        if gstin and len(gstin) == 15:
            if gstin not in b2b_map:
                b2b_map[gstin] = []
            b2b_map[gstin].append(inv_entry)
        else:
            b2c_list.append(inv_entry)

    gstr1 = {
        "gstin": req.user_id,
        "fp": f"{req.month:02d}{req.year}",
        "b2b": [{"ctin": gstin, "inv": invs} for gstin, invs in b2b_map.items()],
        "b2c": b2c_list,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "total_invoices": len(invoices),
    }

    return JSONResponse(content=gstr1, headers={
        "Content-Disposition": f'attachment; filename="GSTR1_{req.month:02d}_{req.year}.json"'
    })

@app.post("/api/gstr/csv", tags=["GST"])
async def gstr_csv(req: GSTRExportReq, user=Depends(get_user)):
    """Export invoices as CSV for Excel/Tally import."""
    sb = get_supabase()
    result = (sb.table("invoices")
                .select("*")
                .eq("user_id", req.user_id)
                .gte("invoiceDate", f"{req.year}-{req.month:02d}-01")
                .lte("invoiceDate", f"{req.year}-{req.month:02d}-31")
                .execute())

    invoices = result.data or []

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Invoice No","Date","Type","Party","GSTIN","Subtotal",
        "CGST","SGST","IGST","Total Tax","Grand Total","Status","Payment Mode"
    ])

    for inv in invoices:
        party = inv.get("party") or {}
        writer.writerow([
            inv.get("invoiceNumber",""),
            inv.get("invoiceDate",""),
            inv.get("type",""),
            party.get("name",""),
            party.get("gstin",""),
            inv.get("subtotal",0),
            inv.get("totalCGST",0),
            inv.get("totalSGST",0),
            inv.get("totalIGST",0),
            inv.get("totalTax",0),
            inv.get("grandRounded",0),
            inv.get("status",""),
            inv.get("paymentMode",""),
        ])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="Invoices_{req.month:02d}_{req.year}.csv"'}
    )

# ─────────────────────────────────────────────────────────────
# ── GSTIN Verify ──────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/gst/verify-gstin", tags=["GST"])
async def verify_gstin(req: GSTINVerifyReq, user=Depends(get_user)):
    """Basic GSTIN format validation + checksum."""
    gstin = req.gstin.upper().strip()
    import re
    if not re.match(r"^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$", gstin):
        return {"valid": False, "error": "Invalid GSTIN format"}

    state_codes = {
        "01":"Jammu & Kashmir","02":"Himachal Pradesh","03":"Punjab","04":"Chandigarh",
        "05":"Uttarakhand","06":"Haryana","07":"Delhi","08":"Rajasthan","09":"Uttar Pradesh",
        "10":"Bihar","11":"Sikkim","12":"Arunachal Pradesh","13":"Nagaland","14":"Manipur",
        "15":"Mizoram","16":"Tripura","17":"Meghalaya","18":"Assam","19":"West Bengal",
        "20":"Jharkhand","21":"Odisha","22":"Chhattisgarh","23":"Madhya Pradesh",
        "24":"Gujarat","26":"Dadra & Nagar Haveli","27":"Maharashtra","28":"Andhra Pradesh (old)",
        "29":"Karnataka","30":"Goa","31":"Lakshadweep","32":"Kerala","33":"Tamil Nadu",
        "34":"Puducherry","35":"Andaman & Nicobar","36":"Telangana","37":"Andhra Pradesh",
        "38":"Ladakh","97":"Other Territory","99":"Centre Jurisdiction",
    }
    state_code = gstin[:2]
    state = state_codes.get(state_code, "Unknown")
    pan = gstin[2:12]
    entity_type = {"P":"Individual/Proprietor","F":"Firm/LLP","C":"Private Ltd","H":"HUF","T":"Trust","B":"Body of Individuals","L":"Local Authority","J":"Artificial Juridical Person","G":"Government"}.get(gstin[5], "Unknown")

    return {
        "valid": True,
        "gstin": gstin,
        "state": state,
        "state_code": state_code,
        "pan": pan,
        "entity_type": entity_type,
        "registration_type": "Regular" if gstin[12] == "1" else "Composition/Other"
    }

# ─────────────────────────────────────────────────────────────
# ── SMS OTP via Fast2SMS ───────────────────────────────────────
# ─────────────────────────────────────────────────────────────
import random, string

@app.post("/api/auth/send-otp", tags=["Auth"])
async def send_otp(req: SMSOTPReq, background_tasks: BackgroundTasks):
    phone = req.phone.strip()
    if not phone.isdigit() or len(phone) != 10:
        raise HTTPException(400, "Invalid phone number. Must be 10 digits.")

    otp = "".join(random.choices(string.digits, k=6))

    if FAST2SMS_KEY:
        async def _send():
            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    await client.post(
                        "https://www.fast2sms.com/dev/bulkV2",
                        headers={"authorization": FAST2SMS_KEY},
                        json={
                            "route": "otp",
                            "variables_values": otp,
                            "numbers": phone,
                        }
                    )
                log.info(f"OTP sent to {phone[-4:]}****")
            except Exception as e:
                log.error(f"SMS send error: {e}")

        background_tasks.add_task(_send)
    else:
        log.info(f"[DEV] OTP for {phone}: {otp}")

    # Store OTP in Supabase with 5-min expiry
    sb = get_supabase()
    try:
        sb.table("otp_store").upsert({
            "phone": phone,
            "otp": otp,
            "expires_at": (datetime.utcnow() + timedelta(minutes=5)).isoformat(),
            "used": False,
        }).execute()
    except Exception as e:
        log.error(f"OTP store error: {e}")

    return {"success": True, "message": f"OTP sent to {phone[:3]}XXXXXXX"}

@app.post("/api/auth/verify-otp", tags=["Auth"])
async def verify_otp(phone: str, otp: str):
    sb = get_supabase()
    try:
        result = sb.table("otp_store").select("*").eq("phone", phone).eq("otp", otp).eq("used", False).execute()
        record = result.data[0] if result.data else None

        if not record:
            raise HTTPException(400, "Invalid OTP")

        expires = datetime.fromisoformat(record["expires_at"].replace("Z",""))
        if datetime.utcnow() > expires:
            raise HTTPException(400, "OTP expired. Please request a new one.")

        # Mark used
        sb.table("otp_store").update({"used": True}).eq("phone", phone).execute()
        return {"success": True, "verified": True}
    except HTTPException:
        raise
    except Exception as e:
        log.error(f"OTP verify error: {e}")
        raise HTTPException(500, "Verification failed")

# ─────────────────────────────────────────────────────────────
# ── Invoice Email ─────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.post("/api/invoice/send-email", tags=["Invoices"])
async def send_invoice_email(req: InvoiceEmailReq, background_tasks: BackgroundTasks, user=Depends(get_user)):
    if not SMTP_USER:
        raise HTTPException(503, "Email not configured")

    async def _send():
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText

        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f9f9f9;padding:20px;">
          <div style="background:linear-gradient(135deg,#004D40,#00897B);padding:28px;border-radius:12px 12px 0 0;text-align:center;">
            <h1 style="color:white;margin:0;font-size:24px;">₹ BillBharat</h1>
            <p style="color:rgba(255,255,255,.8);margin:6px 0 0;font-size:14px;">GST Invoice</p>
          </div>
          <div style="background:white;padding:28px;border-radius:0 0 12px 12px;border:1px solid #e0e0e0;">
            <p style="font-size:16px;color:#333;">Hi <strong>{req.to_name}</strong>,</p>
            <p style="color:#555;">Please find your invoice from <strong>{req.business_name}</strong>:</p>
            <div style="background:#F0FAF7;border:1px solid #C9E4DC;border-radius:10px;padding:20px;margin:20px 0;text-align:center;">
              <div style="font-size:13px;color:#4A7A6D;">Invoice No</div>
              <div style="font-size:22px;font-weight:bold;color:#00897B;">{req.invoice_number}</div>
              <div style="font-size:13px;color:#4A7A6D;margin-top:10px;">Amount Due</div>
              <div style="font-size:28px;font-weight:900;color:#004D40;">₹{req.amount:,.2f}</div>
              <div style="font-size:12px;color:#7EADA3;">Invoice Date: {req.invoice_date}</div>
            </div>
            {f'<div style="text-align:center;margin:20px 0;"><a href="{req.download_url}" style="background:#00897B;color:white;padding:12px 32px;border-radius:8px;text-decoration:none;font-weight:bold;font-size:15px;">📥 Download Invoice</a></div>' if req.download_url else ""}
            <hr style="border:none;border-top:1px solid #e0e0e0;margin:20px 0;"/>
            <p style="font-size:12px;color:#999;text-align:center;">This invoice was generated via BillBharat. Please contact {req.business_name} for any queries.</p>
          </div>
        </div>
        """

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = f"Invoice {req.invoice_number} from {req.business_name} — ₹{req.amount:,.0f}"
            msg["From"] = f"BillBharat <{SMTP_USER}>"
            msg["To"] = req.to_email
            msg.attach(MIMEText(html, "html"))

            with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as smtp:
                smtp.starttls()
                smtp.login(SMTP_USER, SMTP_PASS)
                smtp.send_message(msg)

            log.info(f"Invoice email sent to {req.to_email}")
        except Exception as e:
            log.error(f"Email send error: {e}")

    background_tasks.add_task(_send)
    return {"success": True, "message": f"Invoice emailed to {req.to_email}"}

# ─────────────────────────────────────────────────────────────
# ── Analytics ─────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
@app.get("/api/analytics/summary", tags=["Analytics"])
async def analytics_summary(user=Depends(get_user)):
    sb = get_supabase()
    uid = user.id

    try:
        inv_result = sb.table("invoices").select("*").eq("user_id", uid).execute()
        exp_result = sb.table("expenses").select("*").eq("user_id", uid).execute()
        invoices = inv_result.data or []
        expenses = exp_result.data or []

        total_revenue = sum(i.get("grandRounded", 0) for i in invoices if i.get("status") == "paid")
        total_receivable = sum(
            (i.get("grandRounded", 0) - i.get("amountPaid", 0))
            for i in invoices
            if i.get("status") in ("unpaid", "partial", "overdue")
        )
        total_expenses = sum(e.get("amount", 0) for e in expenses)
        total_gst_collected = sum(i.get("totalTax", 0) for i in invoices)

        # Monthly breakdown (last 6 months)
        monthly = {}
        for inv in invoices:
            d = inv.get("invoiceDate", "")[:7]
            if d:
                monthly.setdefault(d, {"revenue": 0, "invoices": 0})
                monthly[d]["revenue"] += inv.get("grandRounded", 0)
                monthly[d]["invoices"] += 1

        return {
            "total_revenue": total_revenue,
            "total_receivable": total_receivable,
            "total_expenses": total_expenses,
            "net_profit": total_revenue - total_expenses,
            "total_gst_collected": total_gst_collected,
            "total_invoices": len(invoices),
            "paid_invoices": sum(1 for i in invoices if i.get("status") == "paid"),
            "overdue_invoices": sum(1 for i in invoices if i.get("status") == "overdue"),
            "monthly_breakdown": dict(sorted(monthly.items())[-6:]),
        }
    except Exception as e:
        log.error(f"Analytics error: {e}")
        raise HTTPException(500, str(e))
