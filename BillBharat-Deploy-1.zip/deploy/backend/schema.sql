-- ═══════════════════════════════════════════════════════════
-- BillBharat — Supabase Database Schema v3.0
-- Run this in: Supabase Dashboard → SQL Editor
-- ═══════════════════════════════════════════════════════════

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── businesses ──────────────────────────────────────────────
create table if not exists businesses (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  name        text not null,
  gstin       text,
  address     jsonb,
  phone       text,
  email       text,
  bank        jsonb,
  settings    jsonb default '{}',
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);
create index on businesses(user_id);

-- ── invoices ────────────────────────────────────────────────
create table if not exists invoices (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid references auth.users(id) on delete cascade not null,
  invoice_number  text not null,
  type            text not null default 'tax_invoice',
  status          text not null default 'unpaid',
  party           jsonb,
  items           jsonb default '[]',
  subtotal        numeric(12,2) default 0,
  total_cgst      numeric(12,2) default 0,
  total_sgst      numeric(12,2) default 0,
  total_igst      numeric(12,2) default 0,
  total_tax       numeric(12,2) default 0,
  grand_total     numeric(12,2) default 0,
  grand_rounded   numeric(12,2) default 0,
  round_off       numeric(6,4) default 0,
  amount_paid     numeric(12,2) default 0,
  payment_mode    text default 'Cash',
  invoice_date    date,
  due_date        date,
  notes           text,
  po_number       text,
  template        text default 'modern',
  has_gst         boolean default true,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);
create index on invoices(user_id);
create index on invoices(invoice_date);
create index on invoices(status);
create index on invoices(user_id, invoice_date);

-- ── customers ────────────────────────────────────────────────
create table if not exists customers (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  name        text not null,
  type        text default 'customer',
  gstin       text,
  phone       text,
  email       text,
  address     jsonb,
  tags        text[] default '{}',
  lead_stage  text default 'customer',
  notes       text,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);
create index on customers(user_id);
create index on customers(lead_stage);

-- ── items ────────────────────────────────────────────────────
create table if not exists items (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  name        text not null,
  type        text default 'product',
  description text,
  rate        numeric(12,2) default 0,
  unit        text default 'Pcs',
  gst_rate    numeric(5,2) default 18,
  hsn_code    text,
  sac_code    text,
  stock       numeric(12,2) default 0,
  low_stock   numeric(12,2) default 5,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);
create index on items(user_id);

-- ── expenses ─────────────────────────────────────────────────
create table if not exists expenses (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  category    text not null,
  amount      numeric(12,2) not null,
  vendor      text,
  date        date not null,
  notes       text,
  receipt_url text,
  created_at  timestamptz default now()
);
create index on expenses(user_id);
create index on expenses(date);

-- ── employees ────────────────────────────────────────────────
create table if not exists employees (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  name        text not null,
  role        text,
  phone       text,
  email       text,
  pan         text,
  join_date   date,
  salary_components jsonb default '{}',
  attendance  jsonb default '{}',
  active      boolean default true,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);
create index on employees(user_id);

-- ── interactions (CRM) ────────────────────────────────────────
create table if not exists interactions (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid references auth.users(id) on delete cascade not null,
  customer_id   uuid references customers(id) on delete cascade,
  type          text not null,
  notes         text,
  follow_up_date date,
  created_at    timestamptz default now()
);
create index on interactions(customer_id);

-- ── user_subscriptions ───────────────────────────────────────
create table if not exists user_subscriptions (
  id                   uuid primary key default uuid_generate_v4(),
  user_id              uuid references auth.users(id) on delete cascade not null unique,
  is_premium           boolean default false,
  plan                 text default 'free',
  razorpay_payment_id  text,
  razorpay_order_id    text,
  activated_at         timestamptz,
  expires_at           timestamptz,
  updated_at           timestamptz default now()
);
create index on user_subscriptions(user_id);

-- ── otp_store ────────────────────────────────────────────────
create table if not exists otp_store (
  phone       text primary key,
  otp         text not null,
  expires_at  timestamptz not null,
  used        boolean default false,
  created_at  timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- Row Level Security (RLS)
-- ═══════════════════════════════════════════════════════════

alter table businesses        enable row level security;
alter table invoices          enable row level security;
alter table customers         enable row level security;
alter table items             enable row level security;
alter table expenses          enable row level security;
alter table employees         enable row level security;
alter table interactions      enable row level security;
alter table user_subscriptions enable row level security;

-- Each user sees only their own data
create policy "users_own_businesses"        on businesses        for all using (auth.uid() = user_id);
create policy "users_own_invoices"          on invoices          for all using (auth.uid() = user_id);
create policy "users_own_customers"         on customers         for all using (auth.uid() = user_id);
create policy "users_own_items"             on items             for all using (auth.uid() = user_id);
create policy "users_own_expenses"          on expenses          for all using (auth.uid() = user_id);
create policy "users_own_employees"         on employees         for all using (auth.uid() = user_id);
create policy "users_own_interactions"      on interactions      for all using (auth.uid() = user_id);
create policy "users_own_subscriptions"     on user_subscriptions for all using (auth.uid() = user_id);

-- ═══════════════════════════════════════════════════════════
-- Auto-update updated_at trigger
-- ═══════════════════════════════════════════════════════════
create or replace function update_updated_at()
returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

create trigger trg_businesses_updated   before update on businesses   for each row execute function update_updated_at();
create trigger trg_invoices_updated     before update on invoices     for each row execute function update_updated_at();
create trigger trg_customers_updated    before update on customers    for each row execute function update_updated_at();
create trigger trg_items_updated        before update on items        for each row execute function update_updated_at();
create trigger trg_employees_updated    before update on employees    for each row execute function update_updated_at();
