# BillBharat v3.0 — Deployment Guide

## Project Structure

```
billbharat-deploy/
├── frontend/                 ← React + Vite SPA
│   ├── src/
│   │   ├── App.jsx           ← Main app (1573 lines, all-in-one)
│   │   └── main.jsx          ← Entry point
│   ├── public/
│   │   ├── favicon.svg
│   │   └── manifest.json     ← PWA manifest
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js        ← PWA + chunking
│   ├── vercel.json           ← Vercel deploy config
│   └── .env.example          ← Copy to .env
├── backend/                  ← FastAPI Python API
│   ├── main.py               ← All API routes
│   ├── requirements.txt
│   ├── schema.sql            ← Supabase DB schema
│   ├── Dockerfile
│   └── .env.example          ← Copy to .env
├── nginx/
│   └── nginx.conf            ← Production reverse proxy
├── docker-compose.yml        ← Full-stack local/VPS deploy
└── README.md
```

---

## Option 1 — Recommended: Vercel (Frontend) + Railway (Backend)

### Step 1 — Set up Supabase

1. Go to [supabase.com](https://supabase.com) → New Project
2. Go to **SQL Editor** → paste contents of `backend/schema.sql` → Run
3. Go to **Settings → API** → copy:
   - Project URL → `VITE_SUPABASE_URL` and `SUPABASE_URL`
   - `anon` key → `VITE_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_KEY` (backend only, keep secret!)
4. Go to **Authentication → Providers** → enable Email and/or Phone

### Step 2 — Set up Razorpay

1. Go to [dashboard.razorpay.com](https://dashboard.razorpay.com)
2. Settings → API Keys → Generate Key
3. Copy Key ID → `VITE_RAZORPAY_KEY` and `RAZORPAY_KEY_ID`
4. Copy Secret → `RAZORPAY_KEY_SECRET`
5. Settings → Webhooks → Add webhook URL: `https://api.yourdomain.com/api/webhook/razorpay`
   - Events: `payment.captured`, `subscription.halted`
   - Copy Webhook Secret → `RAZORPAY_WEBHOOK_SECRET`

### Step 3 — Deploy Backend to Railway

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# In /backend folder
cd backend
cp .env.example .env
# Fill in all values in .env

railway init
railway up
```

Or use Railway Dashboard:
1. New Project → Deploy from GitHub
2. Select your repo → set root to `/backend`
3. Add all env vars from `.env.example`
4. Deploy → copy the Railway URL (e.g. `https://billbharat-api.railway.app`)

### Step 4 — Deploy Frontend to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

cd frontend
cp .env.example .env
# Fill in values — set VITE_API_URL to your Railway URL

# Build and deploy
npm install
vercel --prod
```

Or via Vercel Dashboard:
1. Import GitHub repo → Framework: Vite
2. Root: `frontend/`
3. Add environment variables from `.env.example`
4. Deploy

---

## Option 2 — VPS (DigitalOcean / AWS / any Linux server)

### Prerequisites
```bash
# Ubuntu 22.04
sudo apt update && sudo apt upgrade -y
sudo apt install -y docker.io docker-compose-v2 nginx certbot
```

### Deploy

```bash
# Clone or upload your project
cd /var/www
git clone https://github.com/yourname/billbharat.git
cd billbharat

# Set up environment files
cp backend/.env.example backend/.env
nano backend/.env    # fill in all values

# Build frontend
cd frontend
npm install
npm run build
cd ..

# SSL certificate (replace with your domain)
sudo certbot certonly --standalone -d billbharat.in -d www.billbharat.in
sudo cp /etc/letsencrypt/live/billbharat.in/fullchain.pem nginx/ssl/
sudo cp /etc/letsencrypt/live/billbharat.in/privkey.pem nginx/ssl/

# Start everything
docker compose up -d

# Check logs
docker compose logs -f
```

---

## Option 3 — Local Development

```bash
# Terminal 1 — Backend
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # fill in values
uvicorn main:app --reload --port 8000

# Terminal 2 — Frontend
cd frontend
npm install
cp .env.example .env             # fill in values
npm run dev
# Opens at http://localhost:3000
```

---

## Environment Variables Reference

### Frontend (`frontend/.env`)
| Variable | Description | Where to get |
|---|---|---|
| `VITE_SUPABASE_URL` | Supabase project URL | Supabase → Settings → API |
| `VITE_SUPABASE_ANON_KEY` | Supabase anon key | Supabase → Settings → API |
| `VITE_RAZORPAY_KEY` | Razorpay Key ID | Razorpay → Settings → API Keys |
| `VITE_API_URL` | Backend API URL | Your Railway/VPS URL |

### Backend (`backend/.env`)
| Variable | Description |
|---|---|
| `SUPABASE_URL` | Same as frontend |
| `SUPABASE_SERVICE_KEY` | Service role key (SECRET — never expose) |
| `RAZORPAY_KEY_ID` | Razorpay Key ID |
| `RAZORPAY_KEY_SECRET` | Razorpay Key Secret |
| `RAZORPAY_WEBHOOK_SECRET` | Webhook verification secret |
| `ANTHROPIC_API_KEY` | Claude AI key |
| `FAST2SMS_API_KEY` | SMS OTP (optional) |
| `SMTP_USER` + `SMTP_PASS` | Gmail app password for invoice emails |
| `CORS_ORIGINS` | Your frontend domain(s) |

---

## API Endpoints

```
GET    /api/health                    Health check
POST   /api/payment/create-order      Create Razorpay order
POST   /api/payment/verify            Verify payment + activate premium
GET    /api/subscription/status       Check premium status
POST   /api/webhook/razorpay          Razorpay webhook handler
POST   /api/ai/ask                    AI CA proxy (modes: gst/brutal/cashflow/offer/growth)
POST   /api/sync/upsert               Sync record to Supabase
POST   /api/sync/delete               Delete record from Supabase
GET    /api/sync/pull/{table}         Pull all records for user
POST   /api/gstr/export               Download GSTR-1 JSON
POST   /api/gstr/csv                  Download invoices CSV
POST   /api/gst/verify-gstin          Validate GSTIN
POST   /api/auth/send-otp             Send SMS OTP
POST   /api/auth/verify-otp           Verify OTP
POST   /api/invoice/send-email        Email invoice to customer
GET    /api/analytics/summary         Revenue/expense analytics
GET    /api/docs                      Swagger UI (auto-generated)
```

---

## PWA (Add to Home Screen)

The frontend is configured as a PWA. Users on mobile can:
- Android: Chrome → ⋮ → "Add to Home screen"
- iOS: Safari → Share → "Add to Home Screen"

Icons needed in `/frontend/public/`:
- `icon-192.png` — 192×192 PNG (app icon)
- `icon-512.png` — 512×512 PNG (splash screen)

Generate from `favicon.svg` using: https://realfavicongenerator.net

---

## Production Checklist

- [ ] `SUPABASE_SERVICE_KEY` is kept secret (only in backend)
- [ ] Razorpay keys switched from `rzp_test_` to `rzp_live_`
- [ ] CORS_ORIGINS set to your actual domain
- [ ] SSL certificate installed (HTTPS)
- [ ] Razorpay webhook URL registered and verified
- [ ] Supabase RLS policies enabled (done by schema.sql)
- [ ] PWA icons (icon-192.png, icon-512.png) in `/public`
- [ ] `SMTP_USER` + `SMTP_PASS` configured for invoice emails
- [ ] Backend `ANTHROPIC_API_KEY` set (don't put in frontend .env in production)
